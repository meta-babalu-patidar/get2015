CREATE DATABASE skill_finder;

USE skill_finder;