package TestCases;

import static org.junit.Assert.*;

import org.junit.Test;

import org.hibernate.criterion.Restrictions;
import org.junit.After;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.hibernate.SessionFactory;
import com.meta.skillfinder.dao.ContactDetailsDao;
import com.meta.skillfinder.dao.UserDao;
import com.meta.skillfinder.dao.impl.ContactDetailsDaoImpl;
import com.meta.skillfinder.dao.impl.UserDaoImpl;
import com.meta.skillfinder.model.ContactDetails;
import com.meta.skillfinder.model.User;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"file:WebContent/WEB-INF/config/SkillFinder-servlet.xml"})

public class ContactDetailsDaoImplTest {


	@Autowired(required=false)
	private User user = new User();
	@Autowired(required=false)
	private ContactDetails contactDetails = new ContactDetails();
	@Autowired(required=false)
	private ContactDetailsDao contactDaoImpl = new ContactDetailsDaoImpl();
	@Autowired(required=false)
	private UserDao userDaoImpl = new UserDaoImpl();
	@Autowired(required=false)
	private SessionFactory sessionFactory;



	/**
	 * 	Set User attributes before test case start executing
	 */
	@Before
	public void setUp() {
		user.setContactId(1);
		user.setUserId(1);
		user.setGiven_name("Ankur");
		user.setEmail("ankur.gupta@metacube.com");
		userDaoImpl.addUser(user);
		contactDetails.setContactId(1);
		contactDetails.setAddress("sitapura");
		contactDetails.setPincode(302033);
		contactDetails.setState("rajasthan");
		contactDetails.setCountry("india");
	}

	/**
	 * to test the method that adds contactDetails object in table
	 */

	@Test
	public void testContactDetails() {

		contactDaoImpl.addContactDetails(contactDetails);
		assertNotNull(sessionFactory.getCurrentSession().createCriteria(ContactDetails.class).add(Restrictions.eq("contactId", 1)).uniqueResult());
	}


	/**
	 * 	Set User attributes after test case executed
	 */
	@After
	public void tearDown() {
		user = null;
		contactDetails = null;
	}
}
