package TestCases;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import com.meta.skillfinder.dao.UserDao;
import com.meta.skillfinder.dao.impl.UserDaoImpl;
import com.meta.skillfinder.exception.MetaSkillFinderException;
import com.meta.skillfinder.model.User;


@RunWith(SpringJUnit4ClassRunner.class)

@ContextConfiguration(locations={"file:WebContent/WEB-INF/config/SkillFinder-servlet.xml"})

public class UserDaoImplTest  {
	@Autowired(required = false)
	private UserDao userDao = new UserDaoImpl();
	@Autowired(required = false)
	private User user = new User();


	/**
	 * 	Set User attributes before test case start executing
	 */
	@Before
	public void setUp() {
		user.setGiven_name("test");
		user.setEmail("ankur.gupta@metacube.com");
		user.setContactId(1);
	}

	/**
	 * to test the method that get user object from table by email
	 * @throws MetaSkillFinderException 
	 */
	@Transactional
	@Test
	public void testGetUser()  {
		String email= "ankur.gupta@metacube.com";
		try {
			userDao.addUser(user);
		} catch (MetaSkillFinderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		User user1;
		try {
			user1 = userDao.getUser(user.getEmail());
			assertEquals(email, user1.getEmail());
		} catch (MetaSkillFinderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * to test the method that get user object from table by email
	 * @throws MetaSkillFinderException 
	 */
	@Transactional
	@Test
	public void testGetUser2()  {
		user.setGiven_name("test2");
		user.setEmail("ab@metacube.com");
		user.setContactId(2);
		String email= "ab@metacube.com";
		try {
			userDao.addUser(user);
		} catch (MetaSkillFinderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		User user1;
		try {
			user1 = userDao.getUser(user.getEmail());
			assertEquals(email, user1.getEmail());
		} catch (MetaSkillFinderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * to test the method to update user that get user object from table by email
	 * @throws MetaSkillFinderException 
	 */

	@Transactional
	@Test
	public void testUpdateUser() {
		user.setGiven_name("test1");
		try {
			userDao.updateUser(user);
		} catch (MetaSkillFinderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		User user1;
		try {
			user1 = userDao.getUser(user.getEmail());
			System.out.println(user1);
			assertEquals("test1", user1.getGiven_name());
		} catch (MetaSkillFinderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}

	/**
	 * 	Set User attributes after test case executed
	 */
	@After
	public void tearDown() {
		user = null;
	}
}


