package TestCases;

import static org.junit.Assert.*;

import org.junit.Test;
import org.hibernate.criterion.Restrictions;
import org.junit.After;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.hibernate.SessionFactory;

import com.meta.skillfinder.exception.MetaSkillFinderException;
import com.meta.skillfinder.model.Certificate;
import com.meta.skillfinder.model.User;
import com.meta.skillfinder.service.CertificateService;
import com.meta.skillfinder.service.UserService;
import com.meta.skillfinder.service.impl.CertificateServiceImpl;
import com.meta.skillfinder.service.impl.UserServiceImpl;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"file:WebContent/WEB-INF/config/SkillFinder-servlet.xml"})

public class CertificateServiceTest  {


	@Autowired(required=false)
	private User user = new User();
	@Autowired(required=false)
	private Certificate certificate = new Certificate();
	@Autowired(required=false)
	private CertificateService certificateServiceImpl = new CertificateServiceImpl();
	@Autowired(required=false)
	private UserService userServiceImpl = new UserServiceImpl();
	@Autowired(required=false)
	private SessionFactory sessionFactory;



	/**
	 * 	Set User attributes before test case start executing
	 */
	@Before
	public void setUp() {
		user.setContactId(1);
		user.setUserId(1);
		user.setGiven_name("Ankur");
		user.setEmail("ankur.gupta@metacube.com");
		try {
			userServiceImpl.addUser(user);
		} catch (MetaSkillFinderException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		certificate.setCertificateId(1);
		certificate.setUserId(1);
		certificate.setCertificateName("css");
		certificate.setIssuingAuthorithy("image");
		try {
			certificateServiceImpl.addUserCertificate(certificate);
		} catch (MetaSkillFinderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			}

	/**
	 * to test the method that adds certificate object in table
	 */

	@Test
	public void testcertificate() {
	
		assertNotNull(sessionFactory.getCurrentSession().createCriteria(Certificate.class).add(Restrictions.eq("userId", 1)).list());
	}

	/**
	 * to test the method that delete certificate object in table
	 */

	@Test
	public void testDeleteCertificate() {
		
		certificateServiceImpl.deleteUserCertificate(1);
		assertNull(sessionFactory.getCurrentSession().createCriteria(Certificate.class).add(Restrictions.eq("userId", 1)).list());
	}

	/**
	 * 	Set User attributes after test case executed
	 */
	@After
	public void tearDown() {
		user = null;
		certificate = null;
	}
}
