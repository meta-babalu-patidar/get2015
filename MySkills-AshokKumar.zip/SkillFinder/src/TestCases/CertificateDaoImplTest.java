package TestCases;

import static org.junit.Assert.*;

import org.junit.Test;
import org.hibernate.criterion.Restrictions;
import org.junit.After;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;

import com.meta.skillfinder.dao.CertificateDao;
import com.meta.skillfinder.dao.UserDao;
import com.meta.skillfinder.dao.impl.CertificateDaoImpl;
import com.meta.skillfinder.dao.impl.UserDaoImpl;
import com.meta.skillfinder.exception.MetaSkillFinderException;
import com.meta.skillfinder.model.Certificate;
import com.meta.skillfinder.model.User;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"file:WebContent/WEB-INF/config/SkillFinder-servlet.xml"})

public class CertificateDaoImplTest  {


	@Autowired(required=false)
	private User user = new User();
	@Autowired(required=false)
	private Certificate certificate = new Certificate();
	@Autowired(required=false)
	private CertificateDao certificateDaoImpl = new CertificateDaoImpl();
	@Autowired(required=false)
	private UserDao userDaoImpl = new UserDaoImpl();
	@Autowired(required=false)
	private SessionFactory sessionFactory;



	/**
	 * 	Set User attributes before test case start executing
	 */
	@Before
	public void setUp() {
		user.setContactId(1);
		user.setUserId(1);
		user.setGiven_name("Ankur");
		user.setEmail("ankur.gupta@metacube.com");
		try {
			userDaoImpl.addUser(user);
		} catch (MetaSkillFinderException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		certificate.setCertificateId(1);
		certificate.setUserId(1);
		certificate.setCertificateName("css");
		certificate.setIssuingAuthorithy("image");
		try {
			certificateDaoImpl.addUserCertificate(certificate);
		} catch (MetaSkillFinderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			}

	/**
	 * to test the method that adds certificate object in table
	 */

	@Transactional
	@Test
	public void testcertificate() {
	
		assertEquals(1, sessionFactory.getCurrentSession().createCriteria(Certificate.class).add(Restrictions.eq("userId", 1)).list().size());
	}

	/**
	 * to test the method that delete certificate object in table
	 */

	@Transactional
	@Test
	public void testDeleteCertificate() {
		
		try {
			certificateDaoImpl.deleteUserCertificate(1);
		} catch (MetaSkillFinderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertEquals(1,sessionFactory.getCurrentSession().createCriteria(Certificate.class).add(Restrictions.eq("userId", 1)).list().size());
	}

	/**
	 * 	Set User attributes after test case executed
	 */
	@After
	public void tearDown() {
		user = null;
		certificate = null;
	}
}
