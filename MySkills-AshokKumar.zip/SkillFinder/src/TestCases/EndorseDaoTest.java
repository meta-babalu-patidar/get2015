package TestCases;

import static org.junit.Assert.*;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.criterion.Restrictions;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.hibernate.SessionFactory;
import com.meta.skillfinder.dao.EndorseDao;
import com.meta.skillfinder.dao.SkillDao;
import com.meta.skillfinder.dao.UserDao;
import com.meta.skillfinder.dao.impl.EndorseDaoImpl;
import com.meta.skillfinder.dao.impl.SkillDaoImpl;
import com.meta.skillfinder.dao.impl.UserDaoImpl;
import com.meta.skillfinder.model.Endorse;
import com.meta.skillfinder.model.Skill;
import com.meta.skillfinder.model.User;
import com.meta.skillfinder.exception.MetaSkillFinderException;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"file:WebContent/WEB-INF/config/SkillFinder-servlet.xml"})

public class EndorseDaoTest {


	@Autowired(required=false)
	private User user = new User();
	@Autowired(required=false)
	private User user1 = new User();
	@Autowired(required=false)
	private EndorseDao endorseDaoImpl = new EndorseDaoImpl();
	@Autowired(required=false)
	private UserDao userDaoImpl = new UserDaoImpl();
	@Autowired(required=false)
	private Endorse endorse = new Endorse();
	@Autowired(required=false)
	private SkillDao skillDaoImpl = new SkillDaoImpl();
	@Autowired(required=false)
	private Skill skill = new Skill();
	@Autowired(required=false)
	private SessionFactory sessionFactory;



	/**
	 * 	Set User attributes before test case start executing
	 */
	@Before
	public void setUp() {
		user.setContactId(1);
		user.setUserId(1);
		user.setGiven_name("Ankur");
		user.setEmail("ankur.gupta@metacube.com");
		try {
			userDaoImpl.addUser(user);
		} catch (MetaSkillFinderException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		user1.setContactId(2);
		user1.setUserId(2);
		user1.setGiven_name("Ankur");
		user1.setEmail("ab@metacube.com");
		try {
			userDaoImpl.addUser(user1);
		} catch (MetaSkillFinderException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Set<Skill> skills = new HashSet<Skill>();
		skill.setSkillId(1);
		skill.setSkillName("c");
		skill.setSkillName("java");
		skills.add(skill);
		user.setUserSkills(skills);
		try {
			userDaoImpl.addUser(user);
		} catch (MetaSkillFinderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		endorse.setEndorseId(1);
		endorse.setUserSkillId(1);
		endorse.setEndorsedUserId(1);
		endorse.setEndorserUserId(2);
		
	}

	/**
	 * to test the method that adds user endorse object in table
	 */
	@Test
	public void testEndorse() {
		try {
			endorseDaoImpl.addEndorsement(endorse);
		} catch (MetaSkillFinderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertNotNull(sessionFactory.getCurrentSession().createCriteria(Endorse.class).add(Restrictions.eq("userSkillId", 1)).add(Restrictions.eq("endorsedUserId",1)).list().size());
	}

	

	/**
	 * to test the method that get user object from table by email
	 */	
	@Test
	public void testGetUser() {
		String email= "ankur.gupta@metacube.com";
		try {
			assertEquals(email, userDaoImpl.getUser(email).getEmail());
		} catch (MetaSkillFinderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 	Set User attributes after test case executed
	 */
	@After
	public void tearDown() {
		user = null;
		endorse = null;
		skill=null;
	}
}



