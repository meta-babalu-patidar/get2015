package TestCases;

import static org.junit.Assert.assertNotNull;
import java.util.HashSet;
import java.util.Set;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import com.meta.skillfinder.model.Skill;
import com.meta.skillfinder.model.User;
import com.meta.skillfinder.service.SkillService;
import com.meta.skillfinder.service.UserService;
import com.meta.skillfinder.service.impl.SkillServiceImpl;
import com.meta.skillfinder.service.impl.UserServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)

@ContextConfiguration(locations={"file:WebContent/WEB-INF/config/SkillFinder-servlet.xml"})

public class SkillServiceTest {

	@Autowired(required=false)
	private User user = new User();
	@Autowired(required=false)
	private SkillService skillServiceImpl = new SkillServiceImpl();
	@Autowired(required=false)
	private UserService userServiceImpl = new UserServiceImpl();
	@Autowired(required=false)
	private Skill skill = new Skill();
	@Autowired(required=false)
	private SessionFactory sessionFactory;



	/**
	 * 	Set User attributes before test case start executing
	 */
	@Before
	public void setUp() {
		user.setUserId(1);
		user.setGiven_name("Ankur");
		user.setEmail("ankur.gupta@metacube.com");
		Set<Skill> skills = new HashSet<Skill>();
		skill.setSkillId(1);
		skill.setSkillName("c");
		skill.setSkillName("c");
		skills.add(skill);
		user.setUserSkills(skills);
		userServiceImpl.addUser(user);
	}
	
	/**
	 * to test the method that adds user skills object in table
	 */

	@Test
	public void testSkills() {
		
		assertNotNull(sessionFactory.getCurrentSession().createCriteria(Skill.class).add(Restrictions.eq("SkillId", 1)).list().size());
	}
	
	/**
	 * to test the method that adds user skill by id object in table
	 */

	@Test
	public void testSkillsId() {
		
		assertNotNull(sessionFactory.getCurrentSession().createCriteria(Skill.class).add(Restrictions.eq("skillName", "c")).uniqueResult());
	}
		
	/**
	 * 	Set User attributes after test case executed
	 */
	@After
	public void tearDown() {
		user = null;
		skill = null;
	}


}
