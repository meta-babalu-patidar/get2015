package TestCases;

import static org.junit.Assert.*;

import org.hibernate.criterion.Restrictions;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.hibernate.SessionFactory;

import com.meta.skillfinder.dao.ExperienceDao;
import com.meta.skillfinder.dao.UserDao;
import com.meta.skillfinder.dao.impl.UserDaoImpl;
import com.meta.skillfinder.model.User;
import com.meta.skillfinder.dao.impl.ExperienceDaoImpl;
import com.meta.skillfinder.model.Experience;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"file:WebContent/WEB-INF/config/SkillFinder-servlet.xml"})

public class ExperienceDaoImplTest {


	@Autowired(required=false)
	private User user = new User();
	@Autowired(required=false)
	private ExperienceDao experienceDaoImpl = new ExperienceDaoImpl();
	@Autowired(required=false)
	private UserDao userDaoImpl = new UserDaoImpl();
	@Autowired(required=false)
	private Experience experience = new Experience();
	@Autowired(required=false)
	private SessionFactory sessionFactory;



	/**
	 * 	Set User attributes before test case start executing
	 */
	@Before
	public void setUp() {
		user.setContactId(1);
		user.setUserId(1);
		user.setGiven_name("Ankur");
		user.setEmail("ankur.gupta@metacube.com");
		userDaoImpl.addUser(user);
		experience.setExperienceId(1);
		experience.setUserId(1);
		experience.setCompanyName("abc");
		experience.setLocation("jaipur");
		experience.setDescription("d");

	}

	/**
	 * to test the method that adds user object in table
	 */
	@Test
	public void testExperience() {
		experienceDaoImpl.addUserExperience(experience);
		assertNotNull(sessionFactory.getCurrentSession().createCriteria(Experience.class).add(Restrictions.eq("userId", 1)).list().size());
	}

	/**
	 * to test the method that delete experience object in table
	 */

	@Test
	public void testDeleteExperience() {
		experienceDaoImpl.addUserExperience(experience);
		assertNotNull(sessionFactory.getCurrentSession().createCriteria(Experience.class).add(Restrictions.eq("userId", 1)).list().size());
		experienceDaoImpl.deleteExperience(1);
		assertNull(sessionFactory.getCurrentSession().createCriteria(Experience.class).add(Restrictions.eq("userId", 1)).list().size());
	}

	/**
	 * to test the method that get user object from table by email
	 */	
	@Test
	public void testGetUser() {
		String email= "ankur.gupta@metacube.com";
		assertEquals(email, userDaoImpl.getUser(email).getEmail());
	}

	/**
	 * 	Set User attributes after test case executed
	 */
	@After
	public void tearDown() {
		user = null;
		experience = null;
	}
}



