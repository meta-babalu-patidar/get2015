package TestCases;

import static org.junit.Assert.*;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import com.meta.skillfinder.model.Qualification;
import com.meta.skillfinder.model.Skill;
import com.meta.skillfinder.model.User;
import com.meta.skillfinder.service.QualificationService;
import com.meta.skillfinder.service.UserService;
import com.meta.skillfinder.service.impl.QualificationServiceImpl;
import com.meta.skillfinder.service.impl.UserServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)

@ContextConfiguration(locations={"file:WebContent/WEB-INF/config/SkillFinder-servlet.xml"})

public class QualificationServiceTest{

	@Autowired(required=false)
	private User user = new User();
	@Autowired(required=false)
	private QualificationService qualificationServiceImpl = new QualificationServiceImpl();
	@Autowired(required=false)
	private UserService userService = new UserServiceImpl();
	@Autowired(required=false)
	private Qualification qualification = new Qualification();
	@Autowired(required=false)
	private SessionFactory sessionFactory;



	/**
	 * 	Set User attributes before test case start executing
	 */
	@Before
	public void setUp() {
		user.setUserId(1);
		user.setGiven_name("Ankur");
		user.setEmail("ankur.gupta@metacube.com");
		userService.addUser(user);
		qualification.setUserId(1);
		qualification.setQualificationId(1);
		qualification.setInstitution("metacube");
		qualificationServiceImpl.addUserQualification(qualification);
		
	}

	/**
	 * to test the method that adds user qualification object in table
	 */

	@Test
	public void testQualification() {

		assertNotNull(sessionFactory.getCurrentSession().createCriteria(Qualification.class).add(Restrictions.eq("userId", 1)).list());
	}

	/**
	 * to test the method that adds user qualification object in table
	 */

	@Test
	public void testSkillsId() {

		assertNotNull(sessionFactory.getCurrentSession().createCriteria(Skill.class).add(Restrictions.eq("skillName", "c")).uniqueResult());
	}

	/**
	 * to test the method that delete qualification object in table
	 */

	@Test
	public void testDeleteQualification() {
		
		qualificationServiceImpl.deleteQualification(1);
		assertNull(sessionFactory.getCurrentSession().createCriteria(Qualification.class).add(Restrictions.eq("qualificationId", 1)).list().size());
	}
	
	/**
	 * 	Set User attributes after test case executed
	 */
	@After
	public void tearDown() {
		user = null;
		qualification = null;
	}


}

