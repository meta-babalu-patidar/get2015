/**
 * 
 */
package com.meta.skillfinder.helper;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.meta.skillfinder.bean.CertificateBean;
import com.meta.skillfinder.model.Certificate;

/**
 * @author Kajal
 *
 */
@Component("certificateHelper")
public class CertificateHelper {

	public List<CertificateBean> prepareCertificateBeanList(List<Certificate> certificateList) {
		List<CertificateBean> certificateBeanList = new ArrayList<CertificateBean>();
		for (Certificate certificate : certificateList)
		{
			CertificateBean certificateBean = new CertificateBean();
			certificateBean.setCertificateName(certificate.getCertificateName());
			certificateBean.setIssuingAuthorithy(certificate.getIssuingAuthorithy());
			certificateBean.setIssuingDate(certificate.getIssuingDate());
			certificateBean.setCertificateId(certificate.getCertificateId());
			certificateBean.setUserId(certificate.getUserId());
			java.util.Date date = new java.util.Date();
			certificateBean.setLastUpdated(new Timestamp(date.getTime()));
			certificateBean.setCreatedTime(certificate.getCreatedTime());
			certificateBeanList.add(certificateBean);
		}
		return certificateBeanList;
	}
	
	public Certificate prepareCertificateModel(CertificateBean certificateBean) {
		Certificate certificate = new Certificate();
		certificate.setCertificateName(certificateBean.getCertificateName());
		certificate.setIssuingAuthorithy(certificateBean.getIssuingAuthorithy());
		certificate.setIssuingDate(certificateBean.getIssuingDate());
		certificate.setCertificateId(certificateBean.getCertificateId());
		certificate.setUserId(certificateBean.getUserId());
		java.util.Date date = new java.util.Date();
		certificate.setLastUpdated(new Timestamp(date.getTime()));
		certificate.setCreatedTime(certificateBean.getCreatedTime());
		return certificate;
	}
}
