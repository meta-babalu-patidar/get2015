/**
 * 
 */
package com.meta.skillfinder.helper;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.meta.skillfinder.bean.QualificationBean;
import com.meta.skillfinder.model.Qualification;
import com.meta.skillfinder.util.Qualifications;

/**
 * @author Kajal
 *
 */
@Component("qualificationHelper")
public class QualificationHelper {

	public Qualification prepareQualificationModel(
			QualificationBean qualificationBean) {
		Qualification qualification = new Qualification();
		qualification.setDescription(qualificationBean.getDescription());
		qualification.setInstitution(qualificationBean.getInstitution());
		qualification.setObtainingYear(qualificationBean.getObtainingYear());
		qualification
				.setQualificationEarned(Qualifications
						.valueOf(qualificationBean.getQualificationEarned()
								.toString()));
		qualification.setCreatedTime(qualificationBean.getCreatedTime());
		java.util.Date date = new java.util.Date();
		qualification.setLastUpdated(new Timestamp(date.getTime()));
		qualification
				.setQualificationId(qualificationBean.getQualificationId());
		qualification.setUpdatedFields(qualificationBean.getUpdatedFields());
		qualification.setUserId(qualificationBean.getQualificationId());
		return qualification;
	}

	public QualificationBean prepareQualificationBean(
			Qualification qualification) {
		QualificationBean qualificationBean = new QualificationBean();
		qualificationBean.setQualificationEarned(Qualifications
				.valueOf(qualification.getQualificationEarned().toString()));
		qualificationBean.setDescription(qualification.getDescription());
		qualificationBean.setInstitution(qualification.getInstitution());
		qualificationBean.setObtainingYear(qualification.getObtainingYear());
		qualificationBean.setCreatedTime(qualification.getCreatedTime());
		java.util.Date date = new java.util.Date();
		qualificationBean.setLastUpdated(new Timestamp(date.getTime()));
		qualificationBean
				.setQualificationId(qualification.getQualificationId());
		qualificationBean.setUpdatedFields(qualification.getUpdatedFields());
		qualificationBean.setUserId(qualification.getQualificationId());
		return qualificationBean;
	}

	public List<QualificationBean> prepareQualificationBeanList(
			List<Qualification> qualificationList) {
		List<QualificationBean> qualificationBeanList = new ArrayList<QualificationBean>();
		for (Qualification qualification : qualificationList) {
			QualificationBean qualificationBean = new QualificationBean();
			qualificationBean
					.setQualificationEarned(Qualifications
							.valueOf(qualification.getQualificationEarned()
									.toString()));
			qualificationBean.setDescription(qualification.getDescription());
			qualificationBean.setInstitution(qualification.getInstitution());
			qualificationBean.setObtainingYear(qualification.getObtainingYear());
			qualificationBean.setCreatedTime(qualification.getCreatedTime());
			java.util.Date date = new java.util.Date();
			qualificationBean.setLastUpdated(new Timestamp(date.getTime()));
			qualificationBean.setQualificationId(qualification
					.getQualificationId());
			qualificationBean
					.setUpdatedFields(qualification.getUpdatedFields());
			qualificationBean.setUserId(qualification.getQualificationId());

			qualificationBeanList.add(qualificationBean);
		}
		return qualificationBeanList;
	}

}
