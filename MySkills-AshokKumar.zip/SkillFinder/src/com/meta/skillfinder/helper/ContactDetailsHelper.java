/**
 * 
 */
package com.meta.skillfinder.helper;

import java.sql.Timestamp;

import org.springframework.stereotype.Component;

import com.meta.skillfinder.bean.ContactDetailsBean;
import com.meta.skillfinder.model.ContactDetails;

/**
 * @author Kajal
 *
 */
@Component("contactDetailsHelper")
public class ContactDetailsHelper {

	public ContactDetailsBean prepareContactDetailsBean(
			ContactDetails contactDetails) {
		ContactDetailsBean contactDetailsBean = new ContactDetailsBean();
		contactDetailsBean.setAddress(contactDetails.getAddress());
		contactDetailsBean.setCountry(contactDetails.getCountry());
		contactDetailsBean.setState(contactDetails.getState());
		contactDetailsBean.setPincode(contactDetails.getPincode());
		contactDetailsBean.setPhoneNumber(contactDetails.getPhoneNumber());
		contactDetailsBean.setContactId(contactDetails.getContactId());
		contactDetailsBean.setCreatedTime(contactDetails.getCreatedTime());
		java.util.Date date = new java.util.Date();
		contactDetailsBean.setLastUpdated(new Timestamp(date.getTime()));
		contactDetailsBean.setUpdatedFields(contactDetails.getUpdatedFields());
		return contactDetailsBean;
	}
	
	public ContactDetails prepareContactDetailsModel(ContactDetailsBean contactDetailsBean){
		ContactDetails contactDetails = new ContactDetails();
		contactDetails.setAddress(contactDetailsBean.getAddress());
		contactDetails.setState(contactDetailsBean.getState());
		contactDetails.setCountry(contactDetailsBean.getCountry());
		contactDetails.setPincode(contactDetailsBean.getPincode());
		contactDetails.setPhoneNumber(contactDetailsBean.getPhoneNumber());
		contactDetails.setContactId(contactDetailsBean.getContactId());
		contactDetails.setCreatedTime(contactDetailsBean.getCreatedTime());
		java.util.Date date= new java.util.Date();
		contactDetails.setLastUpdated(new Timestamp(date.getTime()));
		contactDetails.setUpdatedFields(contactDetailsBean.getUpdatedFields());
		return contactDetails;
	}
	
}
