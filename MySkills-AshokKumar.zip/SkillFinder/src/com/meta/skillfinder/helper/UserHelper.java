/**
 * 
 */
package com.meta.skillfinder.helper;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.meta.skillfinder.bean.ExperienceBean;
import com.meta.skillfinder.bean.UserBean;
import com.meta.skillfinder.model.Experience;
import com.meta.skillfinder.model.User;
import com.meta.skillfinder.util.Gender;

/**
 * @author Kajal
 *
 */
@Component("userHelper")
public class UserHelper {

	public User prepareModel(UserBean userBean) {
		User user = new User();
		user.setGiven_name(userBean.getFirstName());
		user.setMiddleName(userBean.getMiddleName());
		user.setFamily_name(userBean.getLastName());
		user.setStatus(userBean.getStatus());
		user.setDateOfBirth(userBean.getDateOfBirth());
		user.setContactId(userBean.getContactId());
		user.setCreatedTime(userBean.getCreatedTime());
		user.setCurrentCompany(userBean.getCurrentCompany());
		user.setDateOfJoining(userBean.getDateOfJoining());
		user.setDepartment(userBean.getDepartment());
		user.setEmail(userBean.getEmailId());
		//user.setGender(Gender.valueOf(userBean.getGender().toString())); 
		user.setGender(userBean.getGender()); 
		java.util.Date date= new java.util.Date();
		user.setLastUpdated(new Timestamp(date.getTime()));
		user.setPassword(userBean.getPassword());
		user.setPicture(userBean.getPicture());
		user.setPost(userBean.getPost());
		user.setProfessionalHeadline(userBean.getProfessionalHeadline());
		user.setProfessionalSummary(userBean.getProfessionalSummary());
		user.setUpdatedFields(userBean.getUpdatedFields());
		user.setUserId(userBean.getUserId());
		user.setValidity(userBean.getValidity());
		return user;
	}
	
	public UserBean prepareUserBean(User user) {
		UserBean userBean = new UserBean();
		userBean.setEmailId(user.getEmail());
		userBean.setPassword(user.getPassword());
		userBean.setFirstName(user.getGiven_name());
		userBean.setProfessionalHeadline(user.getProfessionalHeadline());
		userBean.setMiddleName(user.getMiddleName());
		userBean.setLastName(user.getFamily_name());
		userBean.setStatus(user.getStatus());
		userBean.setDateOfBirth(user.getDateOfBirth());
		userBean.setContactId(user.getContactId());
		userBean.setCreatedTime(user.getCreatedTime());
		userBean.setCurrentCompany(user.getCurrentCompany());
		userBean.setDateOfJoining(user.getDateOfJoining());
		userBean.setDepartment(user.getDepartment());
		//userBean.setGender(Gender.valueOf(user.getGender().toString()));   
		userBean.setGender(user.getGender()); 
		java.util.Date date= new java.util.Date();
		userBean.setLastUpdated(new Timestamp(date.getTime()));
		userBean.setPicture(user.getPicture());
		userBean.setPost(user.getPost());
		userBean.setProfessionalSummary(user.getProfessionalSummary());
		userBean.setUpdatedFields(user.getUpdatedFields());
		userBean.setUserId(user.getUserId());
		userBean.setValidity(user.getValidity());
		return userBean;
	}
	
	public List<UserBean> prepareUserBeanList(List<User> userList) {
		List<UserBean> userBeanList = new ArrayList<UserBean>();
		for (User user : userList)
		{
			UserBean userBean = new UserBean();
			userBean.setEmailId(user.getEmail());
			userBean.setPassword(user.getPassword());
			userBean.setFirstName(user.getGiven_name());
			userBean.setProfessionalHeadline(user.getProfessionalHeadline());
			userBean.setMiddleName(user.getMiddleName());
			userBean.setLastName(user.getFamily_name());
			userBean.setStatus(user.getStatus());
			userBean.setDateOfBirth(user.getDateOfBirth());
			userBean.setContactId(user.getContactId());
			userBean.setCreatedTime(user.getCreatedTime());
			userBean.setCurrentCompany(user.getCurrentCompany());
			userBean.setDateOfJoining(user.getDateOfJoining());
			userBean.setDepartment(user.getDepartment());
			//user.setGender(gender);   ?????????????????????????????????????????
			java.util.Date date= new java.util.Date();
			userBean.setLastUpdated(new Timestamp(date.getTime()));
			userBean.setPicture(user.getPicture());
			userBean.setPost(user.getPost());
			userBean.setProfessionalSummary(user.getProfessionalSummary());
			userBean.setUpdatedFields(user.getUpdatedFields());
			userBean.setUserId(user.getUserId());
			userBean.setValidity(user.getValidity());
			userBeanList.add(userBean);
		}
		return userBeanList;
	}
	
}
