/**
 * 
 */
package com.meta.skillfinder.helper;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Component;



import com.meta.skillfinder.bean.ExperienceBean;
import com.meta.skillfinder.model.Experience;

/**
 * @author Kajal
 *
 */
@Component("experienceHelper")
public class ExperienceHelper {

	SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
	public List<ExperienceBean> prepareExperienceBeanList(List<Experience> experienceList) {
		List<ExperienceBean> experienceBeanList = new ArrayList<ExperienceBean>();
		for (Experience experience : experienceList)
		{
			ExperienceBean experienceBean = new ExperienceBean();
			experienceBean.setCompanyName(experience.getCompanyName());
			experienceBean.setExperienceDescription(experience.getExperienceDescription());
			experienceBean.setLocation(experience.getLocation());
			experienceBean.setTitle(experience.getTitle());
			
			experienceBean.setJoiningDate(experience.getJoiningDate()); 
			experienceBean.setRelieveDate(experience.getRelieveDate());
			experienceBean.setExperienceId(experience.getExperienceId());
			experienceBean.setCreatedTime(experience.getCreatedTime());
			java.util.Date date= new java.util.Date();
			experienceBean.setLastUpdated(new Timestamp(date.getTime()));
			experienceBean.setUpdatedFields(experience.getUpdatedFields());
			experienceBean.setUserId(experience.getUserId());
			System.out.println("pop id"+experienceBean.getExperienceId());
			experienceBeanList.add(experienceBean);
		}
		return experienceBeanList;
	}
	
	public Experience prepareExperienceModel(ExperienceBean experienceBean) {
		Experience experience = new Experience();
		experience.setCompanyName(experienceBean.getCompanyName());
		experience.setExperienceDescription(experienceBean.getExperienceDescription());
		experience.setLocation(experienceBean.getLocation());
		experience.setTitle(experienceBean.getTitle());
//		Date joiningDate = formatter.parse(experienceBean.getJoiningDate());
//		experience.setJoiningDate(joiningDate);
//		Date relieveDate = formatter.parse(experienceBean.getRelieveDate());
//		experience.setRelieveDate(relieveDate);
		experience.setJoiningDate(experienceBean.getJoiningDate());
		experience.setRelieveDate(experienceBean.getRelieveDate());
		experience.setCreatedTime(experienceBean.getCreatedTime());
		experience.setExperienceId(experienceBean.getExperienceId());
		java.util.Date date= new java.util.Date();
		experience.setLastUpdated(new Timestamp(date.getTime()));
		experience.setUpdatedFields(experienceBean.getUpdatedFields());
		experience.setUserId(experienceBean.getUserId());
		return experience;
	}
}
