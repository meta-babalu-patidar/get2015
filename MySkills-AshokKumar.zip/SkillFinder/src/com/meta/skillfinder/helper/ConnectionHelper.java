/**
 * 
 */
package com.meta.skillfinder.helper;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.meta.skillfinder.bean.ConnectionBean;
import com.meta.skillfinder.bean.ContactDetailsBean;
import com.meta.skillfinder.model.Connection;
import com.meta.skillfinder.model.ContactDetails;

/**
 * @author Kajal
 *
 */
@Component("connectionHelper")
public class ConnectionHelper {

	public Connection prepareConnectionModel(ConnectionBean connectionBean) {
        Connection connection = new Connection();
        connection.setConnectionId(connectionBean.getConnectionId());
        connection.setUserId(connectionBean.getUserId());
        connection.setConnectionTime(connectionBean.getConnectionTime());
        connection.setCreatedTime(connectionBean.getCreatedTime());
        connection.setConnectionUserId(connectionBean.getConnectionUserId());
        //java.util.Date date= new java.util.Date();
        //experience.setLastUpdated(new Timestamp(date.getTime()));
        return connection;
    }

    public List<ConnectionBean> prepareConnectionBeanList(List<Connection> connectionList) {
        List<ConnectionBean> connectionBeanList = new ArrayList<ConnectionBean>();
        for (Connection connection : connectionList) {
            ConnectionBean connectionBean = new ConnectionBean();
            connectionBean.setConnectionId(connection.getConnectionId());
            connectionBean.setUserId(connection.getUserId());
            connectionBean.setConnectionTime(connection.getConnectionTime());
            connectionBean.setCreatedTime(connection.getCreatedTime());
            connectionBean.setConnectionUserId(connection.getConnectionUserId());
            connectionBeanList.add(connectionBean);
        }
        return connectionBeanList;
    }
	
}
