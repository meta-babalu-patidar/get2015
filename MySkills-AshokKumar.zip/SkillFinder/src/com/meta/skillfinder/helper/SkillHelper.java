/**
 * 
 */
package com.meta.skillfinder.helper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.meta.skillfinder.bean.SkillBean;
import com.meta.skillfinder.model.Skill;

/**
 * @author Kajal
 *
 */
@Component("skillHelper")
public class SkillHelper {

	public List<SkillBean> prepareUserSkillBeanList (List<Skill> userSkillList) {
		List<SkillBean> skillBeanList = new ArrayList<SkillBean>();
		for (Skill skill : userSkillList) {
			SkillBean skillBean = new SkillBean();
			skillBean.setSkillName(skill.getSkillName());
			skillBean.setSkillId(skill.getSkillId());
			skillBeanList.add(skillBean);
		}
		return skillBeanList;
	}
	
	public Skill prepareSkillModel(SkillBean skillBean) {
		Skill skill = new Skill();
		skill.setSkillId(skillBean.getSkillId());
		skill.setSkillName(skillBean.getSkillName());
		return skill;
	}

}
