//
///**
// * @author Kajal
// *
// */
//
//package com.meta.skillfinder.model;
//
//import java.sql.Timestamp;
//
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.Table;
//
//import lombok.Data;
//
////@Data
////@Entity
////@Table (name="user_skill")
////public class UserSkill {
////	
////	@Id
////	@GeneratedValue(strategy=GenerationType.AUTO)
////	@Column(name = "skillId")
////	private int skillId;
////	
////	@Id
////	@GeneratedValue(strategy=GenerationType.AUTO)
////	@Column(name = "userId")
////	private int userId;
//}
