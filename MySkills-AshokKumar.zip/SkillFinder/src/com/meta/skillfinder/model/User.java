/**
 * @model  CertificateModel
 * @since  27th November 15
 * This Model is used to mapping between entity and table
 */

package com.meta.skillfinder.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import lombok.Data;
import com.meta.skillfinder.util.Gender;
import com.meta.skillfinder.util.Valid;

/**
 * @Entity This annotation Specifies that the class is an entity
 * @Table This annotation specifies the primary table for the annotated entity
 */

@Data
@Entity
@Table(name="user")
public class User implements Serializable{

	private static final long serialVersionUID = -723583058586873479L;

	/**
	 * @Id primary key of an entity
	 * @GeneratedValue Provides for the specification of generation strategies for the values of primary keys
	 * @Column Is used to specify a mapped column for a persistent property or field
	 */

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "user_id")
	private Integer userId;

	@Column(name = "validity")
	private Valid validity;

	@Column(name = "first_name")
	private String given_name;

	@Column(name = "middle_name")
	private String middleName;

	@Column(name = "last_name")
	private String family_name;

	@Column(name = "date_of_joining")
	private Timestamp dateOfJoining;

	@Column(name = "date_of_birth")
	private Date dateOfBirth;

	@Column(name = "gender")
	private Gender gender;

	@Column(name = "contact_id")
	private Integer contactId;

	@Column(name = "email_id")
	private String email;

	@Column(name = "password")
	private String password;

	@Column(name = "status")
	private String status;

	@Column(name = "current_company")
	private String currentCompany;

	@Column(name = "department")
	private String department;

	@Column(name = "post")
	private String post;

	@Column(name = "profile_photo")
	private String picture;

	@Column(name = "professional_headline")
	private String professionalHeadline;

	@Column(name = "professional_summary")
	private String professionalSummary;

	@ManyToMany(fetch=FetchType.EAGER, cascade=CascadeType.ALL)
	@JoinTable( name="user_skill", 
	joinColumns={@JoinColumn(name="userId")},
	inverseJoinColumns={@JoinColumn(name="skillId")}
			)
	private Set<Skill> userSkills;
	
	@Column(name = "created_time",columnDefinition = "TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP") 
	private Timestamp createdTime;

	
	@Column(name = "last_updated")
	private Timestamp lastUpdated;

	
	@Column(name = "updated_fields")
	private String updatedFields;

	/**
	 * @param dateOfJoining
	 * @param lastUpdated
	 */
	public User() {
		super();	
		java.util.Date date= new java.util.Date();
		this.dateOfJoining = new Timestamp(date.getTime());
		this.lastUpdated = new Timestamp(date.getTime());
	}

	/**
	 * it implements equals for user entity
	 * @ovveride equals()
	 */

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		if (contactId == null) {
			if (other.contactId != null)
				return false;
		} else if (!contactId.equals(other.contactId))
			return false;
		if (createdTime == null) {
			if (other.createdTime != null)
				return false;
		} else if (!createdTime.equals(other.createdTime))
			return false;
		if (currentCompany == null) {
			if (other.currentCompany != null)
				return false;
		} else if (!currentCompany.equals(other.currentCompany))
			return false;
		if (dateOfBirth == null) {
			if (other.dateOfBirth != null)
				return false;
		} else if (!dateOfBirth.equals(other.dateOfBirth))
			return false;
		if (dateOfJoining == null) {
			if (other.dateOfJoining != null)
				return false;
		} else if (!dateOfJoining.equals(other.dateOfJoining))
			return false;
		if (department == null) {
			if (other.department != null)
				return false;
		} else if (!department.equals(other.department))
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (family_name == null) {
			if (other.family_name != null)
				return false;
		} else if (!family_name.equals(other.family_name))
			return false;
		if (gender != other.gender)
			return false;
		if (given_name == null) {
			if (other.given_name != null)
				return false;
		} else if (!given_name.equals(other.given_name))
			return false;
		if (lastUpdated == null) {
			if (other.lastUpdated != null)
				return false;
		} else if (!lastUpdated.equals(other.lastUpdated))
			return false;
		if (middleName == null) {
			if (other.middleName != null)
				return false;
		} else if (!middleName.equals(other.middleName))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		if (picture == null) {
			if (other.picture != null)
				return false;
		} else if (!picture.equals(other.picture))
			return false;
		if (post == null) {
			if (other.post != null)
				return false;
		} else if (!post.equals(other.post))
			return false;
		if (professionalHeadline == null) {
			if (other.professionalHeadline != null)
				return false;
		} else if (!professionalHeadline.equals(other.professionalHeadline))
			return false;
		if (professionalSummary == null) {
			if (other.professionalSummary != null)
				return false;
		} else if (!professionalSummary.equals(other.professionalSummary))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		if (updatedFields == null) {
			if (other.updatedFields != null)
				return false;
		} else if (!updatedFields.equals(other.updatedFields))
			return false;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!userId.equals(other.userId))
			return false;
		if (validity != other.validity)
			return false;
		return true;
	}

	/**
	 * it implements hash code for user entity
	 * @override hashCode()
	 */

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((contactId == null) ? 0 : contactId.hashCode());
		result = prime * result
				+ ((createdTime == null) ? 0 : createdTime.hashCode());
		result = prime * result
				+ ((currentCompany == null) ? 0 : currentCompany.hashCode());
		result = prime * result
				+ ((dateOfBirth == null) ? 0 : dateOfBirth.hashCode());
		result = prime * result
				+ ((dateOfJoining == null) ? 0 : dateOfJoining.hashCode());
		result = prime * result
				+ ((department == null) ? 0 : department.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result
				+ ((family_name == null) ? 0 : family_name.hashCode());
		result = prime * result + ((gender == null) ? 0 : gender.hashCode());
		result = prime * result
				+ ((given_name == null) ? 0 : given_name.hashCode());
		result = prime * result
				+ ((lastUpdated == null) ? 0 : lastUpdated.hashCode());
		result = prime * result
				+ ((middleName == null) ? 0 : middleName.hashCode());
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		result = prime * result + ((picture == null) ? 0 : picture.hashCode());
		result = prime * result + ((post == null) ? 0 : post.hashCode());
		result = prime
				* result
				+ ((professionalHeadline == null) ? 0 : professionalHeadline
						.hashCode());
		result = prime
				* result
				+ ((professionalSummary == null) ? 0 : professionalSummary
						.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result
				+ ((updatedFields == null) ? 0 : updatedFields.hashCode());
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		result = prime * result + ((validity == null) ? 0 : validity.hashCode());
		return result;
	}
}
