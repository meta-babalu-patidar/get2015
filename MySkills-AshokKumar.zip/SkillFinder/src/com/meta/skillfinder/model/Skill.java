
/**
 * @model  CertificateModel
 * @since  27th November 15
 * This Model is used to mapping between entity and table
 */

package com.meta.skillfinder.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

/**
 * @Entity This annotation Specifies that the class is an entity
 * @Table This annotation specifies the primary table for the annotated entity
 */

@Data
@Entity
@Table(name="skill")
public class Skill implements Serializable{

	private static final long serialVersionUID = -723583058586873479L;

	/**
	 * @Id primary key of an entity
	 * @GeneratedValue Provides for the specification of generation strategies for the values of primary keys
	 * @Column Is used to specify a mapped column for a persistent property or field
	 */

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "skill_id")
	private int skillId;

	@Column(name = "skill_name")
	private String skillName;

	/**
	 * it implements equals for user entity
	 * @override equals()
	 */

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Skill other = (Skill) obj;
		if (skillId != other.skillId)
			return false;
		if (skillName == null) {
			if (other.skillName != null)
				return false;
		} else if (!skillName.equals(other.skillName))
			return false;
		return true;
	}

	/**
	 * it implements hashCode for user entity
	 * @override hashCode()
	 */

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + skillId;
		result = prime * result
				+ ((skillName == null) ? 0 : skillName.hashCode());
		return result;
	}
}
