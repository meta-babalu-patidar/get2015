/**
 * @model  CertificateModel
 * @since  27th November 15
 * This Model is used to mapping between entity and table
 */

package com.meta.skillfinder.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import com.meta.skillfinder.util.Qualifications;
import lombok.Data;

/**
 * @Entity This annotation Specifies that the class is an entity
 * @Table This annotation specifies the primary table for the annotated entity
 */

@Data
@Entity
@Table(name="qualification")
public class Qualification implements Serializable{

	private static final long serialVersionUID = -723583058586873479L;
	
	/**
	 * @Id primary key of an entity
	 * @GeneratedValue Provides for the specification of generation strategies for the values of primary keys
	 * @Column Is used to specify a mapped column for a persistent property or field
	 */

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "qualification_id")
	private int qualificationId;

	@Column(name = "user_id")
	private int userId;

	@Column(name = "institution")
	private String institution;

	@Column(name = "obtaining_year")
	private Date obtainingYear;

	@Column(name = "qualification_earned")
	private Qualifications qualificationEarned;

	@Column(name = "description")
	private String description;

	@Column(name = "created_time",columnDefinition = "TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP")
	private Timestamp createdTime;

	@Column(name = "last_updated")
	private Timestamp lastUpdated;

	@Column(name = "updated_fields")
	private String updatedFields;

	/**
	 * @param lastUpdated
	 */
	public Qualification() {
		super();	
		java.util.Date date= new java.util.Date();
		this.lastUpdated = new Timestamp(date.getTime());
	}
}
