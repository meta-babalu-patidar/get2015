
/**
 * @bean EndorseBean 
 * @since  27th November 15
 * This Bean initialize the variables related to the user Endorsement.
 * Bean is used to transfer data from user interface to controller
 */
package com.meta.skillfinder.bean;

import java.sql.Timestamp;

import lombok.Data;
/**
 * @Data It is lombok annotation 
 * It is used to automatically generate getter and setters for data members
 */
@Data
public class EndorseBean {
	private int endorseId;
	private int userSkillId;
	private int endorsedUSerId;
	private int endorserUserId;
	private int rating;
	private Timestamp createdTime;
	private Timestamp lastupdated;
}
