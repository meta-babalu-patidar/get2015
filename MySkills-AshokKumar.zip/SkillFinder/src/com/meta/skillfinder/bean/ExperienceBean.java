
/**
 * @bean ExperienceBean 
 * @since  27th November 15
 * This Bean initialize the variables related to the user Experience.
 * Bean is used to transfer data from user interface to controller
 */
package com.meta.skillfinder.bean;

import java.sql.Timestamp;
import java.util.Date;
import lombok.Data;
/**
 * @Data It is lombok annotation 
 * It is used to automatically generate getter and setters for data members
 */
@Data
public class ExperienceBean {
	private int experienceId;
	private int userId;
	private String companyName;
	private String title;
	private String location;
//	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private Date joiningDate;  
//	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private Date relieveDate;   
	private String experienceDescription;
	private Timestamp createdTime;;
	private Timestamp lastUpdated;
	private String updatedFields;
}
