/**
 * @bean CertificateBean 
 * @since  27th November 15
 * This Bean initialize the variables related to the user certification.
 * Bean is used to transfer data from user interface to controller
 */

package com.meta.skillfinder.bean;

import java.sql.Timestamp;
import java.util.Date;
import lombok.Data;
/**
 * @Data It is lombok annotation 
 * It is used to automatically generate getter and setters for data members
 */
@Data
public class CertificateBean {
	private int certificateId;
	private int userId;
	private String certificateName;
	private String issuingAuthorithy;
	private Date issuingDate;
	private Timestamp createdTime;
	private Timestamp lastUpdated;
} 
