/**
 * @bean ConnectionBean 
 * @since  27th November 15
 * This Bean initialize the variables related to the user Connections.
 * Bean is used to transfer data from user interface to controller
 */
package com.meta.skillfinder.bean;

import java.sql.Timestamp;
import lombok.Data;
/**
 * @Data It is lombok annotation 
 * It is used to automatically generate getter and setters for data members
 */
@Data
public class ConnectionBean {
	private int connectionId;
	private int userId;
	private int connectionUserId;
	private Timestamp  connectionTime;
	private Timestamp createdTime;
	private int requestStatus;
}

