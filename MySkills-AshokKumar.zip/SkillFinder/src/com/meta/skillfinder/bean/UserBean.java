
/**
 * @bean userBean 
 * @since  27th November 15
 * This Bean initialize the variables related to the user details
Bean is used to transfer data from user interface to controller
 */

package com.meta.skillfinder.bean;

import java.sql.Timestamp;
import java.util.Date;

import org.springframework.context.annotation.Scope;

import lombok.Data;

import com.meta.skillfinder.util.Gender;
import com.meta.skillfinder.util.Valid;
/**
 * @Data It is lombok annotation 
 * It is used to automatically generate getter and setters for data members
 */
@Data
@Scope("session")
public class UserBean {
	private int userId;		
	private Valid validity;
	private String firstName;
	private String middleName;
	private String lastName;
	private Timestamp dateOfJoining;
	private Date dateOfBirth;
	private Gender gender ;
	private int contactId;
	private String emailId;
	private String password;
	private String status;
	private String currentCompany;
	private String department;
	private String post;
	private String picture;    							// if we save pic on server and only stores it's location.
	private String professionalHeadline;
	private String professionalSummary;
	private Timestamp createdTime;
	private Timestamp lastUpdated;
	private String updatedFields;
}
