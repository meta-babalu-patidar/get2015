
/**
 * @bean SkillBean 
 * @since  27th November 15
 * This Bean initialize the variables related to the user Skill.
 * Bean is used to transfer data from user interface to controller
 */
package com.meta.skillfinder.bean;

import lombok.Data;
/**
 * @Data It is lombok annotation 
 * It is used to automatically generate getter and setters for data members
 */
@Data
public class SkillBean {
	private int skillId;
	private String skillName;
//	private String category;
}
