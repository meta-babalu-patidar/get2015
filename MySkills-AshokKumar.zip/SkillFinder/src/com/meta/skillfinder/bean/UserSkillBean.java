
/**
 * @bean UserSkillBean 
 * @since  27th November 15
 * This Bean initialize the variables related to the userSkills.
 * Bean is used to transfer data from user interface to controller
 */

package com.meta.skillfinder.bean;

import lombok.Data;
/**
 * @Data It is lombok annotation 
 * It is used to automatically generate getter and setters for data members
 */
@Data
public class UserSkillBean {
	private int skillId;
	private int userId;
}
