
/**
 * @class  EditProfileController
 * @since  30th november 15
 * This class implements the controller for connection. It contains all the 
 * connection related controllers.They fetch bean type objects from user interface
 * and process that data create view and model. 
 */

package com.meta.skillfinder.controller;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import com.meta.skillfinder.bean.CertificateBean;
import com.meta.skillfinder.bean.ContactDetailsBean;
import com.meta.skillfinder.bean.ExperienceBean;
import com.meta.skillfinder.bean.QualificationBean;
import com.meta.skillfinder.bean.UserBean;
import com.meta.skillfinder.exception.MetaSkillFinderException;
import com.meta.skillfinder.helper.CertificateHelper;
import com.meta.skillfinder.helper.ContactDetailsHelper;
import com.meta.skillfinder.helper.ExperienceHelper;
import com.meta.skillfinder.helper.QualificationHelper;
import com.meta.skillfinder.helper.UserHelper;
import com.meta.skillfinder.model.Certificate;
import com.meta.skillfinder.model.Experience;
import com.meta.skillfinder.model.Qualification;
import com.meta.skillfinder.model.Skill;
import com.meta.skillfinder.model.User;
import com.meta.skillfinder.model.ContactDetails;
import com.meta.skillfinder.util.Gender;
import com.meta.skillfinder.util.Qualifications;
import com.meta.skillfinder.service.CertificateService;
import com.meta.skillfinder.service.ContactDetailsService;
import com.meta.skillfinder.service.ExperienceService;
import com.meta.skillfinder.service.QualificationService;
import com.meta.skillfinder.service.SkillService;
import com.meta.skillfinder.service.UserService;


@Controller
@SessionAttributes("objOfUser")
public class EditProfileController {

	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private QualificationService qualificationService;
	
	/**
	 * Defining dependencies
	 */

	@Autowired
	private UserService userService;
	
	/**
	 * Defining dependencies
	 */

	@Autowired
	private ContactDetailsService contactDetailsService;
	
	/**
	 * Defining dependencies
	 */

	@Autowired
	private ExperienceService experienceService;
	
	/**
	 * Defining dependencies
	 */

	@Autowired
	private CertificateService certificateService;
	
	/**
	 * Defining dependencies
	 */

	@Autowired
	private ExperienceHelper experienceHelper;
	
	/**
	 * Defining dependencies
	 */

	@Autowired
	private QualificationHelper qualificationHelper;
	
	/**
	 * Defining dependencies
	 */

	@Autowired
	private UserHelper userHelper;
	
	/**
	 * Defining dependencies
	 */

	@Autowired
	private SkillService skillService;
	
	/**
	 * Defining dependencies
	 */

	@Autowired
	private ContactDetailsHelper contactDetailsHelper;
	
	/**
	 * Defining dependencies
	 */

	@Autowired
	private CertificateHelper certificateHelper;

	/**
	 * This function creates the view and model for the edit profile of a user who has logged in.
	 * @param{HttpServletRequest} request
	 * @param{@ModelAttribute("command") UserBean} sessionUserBean
	 * @param{@ModelAttribute("contactDetailsBean") ContactDetailsBean} contactDetailsBean
	 * @param{@ModelAttribute("experienceBean") ExperienceBean} experienceBean
	 * @param{@ModelAttribute("qualificationBean") QualificationBean} qualificationBean
	 * @param{@ModelAttribute("certificateBean") CertificateBean} certificateBean
	 * @return{ModelAndView} 
	 */
	
	@RequestMapping(value = "/editProfile", method = RequestMethod.GET)
	public ModelAndView welcome(
			HttpServletRequest request,
			@ModelAttribute("objOfUser") UserBean sessionUserBean,
			@ModelAttribute("contactDetailsBean") ContactDetailsBean contactDetailsBean,
			@ModelAttribute("experienceBean") ExperienceBean experienceBean,
			@ModelAttribute("qualificationBean") QualificationBean qualificationBean,
			@ModelAttribute("certificateBean") CertificateBean certificateBean,
			ModelMap model) {

		ModelAndView modelAndView = new ModelAndView();

		String emailId = sessionUserBean.getEmailId();
		
		User user;
		try {
			user = userService.getUser(emailId);
		} catch (MetaSkillFinderException e) {
			e.printStackTrace();
			model.addAttribute("message", e.getMessage());
			return new ModelAndView("Error");
		}
		
		UserBean userBean = userHelper.prepareUserBean(user);

		int contactId;
		try {
			contactId = userService.getContactDetailsId(user.getUserId());
		} catch (MetaSkillFinderException e) {
			e.printStackTrace();
			model.addAttribute("message", e.getMessage());
			return new ModelAndView("Error");
		}

		if (contactId != 0) {
			ContactDetails contactDetails;
			try {
				contactDetails = contactDetailsService
						.getContactDetails(contactId);
			} catch (MetaSkillFinderException e) {
				e.printStackTrace();
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
			contactDetailsBean = contactDetailsHelper
					.prepareContactDetailsBean(contactDetails);
		} else {
			contactDetailsBean = new ContactDetailsBean();
		}

		List<Experience> experienceList;
		try {
			experienceList = experienceService.getExperiences(user
					.getUserId());
		} catch (MetaSkillFinderException e) {
			e.printStackTrace();
			model.addAttribute("message", e.getMessage());
			return new ModelAndView("Error");
		}
		
		List<ExperienceBean> experienceBeanList = experienceHelper
				.prepareExperienceBeanList(experienceList);

		List<Qualification> qualificationList;
		try {
			qualificationList = qualificationService
					.getAllQualifications(user.getUserId());
		} catch (MetaSkillFinderException e) {
			e.printStackTrace();
			model.addAttribute("message", e.getMessage());
			return new ModelAndView("Error");
		}
		
		List<QualificationBean> qualificationBeanList = qualificationHelper
				.prepareQualificationBeanList(qualificationList);

		List<Certificate> certificateList;
		try {
			certificateList = certificateService
					.getAllCertificates(user.getUserId());
		} catch (MetaSkillFinderException e) {
			e.printStackTrace();
			model.addAttribute("message", e.getMessage());
			return new ModelAndView("Error");
		}
		
		List<CertificateBean> certificateBeanList = certificateHelper
				.prepareCertificateBeanList(certificateList);
		
		List<Skill> skillList;
		try {
			skillList = skillService.getAllSkills();
		} catch (MetaSkillFinderException e) {
			e.printStackTrace();
			model.addAttribute("message", e.getMessage());
			return new ModelAndView("Error");
		}
		
		model.addAttribute("listOfSkills", skillList);
		model.addAttribute("listOfQualification", qualificationBeanList);
		model.addAttribute("listOfExperience", experienceBeanList);
		model.addAttribute("contactDetailsBean", contactDetailsBean);
		model.addAttribute("objOfUser", userBean);
		model.addAttribute("listOfCertificate", certificateBeanList);
		model.addAttribute("genderEnum", Gender.values());
		model.addAttribute("qualificationEnum", Qualifications.values());
		model.addAttribute("message", "");
		modelAndView.addAllObjects(model);
		modelAndView.setViewName("EditProfile");
		return modelAndView;
	}

	/**
	 * This function creates the view and model for the edit profile after changing the personal details.
	 * @param{HttpServletRequest} request
	 * @param{@ModelAttribute("command") UserBean} sessionUserBean
	 * @return{ModelAndView} 
	 */
	
	@RequestMapping(value = "/editUser", method = RequestMethod.POST)
	public ModelAndView editUser(
			@ModelAttribute("objOfUser") UserBean sessionUserBean,
			BindingResult result, ModelMap model, HttpServletRequest request) {

		User user = userHelper.prepareModel(sessionUserBean);
		try {
			userService.addUser(user);
		} catch (MetaSkillFinderException e) {
			model.addAttribute("message", e.getMessage());
			return new ModelAndView("Error");
		}
		return new ModelAndView("redirect:/profile.html");
	}

	/**
	 * This function creates the view and model for the edit profile after changing the password details.
	 * @param{HttpServletRequest} request
	 * @param{@ModelAttribute("command") UserBean} sessionUserBean
	 * @return{ModelAndView} 
	 */
	
	@RequestMapping(value = "/changePassword", method = RequestMethod.POST)
	public ModelAndView changePassword(@ModelAttribute("objOfUser") UserBean sessionUserBean,
			BindingResult result, ModelMap model, HttpServletRequest request) {
		String returnPath = "";
		System.out.println("currdb"+sessionUserBean.getPassword()+"curr"+request.getParameter("currentPassword"));
		if(sessionUserBean.getPassword().equals(request.getParameter("currentPassword")))
		{
			sessionUserBean.setPassword(request.getParameter("newPassword"));
			User user = userHelper.prepareModel(sessionUserBean);
			try {
				userService.addUser(user);
			} catch (MetaSkillFinderException e) {
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
			returnPath = "redirect:/profile.html";
		}
		else
		{
			model.addAttribute("message", "Incorrect password");
			returnPath = "redirect:/editProfile.html";
		}
		return new ModelAndView(returnPath, model);
		
	}

	/**
	 * This function creates the view and model for the edit profile after changing the contact details.
	 * @param{HttpServletRequest} request
	 * @param{@ModelAttribute("command") UserBean} sessionUserBean
	 * @param{@ModelAttribute("contactDetailsBean") ContactDetailsBean} contactDetailsBean
	 * @return{ModelAndView} 
	 */
	
	@RequestMapping(value = "/editContactDetails", method = RequestMethod.POST)
	public ModelAndView editContactDetails(
			@ModelAttribute("contactDetailsBean") ContactDetailsBean contactDetailsBean,
			@ModelAttribute("objOfUser") UserBean sessionUserBean,
			BindingResult result, ModelMap model, HttpServletRequest request) {

		ContactDetails contactDetails = contactDetailsHelper
				.prepareContactDetailsModel(contactDetailsBean);
		int contactId = sessionUserBean.getContactId();
		if (contactId == 0) {
			int contactIdNew;
			try {
				contactIdNew = contactDetailsService
						.addContactDetails(contactDetails);
			} catch (MetaSkillFinderException e) {
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
			User user = userHelper.prepareModel(sessionUserBean);
			user.setContactId(contactIdNew);
			try {
				userService.addUser(user);
			} catch (MetaSkillFinderException e) {
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
		} else {
			contactDetails.setContactId(contactId);
			try {
				contactDetailsService.addContactDetails(contactDetails);
			} catch (MetaSkillFinderException e) {
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
		}
		return new ModelAndView("redirect:/profile.html");
	}

	/**
	 * This function creates the view and model for the edit profile after changing the personal details.
	 * @param{HttpServletRequest} request
	 * @param{@ModelAttribute("command") UserBean} sessionUserBean
	 * @param{@ModelAttribute("experienceBean") ExperienceBean} experienceBean
	 * @return{ModelAndView} 
	 */
	
	@RequestMapping(value = "/editExperience", method = RequestMethod.POST)
	public ModelAndView editExperience(
			@ModelAttribute("experienceBean") ExperienceBean experienceBean,
			@ModelAttribute("objOfUser") UserBean sessionUserBean,
			BindingResult result, ModelMap model, HttpServletRequest request) {

		int experienceId = Integer.parseInt(request
				.getParameter("experienceId"));
		
		Experience experience = experienceHelper
				.prepareExperienceModel(experienceBean);
		experience.setUserId(sessionUserBean.getUserId());
		experience.setExperienceId(experienceId);
		try {
			experienceService.addUserExperience(experience);
		} catch (MetaSkillFinderException e) {
			model.addAttribute("message", e.getMessage());
			return new ModelAndView("Error");
		}
		return new ModelAndView("redirect:/profile.html");
	}

	/**
	 * This function creates the view and model for the edit profile after deleting the experience.
	 * @param{HttpServletRequest} request
	 * @param{@ModelAttribute("command") UserBean} sessionUserBean
	 * @param{@ModelAttribute("experienceBean") ExperienceBean} experienceBean
	 * @return{ModelAndView} 
	 */
	
	@RequestMapping(value = "/deleteExperience", method = RequestMethod.GET)
	public ModelAndView deleteCertificate(
			@ModelAttribute("experienceBean") ExperienceBean experienceBean,
			@ModelAttribute("objOfUser") UserBean sessionUserBean,
			BindingResult result, ModelMap model, HttpServletRequest request) {

		int experienceId = Integer.parseInt(request
				.getParameter("experienceId"));
		try {
			experienceService.deleteExperience(experienceId);
		} catch (MetaSkillFinderException e) {
			model.addAttribute("message", e.getMessage());
			return new ModelAndView("Error");
		}
		return new ModelAndView("redirect:/profile.html");
	}
	
	/**
	 * This function creates the view and model for the edit profile after edting the qualification.
	 * @param{HttpServletRequest} request
	 * @param{@ModelAttribute("command") UserBean} sessionUserBean
	 * @param{@ModelAttribute("qualificationBean") QualificationBean} qualificationBean
	 * @return{ModelAndView} 
	 */

	@RequestMapping(value = "/editQualification", method = RequestMethod.POST)
	public ModelAndView editQualification(
			@ModelAttribute("qualificationBean") QualificationBean qualificationBean,
			@ModelAttribute("objOfUser") UserBean sessionUserBean,
			BindingResult result, ModelMap model, HttpServletRequest request) {

		int qualificationId = Integer.parseInt(request
				.getParameter("qualificationId"));
		System.out.println("qualificationId" + qualificationId);

		Qualification qualification = qualificationHelper
				.prepareQualificationModel(qualificationBean);
		qualification.setQualificationId(qualificationId);
		qualification.setUserId(sessionUserBean.getUserId());
		
		try {
			qualificationService.addUserQualification(qualification);
		} catch (MetaSkillFinderException e) {
			model.addAttribute("message", e.getMessage());
			return new ModelAndView("Error");
		}
		return new ModelAndView("redirect:/profile.html");
	}

	/**
	 * This function creates the view and model for the edit profile after deleting the qualification.
	 * @param{HttpServletRequest} request
	 * @param{@ModelAttribute("command") UserBean} sessionUserBean
	 * @param{@ModelAttribute("qualificationBean") QualificationBean} qualificationBean
	 * @return{ModelAndView} 
	 */
	
	@RequestMapping(value = "/deleteQualification", method = RequestMethod.GET)
	public ModelAndView deleteCertificate(
			@ModelAttribute("qualificationBean") QualificationBean qualificationBean,
			@ModelAttribute("objOfUser") UserBean sessionUserBean,
			BindingResult result, ModelMap model, HttpServletRequest request) {

		int qualificationId = Integer.parseInt(request
				.getParameter("qualificationId"));
		try {
			qualificationService.deleteQualification(qualificationId);
		} catch (MetaSkillFinderException e) {
			model.addAttribute("message", e.getMessage());
			return new ModelAndView("Error");
		}
		return new ModelAndView("redirect:/profile.html");
	}

	/**
	 * This function creates the view and model for the edit profile after editing the certificate.
	 * @param{HttpServletRequest} request
	 * @param{@ModelAttribute("command") UserBean} sessionUserBean
	 * @ModelAttribute("certificateBean") CertificateBean} certificateBean
	 * @return{ModelAndView} 
	 */
	
	@RequestMapping(value = "/editCertificate", method = RequestMethod.POST)
	public ModelAndView editCertificate(
			@ModelAttribute("certificateBean") CertificateBean certificateBean,
			@ModelAttribute("objOfUser") UserBean sessionUserBean,
			BindingResult result, ModelMap model, HttpServletRequest request) {

		int certificateId = Integer.parseInt(request
				.getParameter("certificateId"));
		certificateBean.setCertificateId(certificateId);
		Certificate certificate = certificateHelper
				.prepareCertificateModel(certificateBean);
		certificate.setUserId(sessionUserBean.getUserId());
		certificate.setCertificateId(certificateBean.getCertificateId());
		try {
			certificateService.addUserCertificate(certificate);
		} catch (MetaSkillFinderException e) {
			model.addAttribute("message", e.getMessage());
			return new ModelAndView("Error");
		}
		return new ModelAndView("redirect:/profile.html");
	}

	/**
	 * This function creates the view and model for the edit profile after deleting Certificate.
	 * @param{HttpServletRequest} request
	 * @param{@ModelAttribute("command") UserBean} sessionUserBean
	 * @param{@ModelAttribute("certificateBean") CertificateBean} certificateBean
	 * @return{ModelAndView} 
	 */
	
	@RequestMapping(value = "/deleteCertificate", method = RequestMethod.GET)
	public ModelAndView deleteCertificate(
			@ModelAttribute("certificateBean") CertificateBean certificateBean,
			@ModelAttribute("objOfUser") UserBean sessionUserBean,
			BindingResult result, ModelMap model, HttpServletRequest request) {

		int certificateId = Integer.parseInt(request
				.getParameter("certificateId"));
		try {
			certificateService.deleteUserCertificate(certificateId);
		} catch (MetaSkillFinderException e) {
			model.addAttribute("message", e.getMessage());
			return new ModelAndView("Error");
		}
		return new ModelAndView("redirect:/profile.html");
	}

}
