
/**
 * @class  SearchController
 * @since  30th november 15
 * This class implements the controller for search. It contains all the 
 * search related controllers.They fetch bean type objects from user interface
 * and process that data create view and model. 
 */

package com.meta.skillfinder.controller;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import com.meta.skillfinder.bean.UserBean;
import com.meta.skillfinder.exception.MetaSkillFinderException;
import com.meta.skillfinder.model.Skill;
import com.meta.skillfinder.model.User;
import com.meta.skillfinder.service.SkillService;

@Controller
@SessionAttributes("objOfUser")
public class SearchController {

	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private SkillService skillService;
	
	/**
	 * This function creates the view and model for the search result jsp page.
	 * @param{HttpServletRequest} request
	 * @param{@RequestParam("Skill") String} 
	 * @param{@ModelAttribute("objOfUser") UserBean} sessionUserBean
	 * @param{@ModelAttribute("command") Skill} skill
	 * @return{ModelAndView} 
	 */
	
	@RequestMapping(value = "/searchUserBySkill", method = RequestMethod.POST)
	public ModelAndView searchUserBySkill(@RequestParam("Skill") String skill1,
			@ModelAttribute("objOfUser") UserBean sessionUserBean,
			@ModelAttribute("command") Skill skill, BindingResult result,
			ModelMap model, HttpServletRequest request) {
		
		 	int skillId = Integer.parseInt(skill1); 
		 	System.out.println("skillid"+skillId);
		 	
	        try {
				Skill skillObject  = skillService.getSkillById(skillId);
			} catch (MetaSkillFinderException e) {
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
	        
	        List<Skill> skillList;
			try {
				skillList = skillService.getAllSkills();
			} catch (MetaSkillFinderException e) {
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
	        
	        List<User> searchedUsers;
			try {
				searchedUsers = skillService.getUsersBySkillId(skillId, sessionUserBean.getUserId());
			} catch (MetaSkillFinderException e) {
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
	        
	        ModelAndView modelAndView =  new ModelAndView();
	        model.addAttribute("listOfSkills", skillList);
			modelAndView.addObject("listOfSearchedUsers",searchedUsers);
			modelAndView.setViewName("SearchResult");
			return modelAndView;
		
	}
}
