

/**
 * @class  LogOutController
 * @since  30th november 15
 * This class implements the controller for logout. It contains all the 
 * logout related controllers.They fetch bean type objects from user interface
 * and process that data create view and model. 
 */

package com.meta.skillfinder.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.meta.skillfinder.bean.UserBean;
import com.meta.skillfinder.helper.UserHelper;
import com.meta.skillfinder.service.UserService;

@Controller
public class LogOutController {

	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private UserService userService;

	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private UserHelper userHelper;

	/**
	 * This function creates the view and model for the logout jsp page.
	 * @param{HttpServletRequest} request
	 * @param{@ModelAttribute("command") UserBean} userBean
	 * @return{ModelAndView} 
	 */
	
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public ModelAndView userProfile(
			@ModelAttribute("userBean") UserBean userBean,
			BindingResult bindingResult, ModelMap model,
			HttpServletRequest request) {
		if (bindingResult.hasErrors()) {
			// write a code to handle the error
			model.addAttribute("message", "error..");
			return new ModelAndView("Error", model);
		} else {
			HttpSession session = request.getSession(false);
			//invalidates the session if the user is logged in 
			if (session != null)
			{
				session.removeAttribute("objOfUser");
				session.invalidate();
			}
			return new ModelAndView("index");
		}
	}

}
