/**
 * @class  HomePageController
 * @since  30th november 15
 * This class implements the controller for HomePageController. It contains all the 
 * homepage related functions. They fetch bean type objects from user interface
 * and process that data create view and model. 
 */
package com.meta.skillfinder.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.meta.skillfinder.bean.CertificateBean;
import com.meta.skillfinder.bean.ConnectionBean;
import com.meta.skillfinder.bean.ContactDetailsBean;
import com.meta.skillfinder.bean.ExperienceBean;
import com.meta.skillfinder.bean.QualificationBean;
import com.meta.skillfinder.bean.SkillBean;
import com.meta.skillfinder.bean.UserBean;
import com.meta.skillfinder.exception.MetaSkillFinderException;
import com.meta.skillfinder.helper.CertificateHelper;
import com.meta.skillfinder.helper.ContactDetailsHelper;
import com.meta.skillfinder.helper.ExperienceHelper;
import com.meta.skillfinder.helper.QualificationHelper;
import com.meta.skillfinder.helper.SkillHelper;
import com.meta.skillfinder.helper.UserHelper;
import com.meta.skillfinder.model.Certificate;
import com.meta.skillfinder.model.ContactDetails;
import com.meta.skillfinder.model.Experience;
import com.meta.skillfinder.model.Qualification;
import com.meta.skillfinder.model.Skill;
import com.meta.skillfinder.model.User;
import com.meta.skillfinder.service.CertificateService;
import com.meta.skillfinder.service.ConnectionService;
import com.meta.skillfinder.service.ContactDetailsService;
import com.meta.skillfinder.service.ExperienceService;
import com.meta.skillfinder.service.QualificationService;
import com.meta.skillfinder.service.SkillService;
import com.meta.skillfinder.service.UserService;

@Controller
@SessionAttributes("objOfUser")
public class HomePageController {
	
	/**
	 * Defining dependencies
	 */
	@Autowired
	private ConnectionService connectionService;
	
	/**
	 * Defining dependencies
	 */
	@Autowired
	private UserHelper userHelper;
	
	/**
	 * Defining dependencies
	 */	
	@Autowired
	private QualificationService qualificationService;
	
	/**
	 * Defining dependencies
	 */
	@Autowired
	private UserService userService;
	
	/**
	 * Defining dependencies
	 */
	@Autowired
	private SkillService skillService;
	
	/**
	 * Defining dependencies
	 */
	@Autowired
	private ExperienceService experienceService;
	
	/**
	 * Defining dependencies
	 */
	@Autowired
	private CertificateService certificateService;
	
	/**
	 * Defining dependencies
	 */
	@Autowired
	private ContactDetailsService contactDetailsService;
	
	/**
	 * Defining dependencies
	 */	
	@Autowired
	private ContactDetailsHelper contactDetailsHelper;
	
	/**
	 * Defining dependencies
	 */	
	@Autowired
	private ExperienceHelper experienceHelper;
	
	/**
	 * Defining dependencies
	 */	
	@Autowired
	private QualificationHelper qualificationHelper;
	
	/**
	 * Defining dependencies
	 */
	@Autowired
	private SkillHelper skillHelper;
	
	/**
	 * Defining dependencies
	 */
	@Autowired
	private CertificateHelper certificateHelper;
	
		/**
		 * This function creates the view and model for the homepage jsp page.
		 * @param{HttpServletRequest} request
		 * @param{@ModelAttribute("command") UserBean} userBean
		 * @param{@ModelAttribute("objOfUser") UserBean sessionUserBean,} sessionUserBean
		 * @param{@ModelAttribute("connectionBean") ConnectionBean} connectionBean
		 * @return{ModelAndView} 
		 */
	
	@RequestMapping(value = "/homePage", method = RequestMethod.GET)
	public ModelAndView welcome(HttpServletRequest request,@ModelAttribute("userBean") UserBean userBean,
			@ModelAttribute("objOfUser") UserBean sessionUserBean,
			@ModelAttribute("connectionBean") ConnectionBean connectionBean,
			BindingResult bindingResult, ModelMap model)
	{
		if (bindingResult.hasErrors()) {
			// write a code to handle the error
			model.addAttribute("message", "error..");
			return new ModelAndView("Error", model);
		} else {
			
			ModelAndView modelAndView = new ModelAndView();
			modelAndView.addObject("experienceBean", new ExperienceBean());
			modelAndView.addObject("qualificationBean", new QualificationBean());
			modelAndView.addObject("skillBean", new SkillBean());
			modelAndView.addObject("certificateBean", new CertificateBean());
			
			int userId = (sessionUserBean).getUserId();

			Qualification qualification;
			try {
				qualification = qualificationService.getLatestQualification(userId);
			} catch (MetaSkillFinderException e) {
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}

			List<Experience> experienceList;
			try {
				experienceList = experienceService.getExperiences(userId);
			} catch (MetaSkillFinderException e) {
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
			
			List<Qualification> qualificationList;
			try {
				qualificationList = qualificationService.getAllQualifications(userId);
			} catch (MetaSkillFinderException e) {
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
			
			List<Certificate> certificateList;
			try {
				certificateList = certificateService.getAllCertificates(userId);
			} catch (MetaSkillFinderException e) {
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
			
			List<Skill> userSkillList;
			try {
				userSkillList = userService.getUserSkills(userId);
			} catch (MetaSkillFinderException e) {
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
			
			int contactId;
			try {
				contactId = userService.getContactDetailsId(userId);
			} catch (MetaSkillFinderException e) {
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
			
			ContactDetailsBean contactDetailsBean = new ContactDetailsBean();
			
			if (contactId != 0) {
				ContactDetails contactDetails;
				try {
					contactDetails = contactDetailsService.getContactDetails(contactId);
				} catch (MetaSkillFinderException e) {
					model.addAttribute("message", e.getMessage());
					return new ModelAndView("Error");
				}
				contactDetailsBean = contactDetailsHelper.prepareContactDetailsBean(contactDetails);
			} else {
				contactDetailsBean = null;
			}

			if (qualification != null) {
				QualificationBean qualificationBeanObj = qualificationHelper.prepareQualificationBean(qualification);
				request.setAttribute("objOfQualification", qualificationBeanObj);
			}

			List<ExperienceBean> experienceBeanList = experienceHelper.prepareExperienceBeanList(experienceList);

			List<SkillBean> userSkillBeanList = skillHelper.prepareUserSkillBeanList(userSkillList);
			request.setAttribute("listOfSkill", userSkillBeanList);

			List<QualificationBean> qualificationBeanList = qualificationHelper.prepareQualificationBeanList(qualificationList);

			List<CertificateBean> certificateBeanList = certificateHelper.prepareCertificateBeanList(certificateList);

			List<User> notConnectedUsersList;
			try {
				notConnectedUsersList = connectionService.getAllNotConnectedUsers(userId);
			} catch (MetaSkillFinderException e) {
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
			List<UserBean> notConnectedUsersBeanList = userHelper.prepareUserBeanList(notConnectedUsersList);
                        
            List<User> usersWithRequestSentList;
			try {
				usersWithRequestSentList = connectionService.getUsersWithRequestSentList(userId);
			} catch (MetaSkillFinderException e) {
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
            
			List<UserBean> usersWithRequestSentBeanList = userHelper.prepareUserBeanList(usersWithRequestSentList);
                        
            List<User> unknownUsersList;
			try {
				unknownUsersList = connectionService.getUnknownUsersList(userId);
			} catch (MetaSkillFinderException e) {
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
            
			List<UserBean> unknownUsersBeanList = userHelper.prepareUserBeanList(unknownUsersList);
                        
            List<User> pendingConnectionRequestList;
			try {
				pendingConnectionRequestList = connectionService.getPendingConnectionRequestList(userId);
			} catch (MetaSkillFinderException e) {
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
            
			List<UserBean> pendingConnectionRequestBeanList = userHelper.prepareUserBeanList(pendingConnectionRequestList);
			
			List<Skill> skillList;
			try {
				skillList = skillService.getAllSkills();
			} catch (MetaSkillFinderException e) {
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
			
			model.addAttribute("listOfSkills", skillList);
			model.addAttribute("listOfExperience", experienceBeanList);
			model.addAttribute("listOfQualification", qualificationBeanList);
			model.addAttribute("listOfCertificate", certificateBeanList);
			model.addAttribute("contactDetailsBean", contactDetailsBean);
			model.addAttribute("listOfNotConnectedUsers", notConnectedUsersBeanList);
            model.addAttribute("listOfUsersWithRequestSent",usersWithRequestSentBeanList);
            model.addAttribute("listOfUnknownUsers",unknownUsersBeanList);
            model.addAttribute("listOfPendingConnectionRequest",pendingConnectionRequestBeanList);
                      
            modelAndView.addAllObjects(model);
			modelAndView.setViewName("HomePage");
			return modelAndView;
		}
	}
}
