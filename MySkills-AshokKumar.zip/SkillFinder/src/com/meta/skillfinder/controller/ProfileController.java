
/**
 * @class  ProfileController
 * @since  30th november 15
 * This class implements the controller for profile. It contains all the 
 * profile related controllers.They fetch bean type objects from user interface
 * and process that data create view and model. 
 */

package com.meta.skillfinder.controller;

import com.meta.skillfinder.bean.CertificateBean;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.meta.skillfinder.bean.ContactDetailsBean;
import com.meta.skillfinder.bean.ExperienceBean;
import com.meta.skillfinder.bean.QualificationBean;
import com.meta.skillfinder.bean.UserBean;
import com.meta.skillfinder.exception.MetaSkillFinderException;
import com.meta.skillfinder.helper.CertificateHelper;
import com.meta.skillfinder.helper.ContactDetailsHelper;
import com.meta.skillfinder.helper.ExperienceHelper;
import com.meta.skillfinder.helper.QualificationHelper;
import com.meta.skillfinder.helper.SkillHelper;
import com.meta.skillfinder.helper.UserHelper;
import com.meta.skillfinder.model.ContactDetails;
import com.meta.skillfinder.model.Experience;
import com.meta.skillfinder.model.Qualification;
import com.meta.skillfinder.model.Skill;
import com.meta.skillfinder.model.User;
import com.meta.skillfinder.model.Certificate;
import com.meta.skillfinder.service.CertificateService;
import com.meta.skillfinder.service.ContactDetailsService;
import com.meta.skillfinder.service.EndorseService;
import com.meta.skillfinder.service.ExperienceService;
import com.meta.skillfinder.service.QualificationService;
import com.meta.skillfinder.service.SkillService;
import com.meta.skillfinder.service.UserService;
import com.meta.skillfinder.util.Qualifications;

@Controller
@SessionAttributes("objOfUser")
public class ProfileController {
	
	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private QualificationService qualificationService;
	
	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private UserService userService;
	
	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private SkillService skillService;
	
	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private ExperienceService experienceService;
	
	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private EndorseService endorseService;
	
	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private CertificateService certificateService;
	
	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private ContactDetailsService contactDetailsService;
	
	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private ContactDetailsHelper contactDetailsHelper;
	
	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private ExperienceHelper experienceHelper;
	
	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private QualificationHelper qualificationHelper;
	
	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private SkillHelper skillHelper;
	
	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private UserHelper userHelper;
	
	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private CertificateHelper certificateHelper;

    /**
	 * This function creates the view and model for the profile jsp page for add experience.
	 * @param{HttpServletRequest} request
	 * @param{@ModelAttribute("command") ExperienceBean} experienceBean
	 * @return{ModelAndView} 
	 */
	
	@RequestMapping(value = "/addExperience", method = RequestMethod.POST)
	public ModelAndView addUserExperience(
			@ModelAttribute("command") ExperienceBean experienceBean,
			BindingResult result, ModelMap model, HttpServletRequest request) {

		Experience experience = experienceHelper
				.prepareExperienceModel(experienceBean);
		UserBean userBean = (UserBean) request.getSession(false).getAttribute(
				"objOfUser");
		System.out.println("kkkdate" + userBean.getDateOfJoining());
		experience.setUserId(userBean.getUserId());
		try {
			experienceService.addUserExperience(experience);
		} catch (MetaSkillFinderException e) {
			model.addAttribute("message", e.getMessage());
			return new ModelAndView("Error");
		}
		return new ModelAndView("redirect:/profile.html");
	}

    /**
	 * This function creates the view and model for the connection jsp page  for add skill.
	 * @param{HttpServletRequest} request
	 * @param{@RequestParam("Skill") String } skill1
	 * @return{ModelAndView} 
	 */
	@RequestMapping(value = "/addSkill", method = RequestMethod.POST)
	public ModelAndView addUserSkill(@RequestParam("Skill") String skill1,
			@ModelAttribute("command") Skill skill, BindingResult result,
			ModelMap model, HttpServletRequest request) {

		int skillId = Integer.parseInt(skill1);
		
		Skill newSkill1;
		try {
			newSkill1 = skillService.getSkillById(skillId);
		} catch (MetaSkillFinderException e) {
			model.addAttribute("message", e.getMessage());
			return new ModelAndView("Error");
		}

		UserBean userBean = (UserBean) request.getSession(false).getAttribute(
				"objOfUser");
		
		User updateUser;
		try {
			updateUser = userService.getUser(userBean.getEmailId());
		} catch (MetaSkillFinderException e) {
			model.addAttribute("message", e.getMessage());
			return new ModelAndView("Error");
		}

		updateUser.getUserSkills().add(newSkill1);
		
		try {
			userService.addUser(updateUser);
		} catch (MetaSkillFinderException e) {
			model.addAttribute("message", e.getMessage());
			return new ModelAndView("Error");
		}

		return new ModelAndView("redirect:/profile.html");
	}

    /**
	 * This function creates the view and model for the profile jsp page  for add certificate.
	 * @param{HttpServletRequest} request
	 * @param{@ModelAttribute("command") CertificateBean} certificateBean
	 * @return{ModelAndView} 
	 */
	
	@RequestMapping(value = "/addCertificate", method = RequestMethod.POST)
	public ModelAndView addUserSkill(
			@ModelAttribute("command") CertificateBean certificateBean,
			BindingResult result, ModelMap model, HttpServletRequest request) {

		UserBean userBean = (UserBean) request.getSession(false).getAttribute(
				"objOfUser");
		Certificate certificate = certificateHelper
				.prepareCertificateModel(certificateBean);
		certificate.setUserId(userBean.getUserId());
		try {
			certificateService.addUserCertificate(certificate);
		} catch (MetaSkillFinderException e) {
			model.addAttribute("message", e.getMessage());
			return new ModelAndView("Error");
		}
		return new ModelAndView("redirect:/profile.html");
	}

    /**
	 * This function creates the view and model for the profile jsp page for add qualification..
	 * @param{HttpServletRequest} request
	 * @param{@ModelAttribute("command") QualificationBean} qualificationBean
	 * @return{ModelAndView} 
	 */
	@RequestMapping(value = "/addQualification", method = RequestMethod.POST)
	public ModelAndView addUserQualification(
			@ModelAttribute("command") QualificationBean qualificationBean,
			BindingResult result, ModelMap model, HttpServletRequest request) {

		UserBean userBean = (UserBean) request.getSession(false).getAttribute(
				"objOfUser");
		Qualification qualification = qualificationHelper
				.prepareQualificationModel(qualificationBean);
		qualification.setUserId(userBean.getUserId());
		try {
			qualificationService.addUserQualification(qualification);
		} catch (MetaSkillFinderException e) {
			model.addAttribute("message", e.getMessage());
			return new ModelAndView("Error");
		}
		return new ModelAndView("redirect:/profile.html");
	}

    /**
	 * This function creates the view and model for the profile jsp.
	 * @param{HttpServletRequest} request
	 * @param{@ModelAttribute("command") UserBean} userBean
	 * @param{@ModelAttribute("objOfUser") UserBean sessionUserBean,} sessionUserBean
	 * @param{@ModelAttribute("contactDetailsBean") ContactDetailsBean} contactDetailsBean
	 * @param{@ModelAttribute("experienceBean") ExperienceBean} experienceBean
	 * @param{@ModelAttribute("qualificationBean") QualificationBean} qualificationBean
	 * @param{@ModelAttribute("certificateBean") CertificateBean} certificateBean
	 * @return{ModelAndView} 
	 */
	
	@RequestMapping(value = "/profile", method = RequestMethod.GET)
	public ModelAndView userProfile(
			@ModelAttribute("objOfUser") UserBean sessionUserBean,
			@ModelAttribute("userBean") UserBean userBean,
			@ModelAttribute("contactDetailsBean") ContactDetailsBean contactDetailsBean,
			@ModelAttribute("experienceBean") ExperienceBean experienceBean,
			@ModelAttribute("qualificationBean") QualificationBean qualificationBean,
			@ModelAttribute("certificateBean") CertificateBean certificateBean,
			BindingResult result, HttpServletRequest request, ModelMap model) {

		List<Skill> userSkillList;
		try {
			userSkillList = userService.getUserSkills(sessionUserBean
					.getUserId());
		} catch (MetaSkillFinderException e) {
			model.addAttribute("message", e.getMessage());
			return new ModelAndView("Error");
		}
		
		Map<Integer, Integer> mapOfSkills;
		try {
			mapOfSkills = endorseService.getMapOfSkills(sessionUserBean.getUserId(),userSkillList);
		} catch (MetaSkillFinderException e) {
			model.addAttribute("message", e.getMessage());
			return new ModelAndView("Error");
		}
		request.setAttribute("mapOfSkills", mapOfSkills);
		
		List<Skill> skillList;
		try {
			skillList = skillService.getAllSkills();
		} catch (MetaSkillFinderException e) {
			model.addAttribute("message", e.getMessage());
			return new ModelAndView("Error");
		}
		
		ModelAndView modelAndView = new ModelAndView();

		String emailId = sessionUserBean.getEmailId();
		User user;
		try {
			user = userService.getUser(emailId);
		} catch (MetaSkillFinderException e) {
			model.addAttribute("message", e.getMessage());
			return new ModelAndView("Error");
		}
		userBean = userHelper.prepareUserBean(user);

		int contactId;
		try {
			contactId = userService.getContactDetailsId(userBean.getUserId());
		} catch (MetaSkillFinderException e) {
			model.addAttribute("message", e.getMessage());
			return new ModelAndView("Error");
		}

		if (contactId != 0) {
			ContactDetails contactDetails;
			try {
				contactDetails = contactDetailsService
						.getContactDetails(contactId);
			} catch (MetaSkillFinderException e) {
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
			contactDetailsBean = contactDetailsHelper
					.prepareContactDetailsBean(contactDetails);
		} else {
			contactDetailsBean = null;
		}

		Qualification qualification;
		try {
			qualification = qualificationService
					.getLatestQualification(userBean.getUserId());
		} catch (MetaSkillFinderException e) {
			model.addAttribute("message", e.getMessage());
			return new ModelAndView("Error");
		}
		
		if (qualification != null) {
			QualificationBean qualificationBeanObj = qualificationHelper
					.prepareQualificationBean(qualification);
			request.setAttribute("objOfQualification", qualificationBeanObj);
		}

		List<Experience> experienceList;
		try {
			experienceList = experienceService
					.getExperiences(userBean.getUserId());
		} catch (MetaSkillFinderException e) {
			model.addAttribute("message", e.getMessage());
			return new ModelAndView("Error");
		}
		
		List<ExperienceBean> experienceBeanList = experienceHelper
				.prepareExperienceBeanList(experienceList);
		
		List<Qualification> qualificationList;
		try {
			qualificationList = qualificationService
					.getAllQualifications(userBean.getUserId());
		} catch (MetaSkillFinderException e) {
			model.addAttribute("message", e.getMessage());
			return new ModelAndView("Error");
		}
		
		List<QualificationBean> qualificationBeanList = qualificationHelper
				.prepareQualificationBeanList(qualificationList);

		List<Certificate> certificateList;
		try {
			certificateList = certificateService
					.getAllCertificates(userBean.getUserId());
		} catch (MetaSkillFinderException e) {
			model.addAttribute("message", e.getMessage());
			return new ModelAndView("Error");
		}
		
		List<CertificateBean> certificateBeanList = certificateHelper
				.prepareCertificateBeanList(certificateList);
		
		model.addAttribute("listOfExperience", experienceBeanList);
		model.addAttribute("listOfQualification", qualificationBeanList);
		model.addAttribute("listOfCertificate", certificateBeanList);
		model.addAttribute("contactDetailsBean", contactDetailsBean);
		model.addAttribute("listOfUserSkill", userSkillList);
		model.addAttribute("listOfSkills", skillList);
		model.addAttribute("qualificationEnum",Qualifications.values());
		modelAndView.addAllObjects(model);
		modelAndView.setViewName("Profile");
		return modelAndView;
	}

}
