
/**
 * @class  ConnectionProfileController
 * @since  30th november 15
 * This class implements the controller for profile of a connection. It contains all the profile 
 * of connected user related controllers.They fetch bean type objects from user interface
 * and process that data create view and model. 
 */

package com.meta.skillfinder.controller;

import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import com.meta.skillfinder.bean.CertificateBean;
import com.meta.skillfinder.bean.ContactDetailsBean;
import com.meta.skillfinder.bean.ExperienceBean;
import com.meta.skillfinder.bean.QualificationBean;
import com.meta.skillfinder.bean.SkillBean;
import com.meta.skillfinder.bean.UserBean;
import com.meta.skillfinder.exception.MetaSkillFinderException;
import com.meta.skillfinder.helper.CertificateHelper;
import com.meta.skillfinder.helper.ContactDetailsHelper;
import com.meta.skillfinder.helper.ExperienceHelper;
import com.meta.skillfinder.helper.QualificationHelper;
import com.meta.skillfinder.helper.SkillHelper;
import com.meta.skillfinder.helper.UserHelper;
import com.meta.skillfinder.model.Certificate;
import com.meta.skillfinder.model.ContactDetails;
import com.meta.skillfinder.model.Endorse;
import com.meta.skillfinder.model.Experience;
import com.meta.skillfinder.model.Qualification;
import com.meta.skillfinder.model.Skill;
import com.meta.skillfinder.service.CertificateService;
import com.meta.skillfinder.service.ConnectionService;
import com.meta.skillfinder.service.ContactDetailsService;
import com.meta.skillfinder.service.EndorseService;
import com.meta.skillfinder.service.ExperienceService;
import com.meta.skillfinder.service.QualificationService;
import com.meta.skillfinder.service.SkillService;
import com.meta.skillfinder.service.UserService;

@Controller
@SessionAttributes("objOfUser")
public class ConnectionProfileController {

	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private QualificationService qualificationService;

	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private SkillService skillService;
	
	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private UserService userService;
	
	/**
	 * Defining dependencies
	 */

	@Autowired
	private ExperienceService experienceService;
	
	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private EndorseService endorseService;
	
	/**
	 * Defining dependencies
	 */

	@Autowired
	private CertificateService certificateService;
	
	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private ConnectionService connectionService;
	
	/**
	 * Defining dependencies
	 */

	@Autowired
	private ContactDetailsService contactDetailsService;
	
	/**
	 * Defining dependencies
	 */

	@Autowired
	private ContactDetailsHelper contactDetailsHelper;
	
	/**
	 * Defining dependencies
	 */

	@Autowired
	private ExperienceHelper experienceHelper;
	
	/**
	 * Defining dependencies
	 */

	@Autowired
	private QualificationHelper qualificationHelper;
	
	/**
	 * Defining dependencies
	 */

	@Autowired
	private SkillHelper skillHelper;
	
	/**
	 * Defining dependencies
	 */

	@Autowired
	private UserHelper userHelper;
	
	/**
	 * Defining dependencies
	 */

	@Autowired
	private CertificateHelper certificateHelper;

	/**
	 * This function creates the view and model for the profile of a user which is a connection.
	 * @param{HttpServletRequest} request
	 * @param{@ModelAttribute("command") UserBean} userBean
	 * @param{@ModelAttribute("objOfUser") UserBean sessionUserBean,} sessionUserBean
	 * @return{ModelAndView} 
	 */
	
	@RequestMapping(value = "/connectionProfile", method = RequestMethod.GET)
	public ModelAndView welcome(@ModelAttribute("userBean") UserBean userBean,
			@ModelAttribute("objOfUser") UserBean sessionUserBean,
			BindingResult bindingResult, ModelMap model,
			HttpServletRequest request, @RequestParam("emailId") String emailId) {
		
		if (bindingResult.hasErrors()) {
			model.addAttribute("message", "error..");
			return new ModelAndView("Error", model);
		} else {

			ModelAndView modelAndView = new ModelAndView();
			modelAndView.addObject("experienceBean", new ExperienceBean());
			modelAndView.addObject("qualificationBean", new QualificationBean());
			modelAndView.addObject("skillBean", new SkillBean());
			modelAndView.addObject("certificateBean", new CertificateBean());
			try {
				userBean = userHelper.prepareUserBean(userService.getUser(request
						.getParameter("emailId")));
			} catch (MetaSkillFinderException e) {
				e.printStackTrace();
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
			int userId = userBean.getUserId();
			int sessionUserId = sessionUserBean.getUserId();
			int requestStatus;
			try {
				requestStatus = connectionService.getRequestStatus(userId, sessionUserId);
			} catch (MetaSkillFinderException e) {
				e.printStackTrace();
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
			request.setAttribute("requestStatus", requestStatus);
			
			Qualification qualification;
			try {
				qualification = qualificationService
						.getLatestQualification(userId);
			} catch (MetaSkillFinderException e) {
				e.printStackTrace();
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}

			List<Skill> skillList;
			try {
				skillList = skillService.getAllSkills();
			} catch (MetaSkillFinderException e) {
				e.printStackTrace();
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
			
			List<Experience> experienceList;
			try {
				experienceList = experienceService
						.getExperiences(userId);
			} catch (MetaSkillFinderException e) {
				e.printStackTrace();
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
			
			List<Qualification> qualificationList;
			try {
				qualificationList = qualificationService
						.getAllQualifications(userId);
			} catch (MetaSkillFinderException e) {
				e.printStackTrace();
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
			
			List<Certificate> certificateList;
			try {
				certificateList = certificateService
						.getAllCertificates(userId);
			} catch (MetaSkillFinderException e) {
				e.printStackTrace();
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
			
			List<Skill> userSkillList;
			try {
				userSkillList = userService.getUserSkills(userId);
			} catch (MetaSkillFinderException e) {
				e.printStackTrace();
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
			
			Map<Integer, Integer> mapOfEndorsedSkills;
			try {
				mapOfEndorsedSkills = endorseService.getMapOfEndorsedSkills(sessionUserBean.getUserId(),userId,userSkillList);
			} catch (MetaSkillFinderException e) {
				e.printStackTrace();
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
			
			request.setAttribute("mapOfEndorsedSkills", mapOfEndorsedSkills);
			
			Map<Integer, Integer> mapOfSkills;
			try {
				mapOfSkills = endorseService.getMapOfSkills(userId,userSkillList);
			} catch (MetaSkillFinderException e) {
				e.printStackTrace();
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
			request.setAttribute("mapOfSkills", mapOfSkills);
			
			int contactId;
			try {
				contactId = userService.getContactDetailsId(userId);
			} catch (MetaSkillFinderException e) {
				e.printStackTrace();
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
			
			ContactDetailsBean contactDetailsBean = new ContactDetailsBean();

			if (contactId != 0) {
				ContactDetails contactDetails;
				try {
					contactDetails = contactDetailsService
							.getContactDetails(contactId);
				} catch (MetaSkillFinderException e) {
					e.printStackTrace();
					model.addAttribute("message", e.getMessage());
					return new ModelAndView("Error");
				}
				contactDetailsBean = contactDetailsHelper
						.prepareContactDetailsBean(contactDetails);
			} else {
				contactDetailsBean = null;
			}

			if (qualification != null) {
				QualificationBean qualificationBeanObj = qualificationHelper
						.prepareQualificationBean(qualification);
				request.setAttribute("objOfQualification", qualificationBeanObj);
			}

			List<ExperienceBean> experienceBeanList = experienceHelper
					.prepareExperienceBeanList(experienceList);
			request.setAttribute("listOfExperience", experienceBeanList);

			List<SkillBean> userSkillBeanList = skillHelper
					.prepareUserSkillBeanList(userSkillList);
			request.setAttribute("listOfSkill", userSkillBeanList);

			List<QualificationBean> qualificationBeanList = qualificationHelper
					.prepareQualificationBeanList(qualificationList);
			request.setAttribute("listOfQualification", qualificationBeanList);

			List<CertificateBean> certificateBeanList = certificateHelper
					.prepareCertificateBeanList(certificateList);
			request.setAttribute("listOfCertificate", certificateBeanList);

			model.addAttribute("listOfSkills", skillList);
			modelAndView.addObject("userBean", userBean);
			modelAndView.addObject("contactDetailsBean", contactDetailsBean);
			modelAndView.setViewName("ConnectionProfile");
			return modelAndView;

		}
	}
	
	/**
	 * This function creates the view and model after endorsing the skill of a connection .
	 * @param{HttpServletRequest} request
	 * @param{@ModelAttribute("command") UserBean} userBean
	 * @param{@ModelAttribute("objOfUser") UserBean sessionUserBean,} sessionUserBean
	 * @return{ModelAndView} 
	 */
	
	@RequestMapping(value = "/endorseSkill", method = RequestMethod.POST)
	public ModelAndView endorseSkill(@ModelAttribute("userBean") UserBean userBean,
			@ModelAttribute("objOfUser") UserBean sessionUserBean,
			BindingResult bindingResult, ModelMap model,
			HttpServletRequest request) {
	
	
		if (bindingResult.hasErrors()) {
			// write a code to handle the error
			model.addAttribute("message", "error..");
			return new ModelAndView("Error", model);
		} else {
			
			int endorserUserId = sessionUserBean.getUserId();
			String endorsedUserEmailId = request.getParameter("endorsedUserEmailId");
			int endorsedUserId;
			try {
				endorsedUserId = userService.getUser(endorsedUserEmailId).getUserId();
			} catch (MetaSkillFinderException e) {
				e.printStackTrace();
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
			
			int skillId = Integer.parseInt(request.getParameter("skillId"));
			System.out.println(endorsedUserId+"lklklk"+endorserUserId+"hhghghg"+skillId);

			Endorse endorse = new Endorse();
			endorse.setEndorsedUserId(endorsedUserId);
			endorse.setEndorserUserId(endorserUserId);
			endorse.setUserSkillId(skillId);
			try {
				endorseService.addEndorsement(endorse);
			} catch (MetaSkillFinderException e) {
				e.printStackTrace();
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
			
			return new ModelAndView("redirect:/connectionProfile.html?emailId="+endorsedUserEmailId,model);
		}
	}
	
	/**
	 * This function creates the view and model deleting endorse for a  skill of a connection.
	 * @param{HttpServletRequest} request
	 * @param{@ModelAttribute("command") UserBean} userBean
	 * @param{@ModelAttribute("objOfUser") UserBean sessionUserBean,} sessionUserBean
	 * @return{ModelAndView} 
	 */
	
	@RequestMapping(value = "/deleteEndorsement", method = RequestMethod.GET)
	public ModelAndView deleteEndorsement(@ModelAttribute("userBean") UserBean userBean,
			@ModelAttribute("objOfUser") UserBean sessionUserBean,
			BindingResult bindingResult, ModelMap model,
			HttpServletRequest request, 
			@RequestParam("endorsedUserEmailId") String endorsedUserEmailId,
			@RequestParam("skillId") int skillId) {
	
	
		if (bindingResult.hasErrors()) {
			// write a code to handle the error
			model.addAttribute("message", "error..");
			return new ModelAndView("Error", model);
		} else {
			
			int endorserUserId = sessionUserBean.getUserId();
			
			int endorsedUserId;
			try {
				endorsedUserId = userService.getUser(endorsedUserEmailId).getUserId();
			} catch (MetaSkillFinderException e) {
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
			
			try {
				endorseService.deleteEndorsement(endorserUserId, endorsedUserId, skillId);
			} catch (MetaSkillFinderException e) {
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
			
			return new ModelAndView("redirect:/connectionProfile.html?emailId="+endorsedUserEmailId,model);
		}
	}
	
}
