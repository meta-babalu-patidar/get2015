
/**
 * @class  Connection Controller
 * @since  30th november 15
 * This class implements the controller for connection. It contains all the 
 * connection related controllers.They fetch bean type objects from user interface
 * and process that data create view and model. 
 */

package com.meta.skillfinder.controller;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import com.meta.skillfinder.bean.ConnectionBean;
import com.meta.skillfinder.bean.UserBean;
import com.meta.skillfinder.exception.MetaSkillFinderException;
import com.meta.skillfinder.helper.ConnectionHelper;
import com.meta.skillfinder.helper.UserHelper;
import com.meta.skillfinder.model.Connection;
import com.meta.skillfinder.model.Skill;
import com.meta.skillfinder.model.User;
import com.meta.skillfinder.service.ConnectionService;
import com.meta.skillfinder.service.SkillService;
import com.meta.skillfinder.service.UserService;

@Controller
@SessionAttributes("objOfUser")
public class ConnectionController {
	
	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private UserService userService;
	
	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private SkillService skillService;
	
	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private ConnectionService connectionService;

	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private UserHelper userHelper;
	
	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private ConnectionHelper connectionHelper;

    /**
	 * This function creates the view and model for the connection jsp page.
	 * @param{HttpServletRequest} request
	 * @param{@ModelAttribute("command") UserBean} userBean
	 * @param{@ModelAttribute("objOfUser") UserBean sessionUserBean,} sessionUserBean
	 * @param{@ModelAttribute("connectionBean") ConnectionBean} connectionBean
	 * @return{ModelAndView} 
	 */
	
	@RequestMapping(value = "/connection", method = RequestMethod.GET)
	public ModelAndView welcome(HttpServletRequest request,@ModelAttribute("command") UserBean userBean,
			@ModelAttribute("objOfUser") UserBean sessionUserBean,
			@ModelAttribute("connectionBean") ConnectionBean connectionBean,
			BindingResult bindingResult, ModelMap model) {
		if (bindingResult.hasErrors()) {
			model.addAttribute("message", "error..");
			return new ModelAndView("Error", model);
		} else {
			List<Skill> skillList;
			try {
				skillList = skillService.getAllSkills();
			} catch (MetaSkillFinderException e) {
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
			model.addAttribute("listOfSkills", skillList);
			int userId = (sessionUserBean).getUserId();
			List<User> connectedUsersList;
			try {
				connectedUsersList = connectionService.getAllConnections(userId);
			} catch (MetaSkillFinderException e) {
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
			List<UserBean> connectedUsersBeanList = userHelper.prepareUserBeanList(connectedUsersList);
			request.setAttribute("listOfConnectedUsers", connectedUsersBeanList);
			return new ModelAndView("Connection");
		}
	}
	
    /**
	 * This function creates the view and model for the connection jsp page after adding a connection.
	 * @param{HttpServletRequest} request
	 * @param{@ModelAttribute("command") UserBean} userBean
	 * @param{@ModelAttribute("objOfUser") UserBean sessionUserBean,} sessionUserBean
	 * @return{@ModelAttribute("connectionBean") ConnectionBean connectionBean} connectionBean
	 * @return{ModelAndView} 
	 */
	
	@RequestMapping(value = "/addConnection", method = RequestMethod.POST)
	public ModelAndView addConnection(HttpServletRequest request,@ModelAttribute("userBean") UserBean userBean,
			@ModelAttribute("objOfUser") UserBean sessionUserBean,
			@ModelAttribute("connectionBean") ConnectionBean connectionBean,
			BindingResult bindingResult, ModelMap model) {
		if (bindingResult.hasErrors()) {
			model.addAttribute("message", "error..");
			return new ModelAndView("Error", model);
		} else {
			int userId = (sessionUserBean).getUserId();
			int requestedUserId = Integer.parseInt(request.getParameter("connectionUserId"));
			System.out.println("user id"+userId+"hhhh"+requestedUserId);
			Connection userToConnect = new Connection();
			userToConnect.setUserId(requestedUserId);
			userToConnect.setConnectionUserId(userId);
			userToConnect.setRequestStatus(1);
			try {
				connectionService.sendConnectionRequest(userToConnect);
			} catch (MetaSkillFinderException e) {
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
			
			Connection user = new Connection();
			user.setUserId(userId);
			user.setConnectionUserId(requestedUserId);
			user.setRequestStatus(2);
			try {
				connectionService.sendConnectionRequest(user);
			} catch (MetaSkillFinderException e) {
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
			
			return new ModelAndView("redirect:/homePage.html",model);
		}
	}
	
    /**
	 * This function creates the view and model for the connection jsp page after accepting a connection.
	 * @param{HttpServletRequest} request
	 * @param{@ModelAttribute("command") UserBean} userBean
	 * @param{@ModelAttribute("objOfUser") UserBean sessionUserBean,} sessionUserBean
	 * @return{@ModelAttribute("connectionBean") ConnectionBean connectionBean} connectionBean
	 * @return{ModelAndView} 
	 */
	
	 @RequestMapping(value = "/acceptConnection", method = RequestMethod.POST)
		public ModelAndView acceptConnection(HttpServletRequest request,@ModelAttribute("userBean") UserBean userBean,
				@ModelAttribute("objOfUser") UserBean sessionUserBean,
				@ModelAttribute("connectionBean") ConnectionBean connectionBean,
				BindingResult bindingResult, ModelMap model) {
			if (bindingResult.hasErrors()) {
				model.addAttribute("message", "error..");
				return new ModelAndView("Error", model);
			} else {
				int userId = (sessionUserBean).getUserId();
				int requestedUserId = Integer.parseInt(request.getParameter("connectedUserId"));
				System.out.println("user id"+userId+"hhhh"+requestedUserId);
				Connection userToConnect;
				try {
					userToConnect = connectionService.getPendingConnection(requestedUserId, userId);
				} catch (MetaSkillFinderException e) {
					model.addAttribute("message", e.getMessage());
					return new ModelAndView("Error");
				}
				userToConnect.setRequestStatus(3);
				try {
					connectionService.sendConnectionRequest(userToConnect);
				} catch (MetaSkillFinderException e) {
					model.addAttribute("message", e.getMessage());
					return new ModelAndView("Error");
				}
	                        
	            Connection user;
				try {
					user = connectionService.getPendingConnection(userId, requestedUserId);
				} catch (MetaSkillFinderException e) {
					model.addAttribute("message", e.getMessage());
					return new ModelAndView("Error");
				}
	            user.setRequestStatus(3);
				try {
					connectionService.sendConnectionRequest(user);
				} catch (MetaSkillFinderException e) {
					model.addAttribute("message", e.getMessage());
					return new ModelAndView("Error");
				}
				
				return new ModelAndView("redirect:/homePage.html",model);
			}
		}
}
