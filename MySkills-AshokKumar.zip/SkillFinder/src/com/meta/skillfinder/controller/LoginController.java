
/**
 * @class  LoginController
 * @since  30th november 15
 * This class implements the controller for login. It contains all the 
 * login related controllers.They fetch bean type objects from user interface
 * and process that data create view and model. 
 */

package com.meta.skillfinder.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import com.meta.skillfinder.bean.UserBean;
import com.meta.skillfinder.exception.MetaSkillFinderException;
import com.meta.skillfinder.helper.UserHelper;
import com.meta.skillfinder.model.Skill;
import com.meta.skillfinder.model.User;
import com.meta.skillfinder.service.SkillService;
import com.meta.skillfinder.service.UserService;

@Controller
@SessionAttributes("objOfUser")
public class LoginController {
	
	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private UserService userService;
	
	/**
	 * Defining dependencies
	 */
	

	@Autowired
	private UserHelper userHelper;

	/**
	 * Defining dependencies
	 */
	

	@Autowired
	private SkillService skillService;
	
	/**
	 * This function creates the view and model for the index jsp page for login.
	 * @param{HttpServletRequest} request
	 * @param{@ModelAttribute("command") UserBean} userBean
	 * @param{@ModelAttribute("objOfUser") UserBean sessionUserBean,} sessionUserBean
	 * @return{ModelAndView} 
	 */
	
	@RequestMapping(value = "/logIn", method = RequestMethod.POST)
	public ModelAndView getUserByEmailId(
			@ModelAttribute("userBean") UserBean userBean,
			BindingResult bindingResult, ModelMap model,
			HttpServletRequest request) {

		if (bindingResult.hasErrors()) {
			// write a code to handle the error
			model.addAttribute("message", "error..");
			return new ModelAndView("Error", model);
		} else {

			User user = userHelper.prepareModel(userBean);

			try {
				if (userService.getUser(user.getEmail()) == null) {
					model.addAttribute("message",
							"Account doesn't exist, Please sign up");
					return new ModelAndView("index", model);
				} else if (userService.getUser(user.getEmail()).getPassword()
						.equals(userBean.getPassword())) {
					userBean = userHelper.prepareUserBean(userService.getUser(user
							.getEmail()));
					
					HttpSession session = request.getSession(true); 
					
					List<Skill> skillList = skillService.getAllSkills();
					model.addAttribute("listOfSkills", skillList);
					session.setAttribute("objOfUser", userBean);
					return new ModelAndView("redirect:/homePage.html", model);
				} else {
					model.addAttribute("message", "Incorrect password");
					return new ModelAndView("index", model);
				}
			} catch (MetaSkillFinderException e) {
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
		}
	}
	
	/**
	 * This function creates the view and model for the index jsp page.
	 * @param{HttpServletRequest} request
	 * @param{@ModelAttribute("command") UserBean} userBean
	 * @param{@ModelAttribute("objOfUser") UserBean sessionUserBean,} sessionUserBean
	 * @return{ModelAndView} 
	 */
	
	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public ModelAndView welcome(@ModelAttribute("userBean") UserBean userBean,
			BindingResult bindingResult, ModelMap model) {
		if (bindingResult.hasErrors()) {
			// write a code to handle the error
			model.addAttribute("message", "error..");
			return new ModelAndView("Error", model);
		} else {
			return new ModelAndView("index");
		}
	}

}
