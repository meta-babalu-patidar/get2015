
/**
 * @class  SignUpController
 * @since  30th november 15
 * This class implements the controller for sign up. It contains all the 
 *  sign up related controllers.They fetch bean type objects from user interface
 * and process that data create view and model. 
 */

package com.meta.skillfinder.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLConnection;
import java.sql.Timestamp;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.meta.skillfinder.bean.UserBean;
import com.meta.skillfinder.exception.MetaSkillFinderException;
import com.meta.skillfinder.helper.UserHelper;
import com.meta.skillfinder.model.Skill;
import com.meta.skillfinder.model.User;
import com.meta.skillfinder.service.SkillService;
import com.meta.skillfinder.service.UserService;

@Controller
public class SignUpController {

	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private UserService userService;
	
	/**
	 * Defining dependencies
	 */

	@Autowired
	private JavaMailSenderImpl mailSender;
	
	/**
	 * Defining dependencies
	 */

	@Autowired
	private UserHelper userHelper;
	
	/**
	 * Defining dependencies
	 */

	@Autowired(required = true)
	@Qualifier(value = "skillService")
	private SkillService skillService;

	/**
	 * This function creates the view and model for the login jsp page.
	 * @param{HttpServletRequest} request
	 * @param{@ModelAttribute("userBean") UserBean } userBean
	 * @return{ModelAndView} 
	 */
	
	@RequestMapping(value = "/signUp", method = RequestMethod.POST)
	public ModelAndView addUserInDb(
			@ModelAttribute("userBean") UserBean userBean,
			BindingResult result, ModelMap model, HttpServletRequest request) {
		User user = prepareModel(userBean);

		try {
			if (userService.getUser(user.getEmail()) == null) {
				user.setCurrentCompany("Metacube Software Pvt. Ltd.");
				userService.addUser(user);
				userBean = userHelper.prepareUserBean(userService.getUser(user
						.getEmail()));
				HttpSession session = request.getSession(true);
				session.setAttribute("objOfUser", userBean);
				List<Skill> skillList = skillService.getAllSkills();
				model.addAttribute("listOfSkills", skillList);
				model.addAttribute("firstname", userBean.getFirstName());
				model.addAttribute("emailid", userBean.getEmailId());
				return new ModelAndView("redirect:/homePage.html", model);

			} else {
				model.addAttribute("message", "Duplicate E-mail Id");
				return new ModelAndView("index", model);
			}
		} catch (MetaSkillFinderException e) {
			model.addAttribute("message", e.getMessage());
			return new ModelAndView("Error");
		}

	}

	/**
	 * This function creates the view and model for the search sign up.
	 * @param{HttpServletRequest} request
	 * @param{@ModelAttribute("userBean") UserBean } userBean
	 * @return{ModelAndView} 
	 */
	
	@RequestMapping(value = "/GoogleAuth", method = RequestMethod.GET)
	public ModelAndView verifyUserByOAuth(
			@ModelAttribute("userBean") UserBean userBean,
			BindingResult result, ModelMap model, HttpServletRequest request,
			HttpServletRequest response) {
		String returnPath = "";
		try {
			String code = request.getParameter("code"); // get code
			System.out.println(code);

			String urlParameters = "code="
					+ code
					+ "&client_id=157211748853-vqhs13j0kddcdtd18ce210v33djo029h.apps.googleusercontent.com"
					+ "&client_secret=-Y5cxtlROT9yjvIC-zU7XRTs"
					+ "&redirect_uri=http://localhost:8080/SkillFinder/GoogleAuth.html"
					+ "&grant_type=authorization_code"; 						// format parameters to
																				// post

			URL url = new URL("https://accounts.google.com/o/oauth2/token"); 	// post
																				// parameters
			URLConnection urlConn = url.openConnection();
			urlConn.setDoOutput(true);
			OutputStreamWriter writer = new OutputStreamWriter(
					urlConn.getOutputStream());
			writer.write(urlParameters);
			writer.flush();
			String line, outputString = ""; 									// get output in outputString
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					urlConn.getInputStream()));

			while ((line = reader.readLine()) != null) {
				outputString += line;
			}

			JsonObject json = (JsonObject) new JsonParser().parse(outputString); // get Access Token
			String access_token = json.get("access_token").getAsString();

			url = new URL(
					"https://www.googleapis.com/oauth2/v1/userinfo?access_token="
							+ access_token); 								// get User Info
			urlConn = url.openConnection();
			outputString = "";
			reader = new BufferedReader(new InputStreamReader(
					urlConn.getInputStream()));

			while ((line = reader.readLine()) != null) {
				outputString += line;
			}

			User user = new Gson().fromJson(outputString, User.class); 		// Convert JSON response into bean class

			try {
				if (userService.getUser(user.getEmail()) == null) {

					String dummyPassword = user.getEmail().substring(0, 6);
					user.setPassword(dummyPassword);
					user.setCurrentCompany("Metacube Software Pvt. Ltd.");
					user.setContactId(0);
					String recipientAddress = user.getEmail(); 				// takes input from e-mail form
					String subject = "Successful sign up on skill finder account";
					String message = "Your skill finder user account has been created. Your password is "
							+ dummyPassword + ".\nThanks, for joining us.";
					System.out.println("To: " + recipientAddress); 			// prints debug info
					System.out.println("Subject: " + subject);
					System.out.println("Message: " + message);

					SimpleMailMessage email = new SimpleMailMessage();		// creates a simple e-mail object
					email.setTo(recipientAddress);
					email.setSubject(subject);
					email.setText(message);

					mailSender.send(email); 								// sends the e-mail
					userService.addUser(user);

				}
			} catch (MailException | MetaSkillFinderException e) {
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
			
			try {
				userBean = userHelper.prepareUserBean(userService.getUser(user
						.getEmail()));
			} catch (MetaSkillFinderException e) {
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
			
			HttpSession session = request.getSession(true);
			session.setAttribute("objOfUser", userBean);
			List<Skill> skillList;
			try {
				skillList = skillService.getAllSkills();
			} catch (MetaSkillFinderException e) {
				model.addAttribute("message", e.getMessage());
				return new ModelAndView("Error");
			}
			model.addAttribute("listOfSkills", skillList);
			model.addAttribute("firstname", userBean.getFirstName());
			model.addAttribute("emailid", userBean.getEmailId());
			writer.close();
			reader.close();
			returnPath = "redirect:/homePage.html";
		} catch (MalformedURLException e) {
			System.out.println(e);
		} catch (ProtocolException e) {
			System.out.println(e);
		} catch (IOException e) {
			System.out.println(e);
		}
		return new ModelAndView(returnPath, model);
	}

	private User prepareModel(UserBean userBean) {
		User user = new User();
		user.setGiven_name(userBean.getFirstName());
		user.setMiddleName(userBean.getMiddleName());
		user.setFamily_name(userBean.getLastName());
		user.setStatus(userBean.getStatus());
		user.setDateOfBirth(userBean.getDateOfBirth());
		user.setContactId(userBean.getContactId());
		user.setCreatedTime(userBean.getCreatedTime());
		user.setCurrentCompany(userBean.getCurrentCompany());
		user.setDateOfJoining(userBean.getDateOfJoining());
		user.setDepartment(userBean.getDepartment());
		user.setEmail(userBean.getEmailId());
		java.util.Date date = new java.util.Date();
		user.setLastUpdated(new Timestamp(date.getTime()));
		user.setPassword(userBean.getPassword());
		user.setPicture(userBean.getPicture());
		user.setPost(userBean.getPost());
		user.setProfessionalHeadline(userBean.getProfessionalHeadline());
		user.setProfessionalSummary(userBean.getProfessionalSummary());
		user.setUpdatedFields(userBean.getUpdatedFields());
		user.setValidity(userBean.getValidity());
		return user;
	}
}
