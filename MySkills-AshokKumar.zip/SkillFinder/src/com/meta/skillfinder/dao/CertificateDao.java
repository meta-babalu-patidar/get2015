
/**
 * @interface CertificateDao 
 * @since  27th november15
 * This interface declares abstract functions related to the user certification.
 * It is the responsibility of the implementation of this interface to define functions.
 */

package com.meta.skillfinder.dao;

import com.meta.skillfinder.model.Certificate;
import com.meta.skillfinder.exception.MetaSkillFinderException;
import java.util.List;


/**
 * @author kajal
 *
 */
public interface CertificateDao {
	
	/**
	 * This declares a function to add a user certificate into certificate table. 
	 * @param{Certificate} certificate
	 * @throws MetaSkillFinderException
	 */
	
    public void addUserCertificate(Certificate certificate) throws MetaSkillFinderException;
    
	/**
	 * This declares a function to add a user certificate into certificate table. 
	 * @param{int} userId
	 * @returns{List<Certificate>}
	 * @throws MetaSkillFinderException
	 */
    
    public List<Certificate> getAllCertificates(int userId) throws MetaSkillFinderException;
    
    /**
	 * This declares a function to delete a user certificate from certificate table. 
	 * @param{int} certificateId
	 * @throws MetaSkillFinderException
	 */
    
    public void deleteUserCertificate(int certificateId) throws MetaSkillFinderException;
}
