
/**
 * @class  SkillDaoImpl
 * @since  30th november15
 * @implements SkillDao
 * This class defines all the functions related to the user qualification. It contains all 
 * the functions related to qualification table.
 */

package com.meta.skillfinder.dao.impl;

import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import com.meta.skillfinder.dao.SkillDao;
import com.meta.skillfinder.model.Skill;
import com.meta.skillfinder.model.User;
import com.meta.skillfinder.exception.MetaSkillFinderException;

/**
 * @author kajal
 *
 */
@Repository("skillDao")
public class SkillDaoImpl implements SkillDao {

	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private SessionFactory sessionFactory;
	
	/**
     * private logger for this class.
     */
	
	private static final Logger log = Logger.getLogger(SkillDaoImpl.class);
	
	/**
	 * This function gets the skill of the user by skill id from the user skill table.
	 * @param{int} skillId
	 * @return{Skill} skill
	 * @throws MetaSkillFinderException 
	 */

	public Skill getSkillById(int skillId) throws MetaSkillFinderException{
		Skill skill = null;
		try {
			skill =  (Skill) sessionFactory.getCurrentSession()
					.createCriteria(Skill.class)
					.add(Restrictions.eq("skillId", skillId)).uniqueResult();
		}  catch(Exception e) {
			log.debug("Problem with skill database");
			throw new MetaSkillFinderException("Something Went wrong with skill database....");
		} 
		return skill;
	}

	/**
	 * This function gets all the skill from the skill table.
	 * @return{List<Skill>} skillList
	 * @throws MetaSkillFinderException 
	 */
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Skill> getAllSkills() throws MetaSkillFinderException {
		List<Skill> skillList  = null;
		try {
			skillList  = (List<Skill>) sessionFactory.getCurrentSession()
				.createCriteria(Skill.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		} catch(Exception e) {
			log.debug("Problem with skill database");
			throw new MetaSkillFinderException("Something Went wrong with skill database....");
		} 
		return skillList;
	}

	/**
	 * This function gets the skill id by skill name from the skill table.
	 * @return{String} skillName
	 * @throws MetaSkillFinderException 
	 */
	
	@Override
	public int getSkillId(String skillName) throws MetaSkillFinderException {
		Skill skill  = null;
		try {
			skill = (Skill) sessionFactory.getCurrentSession()
					.createCriteria(Skill.class)
					.add(Restrictions.eq("skillName", skillName)).uniqueResult();
		}  catch(Exception e) {
			log.debug("Problem with skill database");
			throw new MetaSkillFinderException("Something Went wrong with skill database....");
		} 
		return skill.getSkillId();
	}
	
	/**
	 * This function gets all users by the the skill for search functionality.
	 * @return{List<User>} searchedUsersList
	 * @throws MetaSkillFinderException 
	 */
	
	@SuppressWarnings("unchecked")
	@Override
	public List<User> getUsersBySkillId(int skillId, int userId) throws MetaSkillFinderException {
		List<User> searchedUsersList = null;
		try {
			String hql = "select u from User u " +
		               "join u.userSkills s " +
		               "where s.skillId = :skillId";
			Query query =  sessionFactory.getCurrentSession().createQuery(hql);
			query.setParameter("skillId",skillId);
			searchedUsersList = query.list();
		} catch(Exception e) {
			log.debug("Problem with skill database");
			throw new MetaSkillFinderException("Something Went wrong with skill database....");
		} 
		return searchedUsersList;
	}
	
}
