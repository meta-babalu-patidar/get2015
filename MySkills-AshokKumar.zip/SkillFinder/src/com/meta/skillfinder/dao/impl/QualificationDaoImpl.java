
/**
 * @class  QualificationDaoImpl
 * @since  30th november15
 * @implements QualificationDao
 * This class defines all the functions related to the user qualification. It contains all 
 * the functions related to qualification table.
 */

package com.meta.skillfinder.dao.impl;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.meta.skillfinder.dao.QualificationDao;
import com.meta.skillfinder.model.Qualification;
import com.meta.skillfinder.exception.MetaSkillFinderException;
import java.util.List;

/**
 * @author kajal
 *
 */
@Repository("qualificationDao")
public class QualificationDaoImpl implements QualificationDao {

	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private SessionFactory sessionFactory;
	
	/**
     * private logger for this class.
     */
	
	private static final Logger log = Logger.getLogger(QualificationDaoImpl.class);

	/**
	 * This function gets the latest qualification of the user from the qualification table.
	 * @param{int} userId
	 * @return{Qualification} qualification
	 * @throws MetaSkillFinderException 
	 */

	public Qualification getLatestQualification(int userId) throws MetaSkillFinderException {
		Qualification qualification = null;
		try {
			DetachedCriteria latestQualificationYear = DetachedCriteria.forClass(
					Qualification.class).setProjection(
					Projections.max("obtainingYear"));
			Criteria crit = sessionFactory.getCurrentSession().createCriteria(
					Qualification.class);
			crit.add(Restrictions.eq("userId", userId));
			crit.add(Property.forName("obtainingYear").eq(latestQualificationYear));
			qualification =  (Qualification) crit.uniqueResult();
		} catch(Exception e) {
			log.debug("Problem with qualification database");
			throw new MetaSkillFinderException("Something Went wrong with qualification database....");
		}
		return qualification;
	}

	/**
	 * This function gets all the qualifications of the user from the qualification table.
	 * @param{int} userId
	 * @return{List<Qualification>} qualificationList
	 * @throws MetaSkillFinderException 
	 */

	@SuppressWarnings("unchecked")
	public List<Qualification> getAllQualifications(int userId) throws MetaSkillFinderException {
		List<Qualification> qualificationList = null;
		try {
			qualificationList = sessionFactory
					.getCurrentSession().createCriteria(Qualification.class)
					.add(Restrictions.eq("userId", userId)).list();
		} catch(Exception e) {
			log.debug("Problem with qualification database");
			throw new MetaSkillFinderException("Something Went wrong with qualification database....");
		}
		return qualificationList;
	}

	/**
	 * This function adds a qualification of the user into the qualification table.
	 * @param{Qualification} qualification
	 * @throws MetaSkillFinderException 
	 */

	public void addUserQualification(Qualification qualification) throws MetaSkillFinderException {
		try {
			sessionFactory.getCurrentSession().saveOrUpdate(qualification);
		} catch(Exception e) {
			log.debug("Problem with qualification database");
			throw new MetaSkillFinderException("Something Went wrong with qualification database....");
		}
	}
	
	/**
	 * This function deletes a qualification of the user from the qualification table.
	 * @param{int} qualificationId
	 * @throws MetaSkillFinderException 
	 */
	
	public void deleteQualification(int qualificationId) throws MetaSkillFinderException {
		try {
			Qualification qualification = (Qualification) sessionFactory.getCurrentSession().createCriteria(Qualification.class)
    			.add(Restrictions.eq("qualificationId", qualificationId) ).uniqueResult();
    	sessionFactory.getCurrentSession().delete(qualification);
		} catch(Exception e) {
			log.debug("Problem with qualification database");
			throw new MetaSkillFinderException("Something Went wrong with qualification database....");
		}
	}
}
