
/**
 * @class  ConnectionDaoImpl
 * @author Kajal
 * @since  26th november15
 * @implements ContactDetailsDao
 * This class defines all the functions related to the user contact details. It contains all 
 * the functions related to contact details table.
 */

package com.meta.skillfinder.dao.impl;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.apache.log4j.Logger;
import com.meta.skillfinder.exception.MetaSkillFinderException;
import com.meta.skillfinder.dao.ContactDetailsDao;
import com.meta.skillfinder.model.ContactDetails;

/**
 * @author kajal
 *
 */
@Repository("contactDetailsDao")
public class ContactDetailsDaoImpl implements ContactDetailsDao {

	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private SessionFactory sessionFactory;
	
	 /**
     * private logger for this class.
     */
    
    private static final Logger log = Logger.getLogger(ContactDetailsDaoImpl.class);
	
    /**
	 * This function gets contact details of the user from contact details table.
	 * @param{int} contactId
	 * @returns{ContactDetails} contactDetails
	 * @throws MetaSkillFinderException 
	 */
	
    public ContactDetails getContactDetails(int contactId) throws MetaSkillFinderException {
		ContactDetails contactDetails = null;
		try {
			contactDetails =  (ContactDetails) sessionFactory.getCurrentSession().createCriteria(ContactDetails.class).add(Restrictions.eq("contactId", contactId)).uniqueResult();
		} catch(Exception e) {
			log.debug("contact details database problem in getting contact details");
			throw new MetaSkillFinderException("Something Went wrong with....");
		}
		return contactDetails;
	}
	
	/**
	 * This function adds contact details of the user in contact details table.
	 * @param{int} contactId
	 * @returns{ContactDetails} contactDetails
	 * @throws MetaSkillFinderException 
	 */
	
    public int addContactDetails(ContactDetails contactDetails) throws MetaSkillFinderException {
		try {
			sessionFactory.getCurrentSession().saveOrUpdate(contactDetails);
		} catch(Exception e) {
			log.debug("contact details database problem in adding contact details");
			throw new MetaSkillFinderException("Something Went wrong with....");
		}
		return contactDetails.getContactId();
	}

}
