
/**
 * @class  CertificateDaoImpl
 * @since  27th november15
 * @implements CertificateDao
 * This class defines all the functions related to the user certificate. It contains all 
 * the functions related to certificate table.
 */

package com.meta.skillfinder.dao.impl;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import com.meta.skillfinder.exception.MetaSkillFinderException;
import org.springframework.stereotype.Repository;
import com.meta.skillfinder.dao.CertificateDao;
import com.meta.skillfinder.model.Certificate;
import java.util.List;

/**
 * @author kajal
 *
 */
@Repository("certificateDao")
public class CertificateDaoImpl implements CertificateDao {

	/**
	 * Defining dependencies
	 */
	
    @Autowired
    private SessionFactory sessionFactory;
    
    /**
     * private logger for this class.
     */
    
    private static final Logger log = Logger.getLogger(CertificateDaoImpl.class);
    
	/**
	 * This function adds a new certificate to a user in certificate table.
	 * @param{Certificate} certificate
	 * @throws MetaSkillFinderException 
	 */
    
    public void addUserCertificate(Certificate certificate) throws MetaSkillFinderException {
		try {

			sessionFactory.getCurrentSession().saveOrUpdate(certificate);

		} catch (Exception e) {
			log.debug("certificate database problem in adding certificate");
			throw new MetaSkillFinderException("Something Went wrong with....");
		}
	}
        
    /**
	 * This function gets all the certificates corresponding to a specific user in certificate table.
	 * @param{integer} userId
	 * @throws MetaSkillFinderException 
	 * @returns{List<Certificate>} certificateList
	 */
	
	@SuppressWarnings("unchecked")
	public List<Certificate> getAllCertificates(int userId) throws MetaSkillFinderException {
		List<Certificate> certificateList = null;
		try {
			certificateList = sessionFactory.getCurrentSession().createCriteria(Certificate.class).add(Restrictions.eq("userId", userId)).list();
		} catch (Exception e) {
			log.debug("certificate database problem in retrieving certificate");
			throw new MetaSkillFinderException("Something Went wrong with....");
		}
		return certificateList;
	}

	/**
	 * This function deletes the certificates corresponding to a specific user in certificate table by certificate id.
	 * @param{int} certificateId
	 * @throws MetaSkillFinderException 
	 */
	
    public void deleteUserCertificate(int certificateId) throws MetaSkillFinderException {
    	Certificate certificate = null;
    	try {
    		certificate = (Certificate) sessionFactory.getCurrentSession().createCriteria(Certificate.class)
    			.add(Restrictions.eq("certificateId", certificateId) ).uniqueResult();
    		sessionFactory.getCurrentSession().delete(certificate);
    	} catch(Exception e) {
    		log.debug("certificate database problem in deleting user certificate");
			throw new MetaSkillFinderException("Something Went wrong with....");
    	}	
    }
}
