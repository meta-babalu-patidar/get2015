
/**
 * @class  EndorseDaoImpl
 * @since  26th november15
 * @implements EndorseDao
 * This class defines all the functions related to the user endorse details. It contains all 
 * the functions related to endorse table.
 */

package com.meta.skillfinder.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.meta.skillfinder.dao.EndorseDao;
import com.meta.skillfinder.exception.MetaSkillFinderException;
import com.meta.skillfinder.model.Endorse;
import com.meta.skillfinder.model.Skill;

/**
 * @author kajal
 *
 */
@Repository("endorseDao")
public class EndorseDaoImpl implements EndorseDao {

	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private SessionFactory sessionFactory;
	
	 /**
     * private logger for this class.
     */
    
    private static final Logger log = Logger.getLogger(EndorseDaoImpl.class);
	
    /**
	 * This function adds an endorsement of the user into endorsement table.
	 * @param{Endorse} endorse
	 * @throws MetaSkillFinderException 
	 */
	
    public void addEndorsement(Endorse endorse) throws MetaSkillFinderException{
		try {
			sessionFactory.getCurrentSession().saveOrUpdate(endorse);
		} catch(Exception e) {
			log.debug("endorse database problem in getting endorse");
			throw new MetaSkillFinderException("Something Went wrong with....");
		}
	}

    /**
	 * This function returns a map of skill id as key and value as o or 1 defining if the user in session has
	 * already endorsed the corresponding skill of the user he is visiting profile of.
	 * @param{int} endorserId
	 * @param{int} endorsedUserId
	 * @param{List<Skill>} endorsedUserSkillList
	 * @returns{Map<Integer,Integer>}  mapOfEndorsedSkills
	 * @throws MetaSkillFinderException 
	 */

    public Map<Integer,Integer> getMapOfEndorsedSkills(int endorserId, int endorsedUserId, List<Skill> endorsedUserSkillList) throws MetaSkillFinderException{
		
		Map<Integer,Integer> mapOfEndorsedSkills = new HashMap<Integer,Integer>();
		try {
			for(Skill skill : endorsedUserSkillList)
			{
				int skillId = skill.getSkillId();
				Endorse endorse =  (Endorse) sessionFactory.getCurrentSession().createCriteria(Endorse.class)
						.add(Restrictions.eq("userSkillId", skillId))
						.add(Restrictions.eq("endorserUserId", endorserId))
						.add(Restrictions.eq("endorsedUserId", endorsedUserId))
						.uniqueResult();
				if(endorse!=null)
				{
					mapOfEndorsedSkills.put(skillId, 1);
				}
				else
				{
					mapOfEndorsedSkills.put(skillId, 0);
				}	
			}
		} catch(Exception e) {
			log.debug("endorse database problem in getting endorse");
			throw new MetaSkillFinderException("Something Went wrong with....");
		}
		return mapOfEndorsedSkills;
	}
	
    /**
	 * This function returns a map of skill id as key and no. of endorse for it as its value for the user in session.
	 * @param{int} userId
	 * @param{List<Skill>} userSkillList 
	 * @returns{Map<Integer,Integer>}  mapOfSkills
	 * @throws MetaSkillFinderException 
	 */
	
    @SuppressWarnings("unchecked")
	public Map<Integer,Integer> getMapOfSkills(int userId, List<Skill> userSkillList) throws MetaSkillFinderException {
		Map<Integer,Integer> mapOfSkills = new HashMap<Integer,Integer>();
		try {
			for(Skill skill : userSkillList)
			{
				int skillId = skill.getSkillId();
				List<Endorse> skillList =  sessionFactory.getCurrentSession().createCriteria(Endorse.class)
						.add(Restrictions.eq("userSkillId", skillId))
						.add(Restrictions.eq("endorsedUserId", userId))
						.list();
				mapOfSkills.put(skillId, skillList.size());
			}
		} catch(Exception e) {
			log.debug("endorse database problem in getting endorse");
			throw new MetaSkillFinderException("Something Went wrong with....");
		}
		return mapOfSkills;
	}
	
    /**
	 * This function deletes an endorsement of the user from the endorsement table.
	 * @param{int} endorserId
	 * @param{int} endorsedUserId
	 * @param{int} skillId
	 * @throws MetaSkillFinderException 
	 */
	
    public void deleteEndorsement(int endorserId, int endorsedUserId, int skillId) throws MetaSkillFinderException{
		try {
			Endorse endorse = (Endorse) sessionFactory.getCurrentSession().createCriteria(Endorse.class)
	    			.add(Restrictions.eq("endorserUserId", endorserId) )
	    			.add(Restrictions.eq("endorsedUserId", endorsedUserId) )
	    			.add(Restrictions.eq("userSkillId", skillId) )
	    			.uniqueResult();
	    	sessionFactory.getCurrentSession().delete(endorse);
		} catch(Exception e) {
			log.debug("endorse database problem in getting endorse");
			throw new MetaSkillFinderException("Something Went wrong with....");
		}
	}
	
}
