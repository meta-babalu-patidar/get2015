
/**
 * @class  ConnectionDaoImpl
 * @since  26th november15
 * @implements ConnectionDaoImpl
 * This class defines all the functions related to the user connection. It contains all 
 * the functions related to connection table.
 */

package com.meta.skillfinder.dao.impl;

import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.meta.skillfinder.exception.MetaSkillFinderException;
import com.meta.skillfinder.dao.ConnectionDao;
import com.meta.skillfinder.model.Connection;
import com.meta.skillfinder.model.User;

/**
 * @author kajal
 *
 */
@Repository("connectionDao")
public class ConnectionDaoImpl implements ConnectionDao {

	/**
	 * Defining dependencies
	 */
	
    @Autowired
    private SessionFactory sessionFactory;

    /**
     * private logger for this class.
     */
    
    private static final Logger log = Logger.getLogger(ConnectionDaoImpl.class);
    
	/**
	 * This function gets list of all the connections from the connection table.
	 * @param{int} userId
	 * @returns{List<User>} connectedUsersList
	 * @throws MetaSkillFinderException 
	 */

    @SuppressWarnings("unchecked")
	public List<User> getAllConnections(int userId) throws MetaSkillFinderException {
		List<User> connectedUsersList = null;
		try {
			String hql = "from User u where (u.userId) in ("
					+ " select c.connectionUserId from Connection c where c.requestStatus=3 and c.userId="
					+ userId + ")";
			connectedUsersList = sessionFactory.getCurrentSession().createQuery(hql).list();
		} catch (Exception e) {
			log.debug("connection database problem in getting all connections");
			throw new MetaSkillFinderException("Something Went wrong with....");
		}
		return connectedUsersList;

	}

	/**
	 * This function gets list of all not connected users from the user table.
	 * @param{int} userId
	 * returns{List<User>} notConnectedUsersList
	 * @throws MetaSkillFinderException 
	 */

    @SuppressWarnings("unchecked")
	public List<User> getAllNotConnectedUsers(int userId) throws MetaSkillFinderException {
    	List<User> notConnectedUsersList = null;
    	try {
	        String hql = "from User u where (u.userId) not in ("
	                + " select c.connectionUserId from Connection c where c.requestStatus!=2 and c.userId=" + userId + ") and u.userId!=" + userId;
	        notConnectedUsersList = sessionFactory.getCurrentSession().createQuery(hql).list();
    	} catch(Exception e) {
    		log.debug("connection database problem in getting all non connections");
    		throw new MetaSkillFinderException("Something Went wrong with....");
    	}
        return notConnectedUsersList;
    }

	/**
	 * This function sends the connection request.
	 * @param{Connection} connection
	 * @throws MetaSkillFinderException 
	 */
    
    public void sendConnectionRequest(Connection connection) throws MetaSkillFinderException {
    	try {
    		sessionFactory.getCurrentSession().saveOrUpdate(connection);
    	} catch(Exception e) {
    		log.debug("connection database problem in sending connection request");
    		throw new MetaSkillFinderException("Something Went wrong with....");
    	}
        
    }

	/**
	 * This function gets list of all the users to whom request is sent.
	 * @param{int} userId
	 * returns{List<User>} usersWithRequestSentList
	 * @throws MetaSkillFinderException 
	 */
    
    @SuppressWarnings("unchecked")
	public List<User> getUsersWithRequestSentList(int userId) throws MetaSkillFinderException {
    	 List<User> usersWithRequestSentList = null;
    	try {
	        String hql = "from User u where (u.userId) in ("
	                + " select c.connectionUserId from Connection c where c.requestStatus=2 and c.userId=" + userId + ") and u.userId!=" + userId;
	        usersWithRequestSentList = sessionFactory.getCurrentSession().createQuery(hql).list();
    	} catch(Exception e) {
    		log.debug("connection database problem in getting  users already sent connections");
    		throw new MetaSkillFinderException("Something Went wrong with....");
    	}
        return usersWithRequestSentList;
    }

	/**
	 * This function gets list of all the users to whom neither request is sent nor request is pending 
	 * from the user table.
	 * @param{int} userId
	 * returns{List<User>} usersWithRequestSentList
	 * @throws MetaSkillFinderException 
	 */
    
    @SuppressWarnings("unchecked")
	public List<User> getUnknownUsersList(int userId) throws MetaSkillFinderException {
    	List<User> usersWithRequestSentList = null;
    	try {
	        String hql = "from User u where (u.userId) not in ("
	                + " select c.connectionUserId from Connection c where c.userId=" + userId + ") and u.userId!=" + userId;
	        usersWithRequestSentList = sessionFactory.getCurrentSession().createQuery(hql).list();
    	} catch(Exception e) {
    		log.debug("connection database problem in getting all unknown users");
    		throw new MetaSkillFinderException("Something Went wrong with....");
    	}
        return usersWithRequestSentList;
    }

	/**
	 * This function gets list of all the users from whom connection request is received but yet not accepted.
	 * @param{int} userId
	 * returns{List<User>} usersWithRequestSentList
	 * @throws MetaSkillFinderException 
	 */
    
    @SuppressWarnings("unchecked")
	public List<User> getPendingConnectionRequestList(int userId) throws MetaSkillFinderException {
    	List<User> usersWithRequestSentList = null;
    	try {
	        String hql = "from User u where (u.userId) in ("
	                + " select c.connectionUserId from Connection c where c.requestStatus=1 and c.userId=" + userId + ") and u.userId!=" + userId;
	        usersWithRequestSentList = sessionFactory.getCurrentSession().createQuery(hql).list();
    	} catch(Exception e) {
    		log.debug("connection database problem in getting all pending connection request");
    		throw new MetaSkillFinderException("Something Went wrong with....");
    	}
        return usersWithRequestSentList;
    }

	/**
	 * This function gets the pending connection from connection table.
	 * @param{int} userId
	 * @param{int} requestedUserId
	 * returns{Connection} connection
	 * @throws MetaSkillFinderException 
	 */
    
    public Connection getPendingConnection(int userId, int requestedUserId) throws MetaSkillFinderException {
    	Connection connection = null;
    	try {
	        connection =  (Connection) sessionFactory.getCurrentSession()
	                .createCriteria(Connection.class)
	                .add(Restrictions.eq("userId", userId))
	                .add(Restrictions.eq("connectionUserId", requestedUserId))
	                .uniqueResult();
    	} catch(Exception e) {
    		log.debug("connection database problem in getting all pending connections");
    		throw new MetaSkillFinderException("Something Went wrong with....");
    	}
        return connection;
    }
    
    /**
	 * This function gets the request status of connection from connection table.
	 * @param{int} connectedUserId
	 * @param{int} sessionUserId
	 * returns{int} requestStatus
	 * @throws MetaSkillFinderException 
	 */

   public int getRequestStatus(int connectedUserId, int sessionUserId) throws MetaSkillFinderException{
    	 
    	int requestStatus = 0;
    	try {
    		Connection connection = (Connection) sessionFactory.getCurrentSession()
                    .createCriteria(Connection.class)
                    .add(Restrictions.eq("userId", sessionUserId))
                    .add(Restrictions.eq("connectionUserId", connectedUserId))
                    .uniqueResult();
       	 if(connection!=null)
       		 requestStatus = connection.getRequestStatus();
    	} catch(Exception e) {
    		log.debug("connection database problem in getting all pending connections");
    		throw new MetaSkillFinderException("Something Went wrong with....");
    	}
    	return requestStatus;
    }
}
