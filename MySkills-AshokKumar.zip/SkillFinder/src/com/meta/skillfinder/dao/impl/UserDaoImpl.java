
/**
 * @class  UserDaoImpl
 * @since  30th november15
 * @implements UserDao
 * This class defines all the functions related to the user. It contains all 
 * the functions related to user table.
 */

package com.meta.skillfinder.dao.impl;

import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.meta.skillfinder.dao.UserDao;
import com.meta.skillfinder.model.Skill;
import com.meta.skillfinder.model.User;
import com.meta.skillfinder.exception.MetaSkillFinderException;

/**
 * @author kajal
 *
 */
@Repository("userDao")
public class UserDaoImpl implements UserDao {

	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private SessionFactory sessionFactory;
	
	/**
     * private logger for this class.
     */
	
	private static final Logger log = Logger.getLogger(UserDaoImpl.class);
	
	/**
	 * This function adds a user in the user table.
	 * @param{User} user
	 * @throws MetaSkillFinderException 
	 */
	
	public void addUser(User user) throws MetaSkillFinderException {
		try {
			if(user.getContactId() > 0) {
				
			}
			else {
				user.setContactId(0);
			}
			sessionFactory.getCurrentSession().saveOrUpdate(user);
		} catch(Exception e) {
			log.debug("Problem with user database");
			throw new MetaSkillFinderException("Something Went wrong with user database....");
		} 
	}
	
	/**
	 * This function returns a user by email id from the user table.
	 * @param{String} emailId
	 * @throws MetaSkillFinderException 
	 */
	
	public User getUser(String emailId) throws MetaSkillFinderException {
		User temp;
		try {
			temp =  (User) sessionFactory.getCurrentSession().createCriteria(User.class).add(Restrictions.eq("email", emailId)).uniqueResult();
		} catch(Exception e) {
			log.debug("Problem with user database");
			throw new MetaSkillFinderException("Something Went wrong with user database....");
		} 
		return temp;
	}
	
	/**
	 * This function returns all user skills by email id from the user table.
	 * @param{int} userId
	 * @return{List<Skill>} userSkills
	 * @throws MetaSkillFinderException 
	 */
	
	public List<Skill> getUserSkills(int userId) throws MetaSkillFinderException {
		List<Skill> userSkills = new ArrayList<Skill>();
		User user = null;
		try {
			Criteria criteria = sessionFactory.getCurrentSession().createCriteria(User.class);
			criteria.add(Restrictions.eq("userId", userId));
			user = (User) criteria.uniqueResult();
		} catch(Exception e) {
			log.debug("Problem with user database");
			throw new MetaSkillFinderException("Something Went wrong with user database....");
		} 
		userSkills.addAll(user.getUserSkills());
        return userSkills;
	}


	/**
	 * This function updates user in the user table.
	 * @param{User} user
	 * @throws MetaSkillFinderException 
	 */
	
	@Override
	public void updateUser(User user)  throws MetaSkillFinderException {
		try {
			sessionFactory.getCurrentSession().saveOrUpdate(user);
		}  catch(Exception e) {
			log.debug("Problem with user database");
			throw new MetaSkillFinderException("Something Went wrong with user database....");
		} 
		
	}
	
	/**
	 * This function returns the contact details id of user from the user table.
	 * @param{User} user
	 * @throws MetaSkillFinderException 
	 */
	
	public int getContactDetailsId(int userId) throws MetaSkillFinderException {
		User tempUser = null;
		int contactId = 0;
		try {
			tempUser =  (User) sessionFactory.getCurrentSession().createCriteria(User.class).add(Restrictions.eq("userId", userId)).uniqueResult();
			if(tempUser.getContactId()!=0) {
				contactId = tempUser.getContactId();
			}
		} catch(Exception e) {
			log.debug("Problem with user database");
			throw new MetaSkillFinderException("Something Went wrong with user database....");
		} 
		return contactId;
	}

}