
/**
 * @class  ExperienceDaoImpl
 * @since  26th november15
 * @implements ExperienceDao
 * This class defines all the functions related to the user experience. It contains all 
 * the functions related to experience table.
 */

package com.meta.skillfinder.dao.impl;

import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.meta.skillfinder.exception.MetaSkillFinderException;
import com.meta.skillfinder.dao.ExperienceDao;
import com.meta.skillfinder.model.Experience;

/**
 * @author kajal
 *
 */
@Repository("experienceDao")
public class ExperienceDaoImpl implements ExperienceDao {

	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private SessionFactory sessionFactory;
	
	 /**
     * private logger for this class.
     */
	
	private static final Logger log = Logger.getLogger(ConnectionDaoImpl.class);
	
	/**
	 * This function gets an experience of the user from the experience table.
	 * @param{int} userId
	 * @throws MetaSkillFinderException 
	 */
	
	@SuppressWarnings("unchecked")
	public List<Experience> getExperiences(int userId) throws MetaSkillFinderException {  
		List<Experience> experienceList = null;
		try {
			experienceList = sessionFactory.getCurrentSession().createCriteria(Experience.class).add(Restrictions.eq("userId", userId)).list();
		} catch(Exception e) {
			log.debug("Problem with experience database");
			throw new MetaSkillFinderException("Something Went wrong with experience database....");
		}
		return experienceList;
	}
	
	/**
	 * This function adds an experience of the user into experience table.
	 * @param{Experience} experience
	 * @throws MetaSkillFinderException 
	 */
	
	public void addUserExperience(Experience experience) throws MetaSkillFinderException {
		try {
			sessionFactory.getCurrentSession().saveOrUpdate(experience);
		} catch(Exception e) {
			log.debug("Problem with experience database");
			throw new MetaSkillFinderException("Something Went wrong with experience database....");
		}
		
	}
	
	/**
	 * This function deletes an experience of the user from experience table.
	 * @param{int} experienceId
	 * @throws MetaSkillFinderException 
	 */
	
	public void deleteExperience(int experienceId) throws MetaSkillFinderException {
		Experience experience = null;
		try {
			experience = (Experience) sessionFactory.getCurrentSession().createCriteria(Experience.class)
    			.add(Restrictions.eq("experienceId", experienceId) ).uniqueResult();
			sessionFactory.getCurrentSession().delete(experience);
		} catch(Exception e) {
			log.debug("Problem with experience database");
			throw new MetaSkillFinderException("Something Went wrong with experience database....");
		}
	}
}
