
/**
 * @interface  ContactDetailsDao
 * @author Kajal
 * @since  26th november15
 * This class defines all the functions related to the user contact details. It contains all 
 * the functions related to contact details table.
 */

package com.meta.skillfinder.dao;

import com.meta.skillfinder.model.ContactDetails;
import com.meta.skillfinder.exception.MetaSkillFinderException;

/**
 * @author kajal
 *
 */
public interface ContactDetailsDao {
	
	/**
	 * This declares a function gets contact details of the user from contact details table.
	 * @param{int} contactId
	 * @returns{ContactDetails} contactDetails
	 * @throws MetaSkillFinderException 
	 */
	
	public ContactDetails getContactDetails(int contactId) throws MetaSkillFinderException;
	
	/**
	 * This declares a function adds contact details of the user in contact details table.
	 * @param{int} contactId
	 * @returns{ContactDetails} contactDetails
	 * @throws MetaSkillFinderException 
	 */
	
	public int addContactDetails(ContactDetails contactDetails) throws MetaSkillFinderException;
}
