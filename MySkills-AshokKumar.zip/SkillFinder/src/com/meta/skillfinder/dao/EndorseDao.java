
/**
 * @interface  EndorseDao
 * @since  26th november15
 * This interface defines all the abstract functions related to the user connection. It contains all 
 * the functions related to connection table.
 */

package com.meta.skillfinder.dao;

import java.util.List;
import java.util.Map;
import com.meta.skillfinder.exception.MetaSkillFinderException;
import com.meta.skillfinder.model.Endorse;
import com.meta.skillfinder.model.Skill;


/**
 * @author kajal
 *
 */
public interface EndorseDao {
	
	/**
	 * This declares a function which adds an endorsement of the user into endorsement table.
	 * @param{Endorse} endorse
	 * @throws MetaSkillFinderException 
	 */
	
	public void addEndorsement(Endorse endorse) throws MetaSkillFinderException;
	
	 /**
	  * This declares a function which returns a map of skill id as key and value as o or 1 defining if the user in session has
	  * already endorsed the corresponding skill of the user he is visiting profile of.
	  * @param{int} endorserId
	  * @param{int} endorsedUserId
	  * @param{List<Skill>} endorsedUserSkillList
	  * @returns{Map<Integer,Integer>}  mapOfEndorsedSkills
	  * @throws MetaSkillFinderException 
	  */
	
	public Map<Integer,Integer> getMapOfEndorsedSkills(int endorserId, int endorsedUserId, List<Skill> endorsedUserSkillList) throws MetaSkillFinderException;
	
	/**
	 * This declares a function which returns a map of skill id as key and no. of endorse for it as its value for the user in session.
	 * @param{int} userId
	 * @param{List<Skill>} userSkillList 
	 * @returns{Map<Integer,Integer>}  mapOfSkills
	 * @throws MetaSkillFinderException 
	 */
	
	public Map<Integer,Integer> getMapOfSkills(int userId, List<Skill> userSkillList) throws MetaSkillFinderException;
	
	/**
	 * This declares a function which deletes an endorsement of the user from the endorsement table.
	 * @param{int} endorserId
	 * @param{int} endorsedUserId
	 * @param{int} skillId
	 * @throws MetaSkillFinderException 
	 */
	
	public void deleteEndorsement(int endorserId, int endorsedUserId, int skillId) throws MetaSkillFinderException;
}
