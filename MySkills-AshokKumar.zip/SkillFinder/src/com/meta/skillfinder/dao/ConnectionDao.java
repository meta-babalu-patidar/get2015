/**
 * @interface  ConnectionDaoImpl
 * @since  26th november15
 * This interface defines all the abstract functions related to the user connection. It contains all 
 * the functions related to connection table.
 */

package com.meta.skillfinder.dao;

import java.util.List;
import com.meta.skillfinder.model.Connection;
import com.meta.skillfinder.model.User;
import com.meta.skillfinder.exception.MetaSkillFinderException;

/**
 * @author kajal
 *
 */
public interface ConnectionDao {
	
	/**
	 * This function gets list of all the connections from the connection table.
	 * @param{int} userId
	 * returns{List<User>} connectedUsersList
	 * @throws MetaSkillFinderException 
	 */
	
	public List<User> getAllConnections(int userId) throws MetaSkillFinderException;
	
	/**
	 * This function gets list of all not connected users from the user table.
	 * @param{int} userId
	 * returns{List<User>} notConnectedUsersList
	 * @throws MetaSkillFinderException 
	 */
	
	public List<User> getAllNotConnectedUsers(int userId) throws MetaSkillFinderException;
	
	/**
	 * This function sends the connection request.
	 * @param{Connection} connection
	 * @throws MetaSkillFinderException 
	 */
	
	public void sendConnectionRequest(Connection connection) throws MetaSkillFinderException;
	
	/**
	 * This function gets list of all the users to whom request is sent.
	 * @param{int} userId
	 * returns{List<User>} usersWithRequestSentList
	 * @throws MetaSkillFinderException 
	 */
        
    public List<User> getUsersWithRequestSentList(int userId) throws MetaSkillFinderException;
    
	/**
	 * This function gets list of all the users to whom neither request is sent nor request is pending 
	 * from the user table.
	 * @param{int} userId
	 * returns{List<User>} usersWithRequestSentList
	 * @throws MetaSkillFinderException 
	 */
        
    public List<User> getUnknownUsersList(int userId) throws MetaSkillFinderException;
    
	/**
	 * This function gets list of all the users from whom connection request is received but yet not accepted.
	 * @param{int} userId
	 * returns{List<User>} usersWithRequestSentList
	 * @throws MetaSkillFinderException 
	 */
        
    public List<User> getPendingConnectionRequestList(int userId) throws MetaSkillFinderException;
    
	/**
	 * This function gets the pending connection from connection table.
	 * @param{int} userId
	 * @param{int} requestedUserId
	 * returns{Connection} connection
	 * @throws MetaSkillFinderException 
	 */
        
    public Connection getPendingConnection(int userId, int requestedUserId) throws MetaSkillFinderException;
        
	/**
	 * This function gets the request status of connection from connection table.
	 * @param{int} connectedUserId
	 * @param{int} sessionUserId
	 * returns{int} requestStatus
	 * @throws MetaSkillFinderException 
	 */
    
    public int getRequestStatus(int connectedUserId, int sessionUserId) throws MetaSkillFinderException;
}
