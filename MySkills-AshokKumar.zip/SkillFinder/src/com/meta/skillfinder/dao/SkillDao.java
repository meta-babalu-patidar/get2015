package com.meta.skillfinder.dao;

import java.util.List;
import com.meta.skillfinder.exception.MetaSkillFinderException;
import com.meta.skillfinder.model.Skill;
import com.meta.skillfinder.model.User;


/**
 * @author kajal
 *
 */
public interface SkillDao {
	
	/**
	 * This function gets the skill of the user by skill id from the user skill table.
	 * @param{int} skillId
	 * @return{Skill} skill
	 * @throws MetaSkillFinderException 
	 */
	
	public int getSkillId(String skillName) throws MetaSkillFinderException;
	
	/**
	 * This function gets all the skill from the skill table.
	 * @return{List<Skill>} skillList
	 * @throws MetaSkillFinderException 
	 */

	public Skill getSkillById(int skillId) throws MetaSkillFinderException;
	
	/**
	 * This function gets the skill id by skill name from the skill table.
	 * @return{String} skillName
	 * @throws MetaSkillFinderException 
	 */

	public List<Skill> getAllSkills() throws MetaSkillFinderException;
	
	/**
	 * This function gets all users by the the skill for search functionality.
	 * @return{List<User>} searchedUsersList
	 * @throws MetaSkillFinderException 
	 */
	
	public List<User> getUsersBySkillId(int skillId, int userId) throws MetaSkillFinderException;
	
}
