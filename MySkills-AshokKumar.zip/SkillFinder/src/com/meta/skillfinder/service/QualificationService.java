
/**
 * @interface  QualificationDao
 * @since 30th november15
 * This interface defines all the abstract functions related to the user qualification. It contains all 
 * the functions related to qualification table.
 */

package com.meta.skillfinder.service;

import com.meta.skillfinder.exception.MetaSkillFinderException;
import com.meta.skillfinder.model.Qualification;
import java.util.List;

/**
 * @author kajal
 *
 */
public interface QualificationService {
	
	/**
	 * This function gets the latest qualification of the user from the qualification table.
	 * @param{int} userId
	 * @return{Qualification} qualification
	 * @throws MetaSkillFinderException 
	 */
	
	public Qualification getLatestQualification(int userId) throws MetaSkillFinderException;
	
	/**
	 * This function gets all the qualifications of the user from the qualification table.
	 * @param{int} userId
	 * @return{List<Qualification>} qualificationList
	 * @throws MetaSkillFinderException 
	 */
    
    public List<Qualification> getAllQualifications(int userId) throws MetaSkillFinderException;
    
    /**
	 * This function adds a qualification of the user into the qualification table.
	 * @param{Qualification} qualification
	 * @throws MetaSkillFinderException 
	 */
    
    public void addUserQualification(Qualification qualification) throws MetaSkillFinderException;
    
    /**
	 * This function deletes a qualification of the user from the qualification table.
	 * @param{int} qualificationId
	 * @throws MetaSkillFinderException 
	 */
    
    public void deleteQualification(int qualificationId) throws MetaSkillFinderException;
}
