/**
 * @interface  UserDao
 * @since 30th november15
 * This interface defines all the abstract functions related to the user. It contains all 
 * the functions related to user.
 */

package com.meta.skillfinder.service;

import java.util.List;
import com.meta.skillfinder.exception.MetaSkillFinderException;
import com.meta.skillfinder.model.User;
import com.meta.skillfinder.model.Skill;

/**
 * @author kajal
 *
 */

public interface UserService {
	
	/**
	 * This function adds a user in the user table.
	 * @param{User} user
	 * @throws MetaSkillFinderException 
	 */
	public void addUser(User user) throws MetaSkillFinderException;
	
	/**
	 * This function returns the contact details id of user from the user table.
	 * @param{User} user
	 * @throws MetaSkillFinderException 
	 */
	public void updateUser(User user) throws MetaSkillFinderException;
		
	/**
	 * This function returns a user by email id from the user table.
	 * @param{String} emailId
	 * @throws MetaSkillFinderException 
	 */
	public User getUser(String emailId) throws MetaSkillFinderException;
	
	/**
	 * This function returns all user skills by email id from the user table.
	 * @param{int} userId
	 * @return{List<Skill>} userSkills
	 * @throws MetaSkillFinderException 
	 */
	public List<Skill> getUserSkills(int userId) throws MetaSkillFinderException;
	
	/**
	 * This function updates user in the user table.
	 * @param{User} user
	 * @throws MetaSkillFinderException 
	 */
	public int getContactDetailsId(int userId) throws MetaSkillFinderException;
}