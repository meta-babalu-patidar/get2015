
/**
 * @interface CertificateDao 
 * @author kajal
 * @since  27th november15
 * This interface declares abstract functions related to the connections at service layer.
 * It is the responsibility of the implementation of this interface to define functions.
 */

package com.meta.skillfinder.service;

import java.util.List;
import com.meta.skillfinder.exception.MetaSkillFinderException;
import com.meta.skillfinder.model.Connection;
import com.meta.skillfinder.model.User;

public interface ConnectionService {

	/**
	 * This function declares a function at service layer which gets list of all the connections 
	 * from the connection table.
	 * @param{int} userId
	 * returns{List<User>} connectedUsersList
	 * @throws MetaSkillFinderException 
	 */
	
	public List<User> getAllConnections(int userId) throws MetaSkillFinderException;
	
	/**
	 * This function at service layer which gets list of all not connected users from the user table.
	 * @param{int} userId
	 * returns{List<User>} notConnectedUsersList
	 * @throws MetaSkillFinderException 
	 */
	
	public List<User> getAllNotConnectedUsers(int userId) throws MetaSkillFinderException;
	
	/**
	 * This function at service layer which sends the connection request.
	 * @param{Connection} connection
	 * @throws MetaSkillFinderException 
	 */
	
	public void sendConnectionRequest(Connection connection) throws MetaSkillFinderException;
	
	/**
	 * This function at service layer which gets list of all the users to whom request is sent.
	 * @param{int} userId
	 * returns{List<User>} usersWithRequestSentList
	 * @throws MetaSkillFinderException 
	 */
	
	public List<User> getUsersWithRequestSentList(int userId) throws MetaSkillFinderException;
	
	/**
	 * This function at service layer which gets list of all the users to whom neither request is sent nor request is pending 
	 * from the user table.
	 * @param{int} userId
	 * returns{List<User>} usersWithRequestSentList
	 * @throws MetaSkillFinderException 
	 */
	
	public List<User> getUnknownUsersList(int userId) throws MetaSkillFinderException;
	
	/**
	 * This function at service layer which gets list of all the users from whom connection request is received but yet not accepted.
	 * @param{int} userId
	 * returns{List<User>} usersWithRequestSentList
	 * @throws MetaSkillFinderException 
	 */
	
	public List<User> getPendingConnectionRequestList(int userId) throws MetaSkillFinderException;
	
	/**
	 * This function at service layer which gets the pending connection from connection table.
	 * @param{int} userId
	 * @param{int} requestedUserId
	 * returns{Connection} connection
	 * @throws MetaSkillFinderException 
	 */
	
	public Connection getPendingConnection(int userId, int requestedUserId) throws MetaSkillFinderException;
	
	/**
	 * This function at service layer gets the request status of connection from connection table.
	 * @param{int} connectedUserId
	 * @param{int} sessionUserId
	 * returns{int} requestStatus
	 * @throws MetaSkillFinderException 
	 */
	
	public int getRequestStatus(int connectedUserId, int sessionUserId) throws MetaSkillFinderException;
}

