
/**
 * @interface  ExperienceService
 * @since  30th november15
 * This interface defines all the abstract functions related to the user experience at service layer. It contains all 
 * the functions related to experience table.
 */

package com.meta.skillfinder.service;

import com.meta.skillfinder.exception.MetaSkillFinderException;
import java.util.List;
import com.meta.skillfinder.model.Experience;


/**
 * @author kajal
 *
 */
public interface ExperienceService {
	
	/**
	 * This declares a function gets an experience of the user from the experience table.
	 * @param{int} userId
	 * @throws MetaSkillFinderException 
	 */
	
	public List<Experience> getExperiences(int userId) throws MetaSkillFinderException;
	
	/**
	 * This declares a function adds an experience of the user into experience table.
	 * @param{Experience} experience
	 * @throws MetaSkillFinderException 
	 */
	
	public void addUserExperience(Experience experience) throws MetaSkillFinderException;
	
	/**
	 * This declares a function deletes an experience of the user from experience table.
	 * @param{int} experienceId
	 * @throws MetaSkillFinderException 
	 */
	
	public void deleteExperience(int experienceId) throws MetaSkillFinderException;
}
