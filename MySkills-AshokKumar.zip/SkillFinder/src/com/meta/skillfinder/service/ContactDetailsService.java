
/**
 * @interface  ContactDetailsService
 * @since  26th november15
 * This class declares all the functions related to the user contact details at service layer. It contains all 
 * the functions related to contact details table.
 */

package com.meta.skillfinder.service;

import com.meta.skillfinder.model.ContactDetails;
import com.meta.skillfinder.exception.MetaSkillFinderException;

/**
 * @author kajal
 *
 */
public interface ContactDetailsService {
	
    /**
	 * This declares a function gets contact details of the user from contact details table.
	 * @param{int} contactId
	 * @returns{ContactDetails} contactDetails
	 * @throws MetaSkillFinderException 
	 */
	
	public ContactDetails getContactDetails(int contactId) throws MetaSkillFinderException;
	
	/**
	 * This declares a function adds contact details of the user in contact details table.
	 * @param{int} contactId
	 * @returns{ContactDetails} contactDetails
	 * @throws MetaSkillFinderException 
	 */
	
	public int addContactDetails(ContactDetails contactDetails) throws MetaSkillFinderException;
}
