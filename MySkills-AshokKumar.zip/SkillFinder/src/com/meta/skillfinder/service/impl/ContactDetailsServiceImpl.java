
/**
 * @class  ContactDetailsServiceImpl
 * @author Kajal
 * @since  29th november15
 * @implements ContactDetailsService
 * This class defines all the functions related to the user contact details. It contains all 
 * the functions related to contact details table.It implements the ContactDetailsService interface.
 */

package com.meta.skillfinder.service.impl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.meta.skillfinder.exception.MetaSkillFinderException;
import com.meta.skillfinder.dao.ContactDetailsDao;
import com.meta.skillfinder.model.ContactDetails;
import com.meta.skillfinder.service.ContactDetailsService;

/**
 * @author kajal
 *
 */
@Service("contactDetailsService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class ContactDetailsServiceImpl implements ContactDetailsService {

	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private ContactDetailsDao contactDetailsDao;
	
	/**
     * private logger for this class.
     */
    
    private static final Logger log = Logger.getLogger(ContactDetailsServiceImpl.class);
	
    /**
	 * This function gets contact details of the user from contact details table.
	 * @param{int} contactId
	 * @returns{ContactDetails} contactDetails
	 * @throws MetaSkillFinderException 
	 */
	
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public ContactDetails getContactDetails(int contactId)  throws MetaSkillFinderException {
		ContactDetails contactDetails = null;
		try {
			contactDetails =  contactDetailsDao.getContactDetails(contactId);
		} catch (MetaSkillFinderException e) {
			log.debug("Contact details database problem in getting contact details");
			throw e;
		}
		return contactDetails;
	}
	
	/**
	 * This function adds contact details of the user in contact details table.
	 * @param{int} contactId
	 * @throws MetaSkillFinderException 
	 */
	
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public int addContactDetails(ContactDetails contactDetails) throws MetaSkillFinderException {
		int returnValue = 0;
		try {
			returnValue =  contactDetailsDao.addContactDetails(contactDetails);
		} catch (MetaSkillFinderException e) {
			log.debug("Contact details database problem in adding contact details");
			throw e;
		}
		return returnValue;
	}
	
}
