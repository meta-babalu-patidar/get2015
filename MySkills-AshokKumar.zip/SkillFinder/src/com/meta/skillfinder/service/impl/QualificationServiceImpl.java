
/**
 * @class  QualificationServiceImpl
 * @since  30th november15
 * @implements QualificationService
 * This class defines all the functions related to the user qualification at service layer. It contains all 
 * the functions related to qualification table.
 */

package com.meta.skillfinder.service.impl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.meta.skillfinder.exception.MetaSkillFinderException;
import com.meta.skillfinder.dao.QualificationDao;
import com.meta.skillfinder.dao.impl.QualificationDaoImpl;
import com.meta.skillfinder.model.Qualification;
import com.meta.skillfinder.service.QualificationService;
import java.util.List;

/**
 * @author kajal
 *
 */

@Service("qualificationService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class QualificationServiceImpl implements QualificationService {

	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private QualificationDao qualificationDao;
	
	/**
     * private logger for this class.
     */
	
	private static final Logger log = Logger.getLogger(QualificationDaoImpl.class);

	/**
	 * This function gets the latest qualification of the user from the qualification table.
	 * @param{int} userId
	 * @return{Qualification} qualification
	 * @throws MetaSkillFinderException 
	 */

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public Qualification getLatestQualification(int userId) throws MetaSkillFinderException {
		Qualification qualification = null;
		try {
			qualification = qualificationDao.getLatestQualification(userId);
		} catch (MetaSkillFinderException e) {
			log.debug("Problem with experience database");
			throw e;
		}
		return qualification;
	}

	/**
	 * This function gets all the qualifications of the user from the qualification table.
	 * @param{int} userId
	 * @return{List<Qualification>} qualificationList
	 * @throws MetaSkillFinderException 
	 */
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public List<Qualification> getAllQualifications(int userId) throws MetaSkillFinderException {
		List<Qualification> tempList = null;
		try {
			tempList = qualificationDao.getAllQualifications(userId);
		} catch (MetaSkillFinderException e) {
			log.debug("Problem with experience database");
			throw e;
		}
		return tempList;
	}

	/**
	 * This function adds a qualification of the user into the qualification table.
	 * @param{Qualification} qualification
	 * @throws MetaSkillFinderException 
	 */

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void addUserQualification(Qualification qualification) throws MetaSkillFinderException {
		try {
			qualificationDao.addUserQualification(qualification);
		} catch (MetaSkillFinderException e) {
			log.debug("Problem with experience database");
			throw e;
		}
	}

	/**
	 * This function deletes a qualification of the user from the qualification table.
	 * @param{int} qualificationId
	 * @throws MetaSkillFinderException 
	 */

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void deleteQualification(int qualificationId) throws MetaSkillFinderException{
		try {
			qualificationDao.deleteQualification(qualificationId);
		} catch (MetaSkillFinderException e) {
			log.debug("Problem with qualification database");
			throw e;
		}
	}

}
