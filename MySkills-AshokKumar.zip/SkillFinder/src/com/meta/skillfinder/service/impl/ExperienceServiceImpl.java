
/**
 * @class  ExperienceServiceImpl
 * @since  26th november15
 * @implements ExperienceService
 * This class defines all the functions related to the user experience at service layer. It contains all 
 * the functions related to experience table.
 */

package com.meta.skillfinder.service.impl;

import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.meta.skillfinder.exception.MetaSkillFinderException;
import com.meta.skillfinder.dao.ExperienceDao;
import com.meta.skillfinder.model.Experience;
import com.meta.skillfinder.service.ExperienceService;

/**
 * @author kajal
 *
 */
@Service("experienceService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class ExperienceServiceImpl implements ExperienceService {

	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private ExperienceDao experienceDao;
	
	 /**
     * private logger for this class.
     */
	
	private static final Logger log = Logger.getLogger(ExperienceServiceImpl.class);
	
	/**
	 * This function gets an experience of the user from the experience table.
	 * @param{int} userId
	 * @throws MetaSkillFinderException 
	 */
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public List<Experience> getExperiences(int userId) throws MetaSkillFinderException {
		List<Experience> experience = null;
		try {
			experience =  experienceDao.getExperiences(userId);
		} catch (MetaSkillFinderException e) {
			log.debug("Problem with experience database");
			throw e;
		}
		return experience;
	}
	
	/**
	 * This function adds an experience of the user into experience table.
	 * @param{Experience} experience
	 * @throws MetaSkillFinderException 
	 */
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void addUserExperience(Experience experience) throws MetaSkillFinderException {
		try {
			experienceDao.addUserExperience(experience);
		} catch (MetaSkillFinderException e) {
			log.debug("Problem with experience database");
			throw e;
		}
	}
	
	/**
	 * This function deletes an experience of the user from experience table.
	 * @param{int} experienceId
	 * @throws MetaSkillFinderException 
	 */
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void deleteExperience(int experienceId) throws MetaSkillFinderException {
		try {
			experienceDao.deleteExperience(experienceId);
		} catch (MetaSkillFinderException e) {
			log.debug("Problem with experience database");
			throw e;
		}
	}
}
