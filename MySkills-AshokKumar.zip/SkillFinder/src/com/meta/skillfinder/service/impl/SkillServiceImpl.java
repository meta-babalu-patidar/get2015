
/**
 * @class  SkillServiceImpl
 * @since  30th november15
 * @implements SkillService
 * This class defines all the functions related to the user skill. It contains all 
 * the functions related to skill table.
 */

package com.meta.skillfinder.service.impl;

import java.util.List;
import com.meta.skillfinder.dao.SkillDao;
import com.meta.skillfinder.exception.MetaSkillFinderException;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.meta.skillfinder.model.Skill;
import com.meta.skillfinder.model.User;
import com.meta.skillfinder.service.SkillService;

/**
 * @author kajal
 *
 */
@Service("skillService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class SkillServiceImpl implements SkillService {

	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private SkillDao skillDao;
	
	/**
     * private logger for this class.
     */
	
	private static final Logger log = Logger.getLogger(SkillServiceImpl.class);
	
	/**
	 * This function gets the skill of the user by skill id from the user skill table.
	 * @throws Exception 
	 * @param{int} skillId
	 * @return{Skill} skill
	 * @throws MetaSkillFinderException 
	 */

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public Skill getSkillById(int skillId) throws MetaSkillFinderException {
		Skill skill = null;
		try {
			skill =  skillDao.getSkillById(skillId);
		} catch(MetaSkillFinderException e) {
			log.debug("Problem with skill database");
			throw e;
		} 
		return skill;
	}

	/**
	 * This function gets all the skill from the skill table.
	 * @return{List<Skill>} skillList
	 * @throws MetaSkillFinderException 
	 */

	@Override
	public List<Skill> getAllSkills()  throws MetaSkillFinderException {
		List<Skill> skillList = null;
		try {
			skillList = skillDao.getAllSkills();
		} catch(MetaSkillFinderException e) {
			log.debug("Problem with skill database");
			throw e;
		} 
		return skillList;
	}
	
	/**
	 * This function gets the skill id by skill name from the skill table.
	 * @return{String} skillName
	 * @throws MetaSkillFinderException 
	 */

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public int getSkillId(String skillName)  throws MetaSkillFinderException  {
		int skillId = 0;
		try {
			skillId =  skillDao.getSkillId(skillName);
		}  catch(MetaSkillFinderException e) {
			log.debug("Problem with skill database");
			throw e;
		} 
		return skillId;
	}
	
	/**
	 * This function gets all users by the the skill for search functionality.
	 * @return{List<User>} searchedUsersList
	 * @throws MetaSkillFinderException 
	 */


	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public List<User> getUsersBySkillId(int skillId, int userId)  throws MetaSkillFinderException {
		List<User> userBySkill = null;
		try {
			userBySkill = skillDao.getUsersBySkillId(skillId, userId);
		}  catch(MetaSkillFinderException e) {
			log.debug("Problem with skill database");
			throw e;
		} 
		return userBySkill;
	}
}
