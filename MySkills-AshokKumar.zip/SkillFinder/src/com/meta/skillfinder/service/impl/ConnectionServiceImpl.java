
/**
 * @class  ConnectionServiceImpl
 * @since  26th november15
 * @implements ConnectionService
 * This class defines all the functions related to the user connection. It contains all 
 * the functions related to connection table.It implements the ConnectionService interface.
 */

package com.meta.skillfinder.service.impl;

import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.meta.skillfinder.exception.MetaSkillFinderException;
import com.meta.skillfinder.dao.ConnectionDao;
import com.meta.skillfinder.model.Connection;
import com.meta.skillfinder.model.User;
import com.meta.skillfinder.service.ConnectionService;


@Service("connectionService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class ConnectionServiceImpl implements ConnectionService {

	/**
	 * Defining dependencies
	 */
	
	@Autowired
    private ConnectionDao connectionDao;
	
	 /**
     * private logger for this class.
     */
    
    private static final Logger log = Logger.getLogger(ConnectionServiceImpl.class);
    
    /**
	 * This function gets list of all the connections from the connection table.
	 * @param{int} userId
	 * returns{List<User>} connectedUsersList
	 * @throws MetaSkillFinderException 
	 */

    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public List<User> getAllConnections(int userId) throws MetaSkillFinderException {
    	List<User> allConnections = null;
        try {
        	allConnections =  connectionDao.getAllConnections(userId);
		} catch (MetaSkillFinderException e) {
			log.debug("connection database problem in getting all connections");
			throw e;
		}
        return allConnections;
    }
    
    /**
	 * This function gets list of all not connected users from the user table.
	 * @param{int} userId
	 * returns{List<User>} notConnectedUsersList
	 * @throws MetaSkillFinderException 
	 */
    
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public List<User> getAllNotConnectedUsers(int userId) throws MetaSkillFinderException {
    	List<User> allNotConnected = null;
    	try {
    		allNotConnected =  connectionDao.getAllNotConnectedUsers(userId);
    	} catch (MetaSkillFinderException e) {
    		log.debug("connection database problem in getting all non connections");
			throw e;
		}
    	return allNotConnected;
    }
    
    /**
	 * This function sends the connection request.
	 * @param{Connection} connection
	 * @throws MetaSkillFinderException 
	 */
    
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void sendConnectionRequest(Connection connection) throws MetaSkillFinderException {
    	try {
    		connectionDao.sendConnectionRequest(connection);
    	} catch (MetaSkillFinderException e) {
    		log.debug("connection database problem in sending connection request");
			throw e;
		}
    }
    
    /**
	 * This function gets list of all the users to whom request is sent.
	 * @param{int} userId
	 * returns{List<User>} usersWithRequestSentList
	 * @throws MetaSkillFinderException 
	 */
    
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public List<User> getUsersWithRequestSentList(int userId) throws MetaSkillFinderException {
    	try {
    		return connectionDao.getUsersWithRequestSentList(userId);
    	} catch (MetaSkillFinderException e) {
    		log.debug("connection database problem in getting  users already sent connections");
			throw e;
		}
    }
    
    /**
	 * This function gets list of all the users to whom neither request is sent nor request is pending 
	 * from the user table.
	 * @param{int} userId
	 * returns{List<User>} usersWithRequestSentList
	 * @throws MetaSkillFinderException 
	 */
    
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public List<User> getUnknownUsersList(int userId) throws MetaSkillFinderException {
    	try {
    		return connectionDao.getUnknownUsersList(userId);
    	} catch (MetaSkillFinderException e) {
    		log.debug("connection database problem in getting all unknown users");
			throw e;
		}
        
    }
    
    /**
	 * This function gets list of all the users from whom connection request is received but yet not accepted.
	 * @param{int} userId
	 * returns{List<User>} usersWithRequestSentList
	 * @throws MetaSkillFinderException 
	 */
    
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public List<User> getPendingConnectionRequestList(int userId) throws MetaSkillFinderException {
    	try {
    		return connectionDao.getPendingConnectionRequestList(userId);
    	} catch (MetaSkillFinderException e) {
    		log.debug("connection database problem in getting all pending connection request");
			throw e;
		}
    }
    
    /**
	 * This function gets the pending connection from connection table.
	 * @param{int} userId
	 * @param{int} requestedUserId
	 * returns{Connection} connection
	 * @throws MetaSkillFinderException 
	 */
    
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public Connection getPendingConnection(int userId, int requestedUserId) throws MetaSkillFinderException {
    	try {
    		return connectionDao.getPendingConnection(userId, requestedUserId);
    	} catch (MetaSkillFinderException e) {
    		log.debug("connection database problem in getting all pending connections");
			throw e;
		}
    }
    
    /**
	 * This function gets the request status of connection from connection table.
	 * @param{int} connectedUserId
	 * @param{int} sessionUserId
	 * returns{int} requestStatus
	 * @throws MetaSkillFinderException 
	 */
    
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public int getRequestStatus(int connectedUserId, int sessionUserId) throws MetaSkillFinderException{
    	try {
    		return connectionDao.getRequestStatus(connectedUserId, sessionUserId);
    	} catch (MetaSkillFinderException e) {
    		log.debug("connection database problem in getting all pending connections");
			throw e;
		}
    }
}
