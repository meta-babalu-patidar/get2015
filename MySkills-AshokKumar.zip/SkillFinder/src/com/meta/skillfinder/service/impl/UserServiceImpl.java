
/**
 * @class  UserDaoImpl
 * @since  30th november15
 * @implements UserDao
 * This class defines all the functions related to the user. It contains all 
 * the functions related to user table.
 */

package com.meta.skillfinder.service.impl;

import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.meta.skillfinder.exception.MetaSkillFinderException;
import com.meta.skillfinder.dao.UserDao;
import com.meta.skillfinder.model.Skill;
import com.meta.skillfinder.model.User;
import com.meta.skillfinder.service.UserService;

/**
 * @author kajal
 *
 */
@Service("userService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class UserServiceImpl implements UserService {

	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private UserDao userDao;
	
	/**
     * private logger for this class.
     */
	
	private static final Logger log = Logger.getLogger(UserServiceImpl.class);
	
	/**
	 * This function adds a user in the user table.
	 * @param{User} user
	 * @throws MetaSkillFinderException 
	 */
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void addUser(User user) throws MetaSkillFinderException {
		try {
			userDao.addUser(user);
		} catch (MetaSkillFinderException e) {
			log.debug("Problem with user database");
			throw e;
		}
	}

	/**
	 * This function returns all user skills by email id from the user table.
	 * @param{int} userId
	 * @return{List<Skill>} userSkills
	 * @throws MetaSkillFinderException 
	 */	
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public List<Skill> getUserSkills(int userId) throws MetaSkillFinderException {
		List<Skill> tempList = null;
		try {
			tempList =  userDao.getUserSkills(userId);
		} catch (MetaSkillFinderException e) {
			log.debug("Problem with user database");
			throw e;
		}
		return tempList;
	}
	
	/**
	 * This function returns a user by email id from the user table.
	 * @param{String} emailId
	 * @throws MetaSkillFinderException 
	 */
	
	public User getUser(String emailId) throws MetaSkillFinderException {
		User user = null;
		try {
			user =  userDao.getUser(emailId);
		} catch (MetaSkillFinderException e) {
			log.debug("Problem with user database");
			throw e;
		}
		return user;
	}

	/**
	 * This function updates user in the user table.
	 * @param{User} user
	 * @throws MetaSkillFinderException 
	 */
	
	@Override
	public void updateUser(User user) throws MetaSkillFinderException{
		try {
			userDao.updateUser(user);
		} catch (MetaSkillFinderException e) {
			log.debug("Problem with user database");
			throw e;
		}
	}

	/**
	 * This function returns the contact details id of user from the user table.
	 * @param{User} user
	 * @throws MetaSkillFinderException 
	 */
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public int getContactDetailsId(int userId) throws MetaSkillFinderException {
		int temp = 0;
		try {
			temp = userDao.getContactDetailsId (userId);
		} catch (MetaSkillFinderException e) {
			log.debug("Problem with user database");
			throw e;
		}
		return temp;
	}
	
}

