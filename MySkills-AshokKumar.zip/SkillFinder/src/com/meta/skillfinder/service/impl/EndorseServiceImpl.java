
/**
 * @class  EndorseServiceImpl
 * @since  29th november15
 * @implements EndorseService
 * This class defines all the functions related to the user skill endorse. It contains all 
 * the functions related to user skill endorse table.It implements the EndorseService interface.
 */

package com.meta.skillfinder.service.impl;

import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.meta.skillfinder.exception.MetaSkillFinderException;
import com.meta.skillfinder.dao.EndorseDao;
import com.meta.skillfinder.model.Endorse;
import com.meta.skillfinder.model.Skill;
import com.meta.skillfinder.service.EndorseService;

/**
 * @author kajal
 *
 */
@Service("endorseService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class EndorseServiceImpl implements EndorseService {

	/**
	 * Defining dependencies
	 */
	
	@Autowired
	private EndorseDao endorseDao;
	
	/**
     * private logger for this class.
     */
	
	private static final Logger log = Logger.getLogger(EndorseServiceImpl.class);
	
	/**
	 * This function adds an endorsement of the user into endorsement table.
	 * @param{Endorse} endorse
	 * @throws MetaSkillFinderException 
	 */
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void addEndorsement(Endorse endorse) throws MetaSkillFinderException{
		try {
			endorseDao.addEndorsement(endorse);
		} catch (MetaSkillFinderException e) {
			log.debug("endorse database problem in adding an endorse");
			throw e;
		}
	}
	
	/**
	 * This function returns a map of skill id as key and value as o or 1 defining if the user in session has
	 * already endorsed the corresponding skill of the user he is visiting profile of.
	 * @param{int} endorserId
	 * @param{int} endorsedUserId
	 * @param{List<Skill>} endorsedUserSkillList
	 * @returns{Map<Integer,Integer>}  mapOfEndorsedSkills
	 * @throws MetaSkillFinderException 
	 */
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public Map<Integer,Integer> getMapOfEndorsedSkills(int endorserId, int endorsedUserId, List<Skill> endorsedUserSkillList) throws MetaSkillFinderException{
		Map<Integer,Integer> tempMap = null;
		try {
			tempMap =  endorseDao.getMapOfEndorsedSkills(endorserId, endorsedUserId, endorsedUserSkillList);
		} catch (MetaSkillFinderException e) {
			log.debug("endorse database problem ");
			throw e;
		}
		return tempMap;
	}
	
	/**
	 * This function returns a map of skill id as key and no. of endorse for it as its value for the user in session.
	 * @param{int} userId
	 * @param{List<Skill>} userSkillList 
	 * @returns{Map<Integer,Integer>}  mapOfSkills
	 * @throws MetaSkillFinderException 
	 */
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public Map<Integer,Integer> getMapOfSkills(int userId, List<Skill> userSkillList) throws MetaSkillFinderException {
		Map<Integer,Integer> tempMap = null;
		try {
			tempMap =  endorseDao.getMapOfSkills(userId, userSkillList);
		}  catch (MetaSkillFinderException e) {
			log.debug("endorse database problem ");
			throw e;
		}
		return tempMap;
	}
	
    /**
	 * This function deletes an endorsement of the user from the endorsement table.
	 * @param{int} endorserId
	 * @param{int} endorsedUserId
	 * @param{int} skillId
	 * @throws MetaSkillFinderException 
	 */
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void deleteEndorsement(int endorserId, int endorsedUserId, int skillId) throws MetaSkillFinderException{
		try {
			endorseDao.deleteEndorsement(endorserId, endorsedUserId, skillId);
		}  catch (MetaSkillFinderException e) {
			log.debug("endorse database problem ");
			throw e;
		}
	}
	
}
