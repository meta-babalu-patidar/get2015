
/**
 * @class CertificateServiceImpl
 * @since  27th november15
 * @implements CertificateService
 * This class is a implementation of certificate service interface. It contains 
 * implementations of all the functions declared in the certificate service layer.
 */

package com.meta.skillfinder.service.impl;

import com.meta.skillfinder.dao.CertificateDao;
import com.meta.skillfinder.exception.MetaSkillFinderException;
import org.apache.log4j.Logger;
import com.meta.skillfinder.model.Certificate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.meta.skillfinder.service.CertificateService;
import java.util.List;

/**
 * @author kajal
 *
 */
@Service("certificateService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class CertificateServiceImpl implements CertificateService {

	/**
	 * Defining dependencies
	 */
	
    @Autowired
    private CertificateDao certificateDao;
    
    /**
     * private logger for this class.
     */
    
    private static final Logger log = Logger.getLogger(CertificateServiceImpl.class);
    
    /**
	 * This function calls the function of certificate dao. Which adds a new certificate
	 * to a user in certificate table.
	 * @param{Certificate} certificate
	 * @throws MetaSkillFinderException 
	 */
    
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void addUserCertificate(Certificate certificate) throws MetaSkillFinderException {
        try {
			certificateDao.addUserCertificate(certificate);
		} catch (MetaSkillFinderException e) {
			log.debug("certificate database problem in adding certificate");
			throw e;
		}
    }
    
    /**
	 * This function calls the function of certificate dao .Which gets all the certificates
	 * corresponding to a specific user in certificate table.
	 * @param{integer} userId
	 * @throws MetaSkillFinderException 
	 * @returns{List<Certificate>} certificateList
	 */
    
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public List<Certificate> getAllCertificates(int userId) throws MetaSkillFinderException {
    	List<Certificate> certificateList = null;
        try {
        	certificateList = certificateDao.getAllCertificates(userId);
		} catch (MetaSkillFinderException e) {
			log.debug("certificate database problem in retrieving certificate");
			throw e;
		}
        return certificateList;
    }
    
    /**
	 * This function deletes the certificates corresponding to a specific user in certificate table by certificate id.
	 * @param{int} certificateId
	 * @throws MetaSkillFinderException 
	 */
    
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void deleteUserCertificate(int certificateId) throws MetaSkillFinderException {
    	try {
			certificateDao.deleteUserCertificate(certificateId);
		} catch (MetaSkillFinderException e) {
			log.debug("certificate database problem in deleting user certificate");
			throw e;
		}
    }
}
