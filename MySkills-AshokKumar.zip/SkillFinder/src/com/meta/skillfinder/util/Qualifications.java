package com.meta.skillfinder.util;

public enum Qualifications {
	
	DIPLOMA, GRADUATE, POST_GRADUATE, DOCTRATE
	
	};
