


package com.meta.skillfinder.util;

public enum Gender {
	MALE, FEMALE
}
