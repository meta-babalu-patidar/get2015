
/**
 * @author Pulkit
 *
 */

package com.meta.skillfinder.util;


public enum Valid {
	VALID, NOT_VALID
};
