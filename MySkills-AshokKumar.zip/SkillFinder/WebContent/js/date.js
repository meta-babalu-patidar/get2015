


$(document).ready(function() {
	$(function() {
		$("#joiningDate").datepicker();
		$("#relieveDate").datepicker();
		$("#obtainingYear").datepicker();
		$("#issueDate").datepicker();
		$("#dateOfBirth").datepicker();
		$(".joiningDate").datepicker();
		$(".relieveDate").datepicker();
		$(".obtainingYear").datepicker();
		$(".issueDate").datepicker();
		showOn: "button";
		dateFormat: "MM/dd/yyyy";

	});
});
