


$(document).ready(function(){
	
	//function validate personal details form
	//return true if valid otherwise false
	 $(".personalSave").click(function(){
	    	var result = false;
	        if($(this).closest(".form-group").find("#firstName").val().trim() == "" ){
	        	$(this).closest(".form-group").find("#personalError").html("* Enter First Name");
	        }
	        else if($(this).closest(".form-group").find("#lastName").val().trim() == "" ){
	        	$(this).closest(".form-group").find("#personalError").html("* Enter Last Name");
	        } 
	       // if($(this).closest(".form-group").find("#gender").val().trim() == "select" ){
	       // 	$(this).closest(".form-group").find("#genderError").html("* Enter gender");
	       // }
	        
	        else if(!validateDate($(this).closest(".form-group").find("#dateOfBirth"))){
	        	$(this).closest(".form-group").find("#personalError").html("* Enter correct DateOFBirth (mm/dd/yyyy)");
	        }
	        else {
	        	$(this).closest(".form-group").find("#personalError").html("");
	        	result = true;
	        }
	        return result;
	  });
	 
	//function validate change password form
	//return true if valid otherwise false
	 $(".passwordSave").click(function(){
	    	
	        var result = false;
	        if($(this).closest(".form-group").find("#password").val().trim() == "" ){
	        	$(this).closest(".form-group").find("#passwordError").html("* Enter Current password");
	        }
	        else if($(this).closest(".form-group").find("#newPassword").val().length < 8 ){
	        	$(this).closest(".form-group").find("#passwordError").html("* New Password Length shuld be greater than 8");
	        } 
	        
	        else if($(this).closest(".form-group").find("#newPassword").val() != $(this).closest(".form-group").find("#confirmPassword").val()){
	        	$(this).closest(".form-group").find("#passwordError").html("* New Password and Confirm Password not Matched !!");
	        } 
	        else {
	        	$(this).closest(".form-group").find("#passwordError").html("");
	        	result = true;
	        } 
	        return result;
	  });
	 
	//function validate contact details form
	//return true if valid otherwise false
	 $(".contactSave").click(function(){
	    	
	        var result = false;
	        if($(this).closest(".form-group").find("#address1").val().trim() == "" ){
	        	$(this).closest(".form-group").find("#contactError").html("* Enter Address");
	        }
	        else if($(this).closest(".form-group").find("#state").val().trim() == "" ){
	        	$(this).closest(".form-group").find("#contactError").html("* Enter State");
	        }
	        else if($(this).closest(".form-group").find("#country").val().trim() == "" ){
	        	$(this).closest(".form-group").find("#contactError").html("* Enter Country");
	        }
	        else if($(this).closest(".form-group").find("#pincode").val().trim() == "" ){
	        	$(this).closest(".form-group").find("#contactError").html("* Enter pincode");
	        }
	        else if($(this).closest(".form-group").find("#mobile").val().trim() == "" ){
	        	$(this).closest(".form-group").find("#contactError").html("* Enter Mobile Number");
	        }
	        else {
	        	$(this).closest(".form-group").find("#contactError").html("");
	        	result = true;
	        }     
	        return result;
	 });
	 
	//function validate professional details form
	//return true if valid otherwise false
	 $(".professionalSave").click(function(){
	    	
	        var result = false;
	        if($(this).closest(".form-group").find("#department").val().trim() == "" ){
	        	$(this).closest(".form-group").find("#professionalError").html("* Enter Department");
	        }
	        else if($(this).closest(".form-group").find("#post").val().trim() == "" ){
	        	$(this).closest(".form-group").find("#professionalError").html("* Enter Post");
	        }
	        else if($(this).closest(".form-group").find("#professionalHeadline").val().trim() == "" ){
	        	$(this).closest(".form-group").find("#professionalError").html("* Enter Professional Headline");
	        }
	        else {
	        	$(this).closest(".form-group").find("#professionalError").html("");
	        	result = true;
	        }     
	        return result;
	 });
	 
	//function experience experience form
	//return true if valid otherwise false
    $(".experienceSave").click(function(){
    	
        var result = false;
        if($(this).closest(".form-group").find("#companyName").val().trim() == "" ){
        	$(this).closest(".form-group").find("#experienceError").html("* Enter Company Name");
        }
        else if($(this).closest(".form-group").find("#jobTitle").val().trim() == "" ){
        	$(this).closest(".form-group").find("#experienceError").html("* Enter Job Title");
        }
        else if($(this).closest(".form-group").find("#jobLocation").val().trim() == "" ){
        	$(this).closest(".form-group").find("#experienceError").html("* Enter job Location");
        } 
        else if(!validateDate($(this).closest(".form-group").find("#joiningDate"))){
        	$(this).closest(".form-group").find("#experienceError").html("* Enter correct Joining Date (mm/dd/yyyy)");
        } 
        else if(!validateDate($(this).closest(".form-group").find("#relieveDate"))){
        	$(this).closest(".form-group").find("#experienceError").html("* Enter correct Releive Date (mm/dd/yyyy)");
        }
        else {
        	$(this).closest(".form-group").find("#experienceError").html("");
        	result = true;
        }     
        return result;
    });
    
    //function validate qualification form
    //return true if valid otherwise false
    $(".qualificationSave").click(function(){
    	
        var result = false;
        if($(this).closest(".form-group").find("#institution").val().trim() == "" ){
        	$(this).closest(".form-group").find("#qualificationError").html("* Enter Department");
        }
        else if($(this).closest(".form-group").find("#obtainingYear").val().trim() == "" ){
        	$(this).closest(".form-group").find("#qualificationError").html("* Enter Post");
        }
        else if($(this).closest(".form-group").find("#qualificationEarned").val().trim() == "" ){
        	$(this).closest(".form-group").find("#qualificationError").html("* Enter Professional Headline");
        }
        else {
        	$(this).closest(".form-group").find("#qualificationError").html("");
        	result = true;
        }     
        return result;
    });
 
    //function validate certificate form
    //return true if valid otherwise false
    $(".certificateSave").click(function(){
    	
        var result = false;
        if($(this).closest(".form-group").find("#certificateName").val().trim() == "" ){
        	$(this).closest(".form-group").find("#certificateError").html("* Enter Certificate Name");
        }
        else if($(this).closest(".form-group").find("#issueAuthority").val().trim() == "" ){
        	$(this).closest(".form-group").find("#certificateError").html("* Enter Issue Authority");
        } 
        else if(!validateDate($(this).closest(".form-group").find("#issueDate"))){
        	$(this).closest(".form-group").find("#certificateError").html("* Enter correct Issued Date");
        }
        else {
        	$(this).closest(".form-group").find("#certificateError").html("");
        	result = true;
        }     
        return result;
    });

    //function validate date form
    //return true if valid otherwise false
    function validateDate(inputText) {
    	 var dateformat = /^(0?[1-9]|1[012])[/](0?[1-9]|[12][0-9]|3[01])[/]\d{4}$/;
    	// Match the date format through regular expression
    	if (inputText.val().match(dateformat)) {
    		var inputDate = inputText.val().split('/');
    		var lengthInputDate = parseInt(inputDate.length);
    		// Extract the string into month, date and year

    		if (lengthInputDate > 1) {
    			var pdate = inputText.value.split('/');
    		}
    		var dd = parseInt(pdate[0]);
    		var mm = parseInt(pdate[1]);
    		var yy = parseInt(pdate[2]);
    		var ListofDays = [ 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 ];
    		if (mm == 1 || mm > 2) {
    			if (dd > ListofDays[mm - 1]) {
    				return false;
    			}
    		}
    		if (mm == 2) {
    			var lyear = false;
    			if ((!(yy % 4) && yy % 100) || !(yy % 400)) {
    				lyear = true;
    			}
    			if ((lyear == false) && (dd >= 29)) {
    				return false;
    			}
    			if ((lyear == true) && (dd > 29)) {
    				return false;
    			}
    		}
    		return true;
    	} else {
    		return false;
    	}
    }
});


