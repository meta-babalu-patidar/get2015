/**
 * @Author:
 */

//function validate experience form
//return true if valid otherwise false
function experienceCheck() {
	var result = false;
	if (document.getElementById("companyName").value.trim() == "") {
		document.getElementById("experienceError").innerHTML = "* Enter Company Name";
	} 
	else if (document.getElementById("jobTitle").value.trim() == "") {
		document.getElementById("experienceError").innerHTML = "* Enter Job Title";
	} 
	else if (document.getElementById("jobLocation").value.trim() == "") {
		document.getElementById("experienceError").innerHTML = "* Enter job Location";
	} 
	else if (!validateDate(document.getElementById("joiningDate"))) {
		document.getElementById("experienceError").innerHTML = "* Enter correct Joining Date (mm/dd/yyyy)";
	} 
	else if (!validateDate(document.getElementById("relieveDate"))) {
		document.getElementById("experienceError").innerHTML = "* Enter correct Releive Date (mm/dd/yyyy)";
	} 
	else if (new Date(document.getElementById("joiningDate").value).getTime() > new Date(document.getElementById("relieveDate").value).getTime()) {
		document.getElementById("experienceError").innerHTML = "* Relieve Date should not be less than Joining Date ";
	}
	else {
		result = true;
	}
	return result;
}

//function reset experience error field.
function resetExperience() {
	document.getElementById("experienceError").innerHTML = "";
}

//function validate qualification form
//return true if valid otherwise false
function qualificationCheck() {
	var result = false;
	if (document.getElementById("institution").value.trim() == "") {
		document.getElementById("qualificationError").innerHTML = "* Enter Institution";
	} else if (document.getElementById("obtainingYear").value.trim() == "") {
		document.getElementById("qualificationError").innerHTML = "* Enter Obtaining Year";
	} else if (document.getElementById("qualificationEarned").value.trim() == "") {
		document.getElementById("qualificationError").innerHTML = "* Enter Qualification Earned";
	} else {
		result = true;
	}
	return result;
}

//function reset qualification error field.
function resetQualification() {
	document.getElementById("qualificationError").innerHTML = "";
}

//function validate certificate form
//return true if valid otherwise false
function certificateCheck() {
	var result = false;
	if (document.getElementById("certificateName").value.trim() == "") {
		document.getElementById("certificateError").innerHTML = "* Enter Certificate Name";
	} else if (document.getElementById("issueAuthority").value.trim() == "") {
		document.getElementById("certificateError").innerHTML = "* Enter Issued Authority";
	} else if (!validateDate(document.getElementById("issueDate"))) {
		document.getElementById("certificateError").innerHTML = "* Enter Issued Date (mm/dd/yyyy)";
	} else {
		result = true;
	}
	return result;
}

//function reset certificate error field.
function resetCertificate() {
	document.getElementById("certificateError").innerHTML = "";
}

//function validate date.
//return true if date valid otherwise false.
function validateDate(inputText) {
	var dateformat = /^(0?[1-9]|1[012])[/](0?[1-9]|[12][0-9]|3[01])[/]\d{4}$/;
	// Match the date format through regular expression
	if (inputText.value.match(dateformat)) {
		var inputDate = inputText.value.split('/');
		var lengthInputDate = parseInt(inputDate.length);
		// Extract the string into month, date and year
		if (lengthInputDate > 1) {
			var pdate = inputText.value.split('/');
		}
		var dd = parseInt(pdate[0]);
		var mm = parseInt(pdate[1]);
		var yy = parseInt(pdate[2]);
		var ListofDays = [ 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 ];
		if (mm == 1 || mm > 2) {
			if (dd > ListofDays[mm - 1]) {
				return false;
			}
		}
		if (mm == 2) {
			var lyear = false;
			if ((!(yy % 4) && yy % 100) || !(yy % 400)) {
				lyear = true;
			}
			if ((lyear == false) && (dd >= 29)) {
				return false;
			}
			if ((lyear == true) && (dd > 29)) {
				return false;
			}
		}
		return true;
	} else {
		return false;
	}
}
	
	
