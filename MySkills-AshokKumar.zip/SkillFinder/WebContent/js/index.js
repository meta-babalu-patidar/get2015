/**
 * @Author:Babalu Patidar
 */


//function validate login form 
//function return true if validate otherwise false
function loginCheck(){
	var result=false;
	resetLogin();
	if(document.getElementById("email").value.trim() == "" ){
		document.getElementById("emailError").innerHTML="Enter Email Id";
	}
	else if(document.getElementById("password").value == "" ){
		document.getElementById("passwordError").innerHTML="Enter Password";
	}
	else{
		result = true;
	}
	return result;
}

//function validate signup form 
//function return true if validate otherwise false
function signupCheck(){
	resetSignup();
	var result=false;
	if(document.getElementById("firstName").value.trim()  =="" ){
		document.getElementById("firstNameError").innerHTML="Enter first name ";
	}
	else if(document.getElementById("lastName").value.trim()  =="" ){
		document.getElementById("lastNameError").innerHTML="Enter last name ";
	}
	else if(document.getElementById("signupEmail").value.trim() == "" ){
		document.getElementById("signupEmailError").innerHTML="Enter Email ID";
	}
	else if(document.getElementById("signupPassword").value =="" ){
		document.getElementById("signupPasswordError").innerHTML="Enter password ";
	}
	else if(document.getElementById("signupPassword").value.length < 8 ){
		document.getElementById("signupPasswordError").innerHTML="Password Length should be greater than 8";
	}
	else if(document.getElementById("confirmPassword").value  =="" ){
		document.getElementById("confirmPasswordError").innerHTML="Enter confirm password ";
	}
	else if(document.getElementById("signupPassword").value != document.getElementById("confirmPassword").value) {
		document.getElementById("confirmPasswordError").innerHTML="Password & Confirm Password mismatch!!";
	}
	else{
		result = true;
	}
		return result;
}

//function reset all error field of signup form 
function  resetSignup() {
	document.getElementById("firstNameError").innerHTML="";
	document.getElementById("lastNameError").innerHTML="";
	document.getElementById("signupEmailError").innerHTML="";
	document.getElementById("signupPasswordError").innerHTML="";
	document.getElementById("confirmPasswordError").innerHTML="";
}

//function reset all error field of login form 
function  resetLogin() {
	document.getElementById("emailError").innerHTML="";
	document.getElementById("passwordError").innerHTML="";
}

//function reset all field of login form
function resetLoginForm() {
	document.getElementById("email").value="";
	document.getElementById("password").value="";
}

//function reset all field of signup form
function resetSignupForm() {
	document.getElementById("signupEmail").value="";
	document.getElementById("signupPassword").value="";
	document.getElementById("firstName").value="";
	document.getElementById("lastName").value="";
	document.getElementById("confirmPassword").value="";
}